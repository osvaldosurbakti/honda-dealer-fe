(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_cars_a0e420d1._.js",
  "static/chunks/node_modules_0d2f74f1._.js"
],
    source: "dynamic"
});
