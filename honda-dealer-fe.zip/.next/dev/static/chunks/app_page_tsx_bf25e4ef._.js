(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_99e22dca._.js",
  "static/chunks/node_modules_91ad1166._.js"
],
    source: "dynamic"
});
