(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__742aee95._.css",
  "static/chunks/components_layout_PreFooter_BlogPreview_tsx_324e3518._.js",
  "static/chunks/_86b3c8cc._.js",
  "static/chunks/node_modules_next_85bcaee2._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_f3174e92._.js"
],
    source: "dynamic"
});
