(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/layout/PreFooter/BlogPreview.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_1eef4d6e._.js",
  "static/chunks/components_layout_PreFooter_BlogPreview_tsx_681a39c1._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/layout/PreFooter/BlogPreview.tsx [app-client] (ecmascript)");
    });
});
}),
]);