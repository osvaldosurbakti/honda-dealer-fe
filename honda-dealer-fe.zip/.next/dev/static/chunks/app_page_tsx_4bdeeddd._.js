(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_99e22dca._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_f7957631._.js"
],
    source: "dynamic"
});
