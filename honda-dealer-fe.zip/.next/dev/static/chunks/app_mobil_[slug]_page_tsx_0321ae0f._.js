(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_cars_2af19b43._.js",
  "static/chunks/node_modules_fc9b1a90._.js"
],
    source: "dynamic"
});
