var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/node_modules_186c80ea._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/document.js [ssr] (ecmascript)").exports
