module.exports = [
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/data/cars/brio.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "brio",
    ()=>brio
]);
const brio = {
    id: 'brio-2024',
    slug: 'all-new-brio',
    name: 'All New BRIO',
    model: 'BRIO',
    category: 'Hatchback',
    priceRange: 'Rp 182,1 - 271,3 Juta',
    startingPrice: 182100000,
    videoUrl: 'https://youtu.be/BZhddbB5pvo?si=GBaeeLA6Kf7l9cJc',
    typeCount: 7,
    year: 2024,
    images: {
        main: '/images/cars/all-new-brio/main.jpg',
        gallery: [
            '/images/cars/all-new-brio/gallery-1.jpg',
            '/images/cars/all-new-brio/gallery-2.jpg',
            '/images/cars/all-new-brio/gallery-3.jpg',
            '/images/cars/all-new-brio/gallery-4.jpg'
        ],
        thumbnail: '/images/cars/all-new-brio/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-brio/colors/red.jpg',
            '/images/cars/all-new-brio/colors/blue.jpg',
            '/images/cars/all-new-brio/colors/white.jpg',
            '/images/cars/all-new-brio/colors/black.jpg',
            '/images/cars/all-new-brio/colors/silver.jpg',
            '/images/cars/all-new-brio/colors/orange.jpg'
        ]
    },
    variants: [
        {
            id: 'brio-s-mt',
            type: 'ALL NEW BRIO S MT',
            price: 182100000,
            priceFormatted: 'Rp 182.100.000',
            features: [
                'Front Dual SRS Airbags',
                'ABS dengan EBD',
                'Power Steering',
                'AC Manual',
                'Audio dengan USB',
                'Rem Depan Cakram',
                'Rem Belakang Tromol',
                'Velg Steel 14"',
                'Seat Fabric',
                'Immobilizer System',
                'Rear Defogger'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-e-mt',
            type: 'ALL NEW BRIO E MT',
            price: 195200000,
            priceFormatted: 'Rp 195.200.000',
            features: [
                'Front Dual SRS Airbags',
                'ABS dengan EBD',
                'Power Steering',
                'AC Manual',
                'Audio dengan USB & Bluetooth',
                'Power Window Depan',
                'Central Door Lock',
                'Remote Keyless Entry',
                'Velg Steel 14" dengan Cover',
                'Body Color Door Handle & Mirror',
                'Rear Spoiler'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-e-cvt',
            type: 'ALL NEW BRIO E CVT',
            price: 213200000,
            priceFormatted: 'Rp 213.200.000',
            features: [
                'Front Dual SRS Airbags',
                'ABS dengan EBD',
                'Power Steering',
                'AC Manual',
                'Audio dengan USB & Bluetooth',
                'Power Window Depan',
                'Central Door Lock',
                'Remote Keyless Entry',
                'Transmisi CVT',
                'Econ Mode',
                'Body Color Door Handle & Mirror',
                'Rear Spoiler'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-mt',
            type: 'ALL NEW BRIO RS MT',
            price: 258600000,
            priceFormatted: 'Rp 258.600.000',
            features: [
                'RS Body Kit & Grille',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-mt-tt',
            type: 'ALL NEW BRIO RS MT TWO TONE',
            price: 261100000,
            priceFormatted: 'Rp 261.100.000',
            features: [
                'RS Body Kit & Grille',
                'Two-Tone Color',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher',
                'Black Roof'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-cvt',
            type: 'ALL NEW BRIO RS CVT',
            price: 268800000,
            priceFormatted: 'Rp 268.800.000',
            features: [
                'RS Body Kit & Grille',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'Transmisi CVT',
                'Econ Mode',
                'Paddle Shift',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-cvt-tt',
            type: 'ALL NEW BRIO RS CVT TWO TONE',
            price: 271300000,
            priceFormatted: 'Rp 271.300.000',
            features: [
                'RS Body Kit & Grille',
                'Two-Tone Color',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'Transmisi CVT',
                'Econ Mode',
                'Paddle Shift',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher',
                'Black Roof'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '3610 mm',
            width: '1680 mm',
            height: '1500 mm',
            wheelbase: '2345 mm',
            weight: '890 - 920 kg'
        },
        performance: {
            engine: '1.2L SOHC i-VTEC',
            displacement: '1198 cc',
            maxPower: '90 PS / 6000 rpm',
            maxTorque: '110 Nm / 4800 rpm',
            transmission: '5-speed Manual / CVT',
            fuelConsumption: '20,0 km/L (MT) / 19,0 km/L (CVT)',
            acceleration: '0-100 km/h dalam 13.5 detik',
            topSpeed: '160 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '35 Liter',
            luggage: '258 Liter',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'LED Headlights (RS)',
                'Front Fog Lamps (RS)',
                '14-inch Alloy Wheels (RS)',
                'RS Body Kit'
            ],
            interior: [
                'Touchscreen Audio',
                'Multi-Info Display',
                'Fabric Seats',
                'RS Seat Fabric'
            ],
            safety: [
                'Dual SRS Airbags',
                'ABS dengan EBD',
                'Immobilizer',
                'Rear Parking Sensor (RS)'
            ],
            entertainment: [
                'USB & Bluetooth Audio',
                '4 Speakers',
                'Steering Audio Control (RS)'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Fun & Youthful',
            description: 'Brio hadir dengan desain yang fun, youthful, dan compact, perfect untuk mobilitas perkotaan. Varian RS dilengkapi dengan body kit sporty yang membuat tampilannya semakin aggressive.',
            features: [
                'Compact Hatchback Design',
                'RS Body Kit (Varian RS)',
                '14-inch Alloy Wheels (RS)',
                'Front Fog Lamps (RS)',
                'Two-Tone Color Options',
                'Chrome Accents'
            ],
            images: [
                '/images/cars/all-new-brio/features/exterior-1.jpg',
                '/images/cars/all-new-brio/features/exterior-2.jpg'
            ]
        },
        interior: {
            title: 'Interior Praktis & Fungsional',
            description: 'Kabin yang didesain dengan layout praktis dan fungsional, menawarkan kenyamanan dan kemudahan penggunaan dalam berkendara sehari-hari.',
            features: [
                'Touchscreen Audio System',
                'Multi-Info Display',
                'Fabric Seats dengan RS Variant',
                'Power Windows',
                'Steering Wheel dengan Audio Control (RS)',
                'Cabin Storage yang Luas'
            ],
            images: [
                '/images/cars/all-new-brio/features/interior-1.jpg',
                '/images/cars/all-new-brio/features/interior-2.jpg'
            ]
        },
        safety: {
            title: 'Keselamatan yang Terjangkau',
            description: 'Dilengkapi dengan fitur keselamatan dasar yang essential untuk perlindungan pengemudi dan penumpang dalam berkendara sehari-hari.',
            features: [
                'Dual Front SRS Airbags',
                'Anti-lock Braking System (ABS)',
                'Electronic Brake-force Distribution (EBD)',
                'Immobilizer System',
                'Rear Parking Sensor (RS)',
                'High-Mounted Stop Lamp'
            ],
            images: [
                '/images/cars/all-new-brio/features/safety-1.jpg',
                '/images/cars/all-new-brio/features/safety-2.jpg'
            ]
        },
        technology: {
            title: 'Teknologi untuk Kenyamanan Berkendara',
            description: 'Berbagai fitur teknologi yang mendukung kenyamanan dan efisiensi dalam berkendara sehari-hari.',
            features: [
                'ECON Mode (CVT)',
                'Paddle Shift (RS CVT)',
                'Remote Keyless Entry',
                'Power Steering',
                'Multi-Info Display',
                'Audio System dengan USB & Bluetooth'
            ],
            images: [
                '/images/cars/all-new-brio/features/tech-1.jpg',
                '/images/cars/all-new-brio/features/tech-2.jpg'
            ]
        }
    },
    description: 'All New Brio adalah hatchback kompak yang sempurna untuk mobilitas perkotaan. Dengan desain yang fun dan youthful, Brio menawarkan efisiensi bahan bakar yang excellent dan kemudahan dalam bermanuver. Tersedia dalam berbagai varian mulai dari S hingga RS dengan pilihan transmisi Manual dan CVT, dilengkapi dengan fitur keselamatan dan teknologi yang memadai untuk kebutuhan sehari-hari.',
    shortDescription: 'Hatchback kompak yang fun dan efisien untuk mobilitas perkotaan dengan pilihan 7 varian termasuk RS yang sporty.',
    tags: [
        'Hatchback',
        'City Car',
        'Economical',
        'Compact',
        'RS Model',
        'Two-Tone',
        'Fuel Efficient'
    ],
    isFeatured: true,
    isNew: true,
    views: 865,
    relatedCars: [
        'new-hr-v',
        'wr-v',
        'mobilio'
    ],
    createdAt: '2024-01-10',
    updatedAt: '2024-01-10'
};
}),
"[project]/data/cars/hrv.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hrv",
    ()=>hrv
]);
const hrv = {
    id: 'hrv-2024',
    slug: 'new-hr-v',
    name: 'All New HR-V',
    model: 'HR-V',
    category: 'SUV',
    priceRange: 'Rp 403,8 - 428,4 Juta',
    startingPrice: 403800000,
    typeCount: 4,
    year: 2024,
    images: {
        main: '/images/cars/all-new-hr-v/main.jpg',
        gallery: [
            '/images/cars/all-new-hr-v/gallery-1.jpg',
            '/images/cars/all-new-hr-v/gallery-2.jpg',
            '/images/cars/all-new-hr-v/gallery-3.jpg',
            '/images/cars/all-new-hr-v/gallery-4.jpg'
        ],
        thumbnail: '/images/cars/all-new-hr-v/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-hr-v/colors/red.jpg',
            '/images/cars/all-new-hr-v/colors/black.jpg',
            '/images/cars/all-new-hr-v/colors/white.jpg',
            '/images/cars/all-new-hr-v/colors/gray.jpg',
            '/images/cars/all-new-hr-v/colors/silver.jpg'
        ]
    },
    variants: [
        {
            id: 'hrv-e-cvt',
            type: 'ALL NEW HR-V E CVT',
            price: 403800000,
            priceFormatted: 'Rp 403.800.000',
            features: [
                'LED Headlights',
                '7-inch Touchscreen Display',
                'Keyless Entry',
                '6 Airbags',
                'Vehicle Stability Assist',
                'Rear View Camera',
                'Manual AC',
                'Fabric Seats',
                '4 Speakers',
                '16-inch Alloy Wheels'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'hrv-e-cvt-tt',
            type: 'ALL NEW HR-V E CVT TWO TONE',
            price: 406300000,
            priceFormatted: 'Rp 406.300.000',
            features: [
                'LED Headlights',
                '7-inch Touchscreen Display',
                'Keyless Entry',
                '6 Airbags',
                'Vehicle Stability Assist',
                'Rear View Camera',
                'Manual AC',
                'Fabric Seats',
                '4 Speakers',
                '16-inch Alloy Wheels',
                'Two-Tone Color',
                'Black Roof'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'hrv-e-plus-cvt',
            type: 'ALL NEW HR-V E+ CVT',
            price: 425900000,
            priceFormatted: 'Rp 425.900.000',
            features: [
                'LED Headlights with DRL',
                '8-inch Touchscreen Display',
                'Push Start Button',
                'Rear View Camera',
                'Parking Sensors',
                'Auto AC',
                'Fabric Seats',
                '6 Speakers',
                '17-inch Alloy Wheels',
                'Paddle Shift',
                'Multi-View Camera'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'hrv-e-plus-cvt-tt',
            type: 'ALL NEW HR-V E+ CVT TWO TONE',
            price: 428400000,
            priceFormatted: 'Rp 428.400.000',
            features: [
                'LED Headlights with DRL',
                '8-inch Touchscreen Display',
                'Push Start Button',
                'Rear View Camera',
                'Parking Sensors',
                'Auto AC',
                'Fabric Seats',
                '6 Speakers',
                '17-inch Alloy Wheels',
                'Paddle Shift',
                'Multi-View Camera',
                'Two-Tone Color',
                'Black Roof',
                'Chrome Accents'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4385 mm',
            width: '1790 mm',
            height: '1590 mm',
            wheelbase: '2610 mm',
            weight: '1250 - 1280 kg'
        },
        performance: {
            engine: '1.5L DOHC i-VTEC',
            displacement: '1498 cc',
            maxPower: '121 PS / 6600 rpm',
            maxTorque: '145 Nm / 4300 rpm',
            transmission: 'CVT dengan Earth Dreams Technology',
            fuelConsumption: '17,8 km/L',
            acceleration: '0-100 km/h dalam 11.2 detik',
            topSpeed: '185 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '40 Liter',
            luggage: '430 Liter (dapat diperluas hingga 1.200 Liter)',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'LED Headlights',
                'Power Retractable Mirrors',
                '16-17 inch Alloy Wheels'
            ],
            interior: [
                'Floating Touchscreen',
                'Digital Cluster',
                'Fabric Seats',
                'Manual/Auto AC'
            ],
            safety: [
                '6 Airbags',
                'ABS + EBD',
                'Vehicle Stability Assist',
                'Rear View Camera'
            ],
            entertainment: [
                'Apple CarPlay',
                'Android Auto',
                '4-6 Speakers'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Modern & Sporty',
            description: 'HR-V generasi baru dengan desain lebih maskulin dan sporty, berkat penggunaan panel front grille dengan desain lebih lebar dan tebal, sebagai latar dari logo Honda.',
            features: [
                'LED Headlights dengan DRL',
                '16-17 inch Alloy Wheels',
                'Power Retractable Side Mirrors',
                'Chrome Front Grille',
                'LED Fog Lamps (E+)',
                'Two-Tone Color Options'
            ],
            images: [
                '/images/cars/all-new-hr-v/features/exterior-1.jpg',
                '/images/cars/all-new-hr-v/features/exterior-2.jpg'
            ]
        },
        interior: {
            title: 'Interior Nyaman & Teknologi Terkini',
            description: 'Kabin yang didesain dengan material berkualitas dan teknologi terkini untuk kenyamanan maksimal pengemudi dan penumpang.',
            features: [
                'Floating 7-8 inch Touchscreen Display',
                'Digital Meter Cluster',
                'Fabric Seats',
                'Manual / Auto AC',
                'Paddle Shift (E+)',
                'Multi-View Camera (E+)'
            ],
            images: [
                '/images/cars/all-new-hr-v/features/interior-1.jpg',
                '/images/cars/all-new-hr-v/features/interior-2.jpg'
            ]
        },
        safety: {
            title: 'Teknologi Keselamatan Komprehensif',
            description: 'Dilengkapi dengan berbagai fitur keselamatan canggih yang memberikan perlindungan maksimal untuk pengemudi dan penumpang.',
            features: [
                '6 SRS Airbags',
                'Anti-lock Braking System (ABS)',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Rear View Camera',
                'Parking Sensors (E+)'
            ],
            images: [
                '/images/cars/all-new-hr-v/features/safety-1.jpg',
                '/images/cars/all-new-hr-v/features/safety-2.jpg'
            ]
        }
    },
    description: 'All New HR-V dengan desain terbaru yang lebih sporty dan teknologi canggih. SUV kompak yang sempurna untuk keluarga modern. Tersedia dalam 4 varian dengan pilihan warna Two-Tone.',
    shortDescription: 'SUV kompak dengan desain modern dan teknologi canggih untuk keluarga urban, tersedia dalam 4 varian.',
    tags: [
        'SUV',
        'Family',
        'City Car',
        'Two-Tone',
        'Compact SUV'
    ],
    isFeatured: true,
    isNew: true,
    views: 1247,
    relatedCars: [
        'new-cr-v',
        'new-br-v',
        'wr-v'
    ],
    createdAt: '2024-01-15',
    updatedAt: '2024-01-15'
};
}),
"[project]/data/cars/crv.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "crv",
    ()=>crv
]);
const crv = {
    id: 'crv-2024',
    slug: 'all-new-cr-v',
    name: 'All New CR-V',
    model: 'CR-V',
    category: 'SUV',
    priceRange: 'Rp 828,7 - 950 Juta',
    startingPrice: 828700000,
    typeCount: 3,
    year: 2024,
    images: {
        main: '/images/cars/all-new-cr-v/main.jpg',
        gallery: [
            '/images/cars/all-new-cr-v/gallery-1.jpg',
            '/images/cars/all-new-cr-v/gallery-2.jpg',
            '/images/cars/all-new-cr-v/gallery-3.jpg',
            '/images/cars/all-new-cr-v/gallery-4.jpg'
        ],
        thumbnail: '/images/cars/all-new-cr-v/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-cr-v/colors/black.jpg',
            '/images/cars/all-new-cr-v/colors/white.jpg',
            '/images/cars/all-new-cr-v/colors/silver.jpg',
            '/images/cars/all-new-cr-v/colors/blue.jpg'
        ]
    },
    variants: [
        {
            id: 'crv-e-cvt',
            type: 'ALL NEW CR-V E CVT',
            price: 828700000,
            priceFormatted: 'Rp 828.700.000',
            features: [
                'LED Headlights dengan DRL',
                '18-inch Alloy Wheels',
                '7-inch Touchscreen',
                'Honda SENSING',
                'Electric Parking Brake'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L Turbo',
            available: true
        },
        {
            id: 'crv-e-hev',
            type: 'ALL NEW CR-V e:HEV',
            price: 899000000,
            priceFormatted: 'Rp 899.000.000',
            features: [
                'Full LED Headlights',
                'Hybrid System',
                '9-inch Touchscreen',
                'Wireless Charger',
                'Panoramic Sunroof'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        }
    ],
    description: 'All New CR-V adalah SUV premium dengan desain yang elegan dan teknologi canggih. Menawarkan kenyamanan terbaik dan fitur keselamatan terlengkap.',
    shortDescription: 'SUV premium dengan teknologi canggih dan kenyamanan terbaik untuk keluarga.',
    tags: [
        'SUV',
        'Premium',
        'Family',
        '7-Seater',
        'Hybrid'
    ],
    isFeatured: true,
    isNew: true,
    views: 892,
    relatedCars: [
        'new-hr-v',
        'new-br-v'
    ],
    createdAt: '2024-01-20',
    updatedAt: '2024-01-20'
};
}),
"[project]/data/cars/wrv.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "wrv",
    ()=>wrv
]);
const wrv = {
    id: 'wrv-2024',
    slug: 'all-new-wr-v',
    name: 'All New WR-V',
    model: 'WR-V',
    category: 'SUV',
    priceRange: 'Rp 320 - 380 Juta',
    startingPrice: 320000000,
    typeCount: 4,
    year: 2024,
    images: {
        main: '/images/cars/all-new-wr-v/main.jpg',
        gallery: [
            '/images/cars/all-new-wr-v/gallery-1.jpg',
            '/images/cars/all-new-wr-v/gallery-2.jpg',
            '/images/cars/all-new-wr-v/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-wr-v/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-wr-v/colors/red.jpg',
            '/images/cars/all-new-wr-v/colors/black.jpg',
            '/images/cars/all-new-wr-v/colors/white.jpg'
        ]
    },
    variants: [
        {
            id: 'wrv-e-cvt',
            type: 'ALL NEW WR-V E CVT',
            price: 320000000,
            priceFormatted: 'Rp 320.000.000',
            features: [
                'LED Headlights',
                '7-inch Touchscreen',
                'Keyless Entry',
                '4 Airbags',
                'Rear Camera'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    description: 'All New WR-V menghadirkan SUV compact dengan desain adventurous dan kapabilitas tangguh untuk petualangan urban.',
    shortDescription: 'SUV compact dengan desain adventurous untuk petualangan urban.',
    tags: [
        'SUV',
        'Adventure',
        'Compact',
        'Urban'
    ],
    isFeatured: true,
    isNew: true,
    views: 756,
    relatedCars: [
        'all-new-brio',
        'new-hr-v'
    ],
    createdAt: '2024-02-01',
    updatedAt: '2024-02-01'
};
}),
"[project]/data/cars/brv.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "brv",
    ()=>brv
]);
const brv = {
    id: 'brv-2024',
    slug: 'all-new-br-v',
    name: 'All New BR-V',
    model: 'BR-V',
    category: 'MPV',
    priceRange: 'Rp 280 - 350 Juta',
    startingPrice: 280000000,
    typeCount: 5,
    year: 2024,
    images: {
        main: '/images/cars/all-new-br-v/main.jpg',
        gallery: [
            '/images/cars/all-new-br-v/gallery-1.jpg',
            '/images/cars/all-new-br-v/gallery-2.jpg',
            '/images/cars/all-new-br-v/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-br-v/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-br-v/colors/white.jpg',
            '/images/cars/all-new-br-v/colors/black.jpg',
            '/images/cars/all-new-br-v/colors/silver.jpg'
        ]
    },
    variants: [
        {
            id: 'brv-e-cvt',
            type: 'ALL NEW BR-V E CVT',
            price: 280000000,
            priceFormatted: 'Rp 280.000.000',
            features: [
                '7-Seater',
                'LED Headlights',
                'Touchscreen Display',
                'Rear AC',
                '4 Airbags'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    description: 'All New BR-V adalah MPV 7-seater dengan desain sporty dan ruang kabin yang luas, cocok untuk keluarga besar.',
    shortDescription: 'MPV 7-seater dengan desain sporty dan ruang luas untuk keluarga.',
    tags: [
        'MPV',
        '7-Seater',
        'Family',
        'Spacious'
    ],
    isFeatured: true,
    isNew: true,
    views: 923,
    relatedCars: [
        'all-new-cr-v',
        'all-new-hr-v'
    ],
    createdAt: '2024-02-05',
    updatedAt: '2024-02-05'
};
}),
"[project]/data/cars/civic.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "civic",
    ()=>civic
]);
const civic = {
    id: 'civic-e-hev-rs-2024',
    slug: 'all-new-civic-e-hev-rs',
    name: 'All New Civic e:HEV RS',
    model: 'Civic',
    category: 'Sedan',
    priceRange: 'Rp 680 - 750 Juta',
    startingPrice: 680000000,
    typeCount: 2,
    year: 2024,
    images: {
        main: '/images/cars/all-new-civic-e-hev-rs/main.jpg',
        gallery: [
            '/images/cars/all-new-civic-e-hev-rs/gallery-1.jpg',
            '/images/cars/all-new-civic-e-hev-rs/gallery-2.jpg',
            '/images/cars/all-new-civic-e-hev-rs/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-civic-e-hev-rs/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-civic-e-hev-rs/colors/red.jpg',
            '/images/cars/all-new-civic-e-hev-rs/colors/black.jpg',
            '/images/cars/all-new-civic-e-hev-rs/colors/white.jpg'
        ]
    },
    variants: [
        {
            id: 'civic-e-hev-rs',
            type: 'ALL NEW CIVIC e:HEV RS',
            price: 750000000,
            priceFormatted: 'Rp 750.000.000',
            features: [
                'RS Body Kit',
                'Hybrid System',
                'Full LED Headlights',
                '10.2-inch Digital Cluster',
                'Bose Premium Audio',
                'Honda SENSING'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        }
    ],
    description: 'All New Civic e:HEV RS menghadirkan sedan sport hybrid dengan performa tangguh dan desain agresif khas RS.',
    shortDescription: 'Sedan sport hybrid dengan desain agresif khas RS dan performa tangguh.',
    tags: [
        'Sedan',
        'Hybrid',
        'Sport',
        'RS',
        'Premium'
    ],
    isFeatured: true,
    isNew: true,
    views: 1567,
    relatedCars: [
        'all-new-civic-type-r',
        'city-hatchback-rs'
    ],
    createdAt: '2024-02-25',
    updatedAt: '2024-02-25'
};
}),
"[project]/data/cars/accord.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "accord",
    ()=>accord
]);
const accord = {
    id: 'accord-ehev-2024',
    slug: 'all-new-accord-ehev',
    name: 'All New Accord e:HEV',
    model: 'Accord',
    category: 'Sedan',
    priceRange: 'Rp 825 - 925 Juta',
    startingPrice: 825000000,
    typeCount: 3,
    year: 2024,
    images: {
        main: '/images/cars/all-new-accord-ehev/main.jpg',
        gallery: [
            '/images/cars/all-new-accord-ehev/gallery-1.jpg',
            '/images/cars/all-new-accord-ehev/gallery-2.jpg',
            '/images/cars/all-new-accord-ehev/gallery-3.jpg',
            '/images/cars/all-new-accord-ehev/gallery-4.jpg'
        ],
        thumbnail: '/images/cars/all-new-accord-ehev/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-accord-ehev/colors/white.jpg',
            '/images/cars/all-new-accord-ehev/colors/black.jpg',
            '/images/cars/all-new-accord-ehev/colors/silver.jpg',
            '/images/cars/all-new-accord-ehev/colors/blue.jpg'
        ]
    },
    variants: [
        {
            id: 'accord-ehev-luxury',
            type: 'ACCORD e:HEV LUXURY',
            price: 825000000,
            priceFormatted: 'Rp 825.000.000',
            features: [
                'Hybrid System 2.0L',
                '12.3-inch Touchscreen Display',
                'Digital Cluster 10.2-inch',
                'Leather Seats dengan Memory Function',
                'Honda SENSING 360',
                '8 Airbags',
                'Panoramic Sunroof',
                'Wireless Charger'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        },
        {
            id: 'accord-ehev-prestige',
            type: 'ACCORD e:HEV PRESTIGE',
            price: 875000000,
            priceFormatted: 'Rp 875.000.000',
            features: [
                'Advanced Hybrid System',
                'Head-up Display',
                'Bose Premium Audio System',
                'Ventilated & Heated Seats',
                '360-degree Camera',
                'Parking Assist',
                'Ambient Lighting',
                'Power Rear Sunshade'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        },
        {
            id: 'accord-ehev-flagship',
            type: 'ACCORD e:HEV FLAGSHIP',
            price: 925000000,
            priceFormatted: 'Rp 925.000.000',
            features: [
                'Full LED Matrix Headlights',
                '12-speaker Bose Audio',
                'Semi-autonomous Driving',
                'Remote Parking Assist',
                'Wireless Apple CarPlay & Android Auto',
                'Digital Key',
                'Traffic Jam Assist',
                'Premium Nappa Leather'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4970 mm',
            width: '1860 mm',
            height: '1450 mm',
            wheelbase: '2830 mm',
            weight: '1580 kg'
        },
        performance: {
            engine: '2.0L Atkinson Cycle i-VTEC + Dual Motor',
            displacement: '1993 cc',
            maxPower: '204 PS (combined)',
            maxTorque: '335 Nm (combined)',
            transmission: 'e-CVT',
            fuelConsumption: '23,8 km/L',
            acceleration: '0-100 km/h dalam 7,6 detik',
            topSpeed: '180 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '48 Liter',
            luggage: '450 Liter',
            doors: '4 Pintu'
        },
        features: {
            exterior: [
                'Full LED Headlights',
                '18-inch Alloy Wheels',
                'Power Sunroof',
                'Smart Entry'
            ],
            interior: [
                'Leather Seats',
                'Dual Zone Climate Control',
                'Power Seats',
                'Push Start'
            ],
            safety: [
                'Honda SENSING 360',
                '8 Airbags',
                'ABS + EBD',
                'Vehicle Stability Assist'
            ],
            entertainment: [
                '12.3-inch Display',
                'Bose Audio',
                'Wireless Connectivity',
                'Navigation'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Elegant & Futuristik',
            description: 'Accord generasi terbaru dengan desain yang lebih premium dan elegan, menampilkan garis-garis yang tajam dan proporsi yang sempurna untuk sedan executive modern.',
            features: [
                'Full LED Matrix Headlights dengan Adaptive Beam',
                '18-inch Premium Alloy Wheels',
                'Panoramic Glass Roof',
                'Chrome Accents & Body Kit',
                'Power Folding Side Mirrors'
            ],
            images: [
                '/images/cars/all-new-accord-ehev/features/exterior-1.jpg',
                '/images/cars/all-new-accord-ehev/features/exterior-2.jpg'
            ]
        },
        interior: {
            title: 'Interior Luxury & Technology',
            description: 'Kabin mewah dengan material premium dan teknologi terkini, menawarkan kenyamanan tertinggi dan pengalaman berkendara yang sophisticated.',
            features: [
                '12.3-inch Advanced Touchscreen Display',
                '10.2-inch Digital Meter Cluster',
                'Leather Seats dengan Memory & Ventilation',
                'Bose Premium Audio System 12-speaker',
                'Ambient Lighting dengan Multiple Colors'
            ],
            images: [
                '/images/cars/all-new-accord-ehev/features/interior-1.jpg',
                '/images/cars/all-new-accord-ehev/features/interior-2.jpg'
            ]
        },
        safety: {
            title: 'Advanced Safety Suite',
            description: 'Dilengkapi dengan Honda SENSING 360 yang memberikan perlindungan menyeluruh dengan berbagai fitur keselamatan canggih untuk perlindungan maksimal.',
            features: [
                'Honda SENSING 360 dengan 360-degree Camera',
                '8 SRS Airbags dengan Knee Airbag',
                'Blind Spot Information System',
                'Cross Traffic Monitor',
                'Traffic Jam Assist'
            ],
            images: [
                '/images/cars/all-new-accord-ehev/features/safety-1.jpg',
                '/images/cars/all-new-accord-ehev/features/safety-2.jpg'
            ]
        },
        technology: {
            title: 'Cutting-Edge Technology',
            description: 'Terintegrasi dengan teknologi paling mutakhir untuk pengalaman berkendara yang terhubung, aman, dan menyenangkan di era digital.',
            features: [
                'Wireless Apple CarPlay & Android Auto',
                'Head-up Display dengan AR Navigation',
                'Digital Key dengan Smartphone Integration',
                'Wireless Smartphone Charger',
                'Honda CONNECT dengan 5G Connectivity'
            ],
            images: [
                '/images/cars/all-new-accord-ehev/features/technology-1.jpg',
                '/images/cars/all-new-accord-ehev/features/technology-2.jpg'
            ]
        }
    },
    description: 'All New Honda Accord e:HEV adalah sedan executive premium dengan teknologi hybrid terdepan. Menghadirkan kombinasi sempurna antara performa, efisiensi, dan kemewahan dengan fitur-fitur canggih untuk pengalaman berkendara yang tak tertandingi.',
    shortDescription: 'Sedan executive premium hybrid dengan teknologi canggih dan kemewahan terbaik di kelasnya.',
    tags: [
        'Sedan',
        'Premium',
        'Hybrid',
        'Executive',
        'Honda SENSING',
        'Luxury'
    ],
    isFeatured: true,
    isNew: true,
    views: 1568,
    relatedCars: [
        'all-new-civic-e-hev-rs',
        'all-new-cr-v',
        'all-new-civic-type-r'
    ],
    createdAt: '2024-03-10',
    updatedAt: '2024-03-10'
};
}),
"[project]/data/cars/stepwgn.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stepwgn",
    ()=>stepwgn
]);
const stepwgn = {
    id: 'stepwgn-e-hev-2024',
    slug: 'stepwgn-e-hev',
    name: 'Stepwgn e:HEV',
    model: 'Stepwgn',
    category: 'MPV',
    priceRange: 'Rp 650 - 750 Juta',
    startingPrice: 650000000,
    typeCount: 3,
    year: 2024,
    images: {
        main: '/images/cars/stepwgn-e-hev/main.jpg',
        gallery: [
            '/images/cars/stepwgn-e-hev/gallery-1.jpg',
            '/images/cars/stepwgn-e-hev/gallery-2.jpg',
            '/images/cars/stepwgn-e-hev/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/stepwgn-e-hev/thumbnail.jpg',
        colorOptions: [
            '/images/cars/stepwgn-e-hev/colors/white.jpg',
            '/images/cars/stepwgn-e-hev/colors/black.jpg',
            '/images/cars/stepwgn-e-hev/colors/silver.jpg'
        ]
    },
    variants: [
        {
            id: 'stepwgn-e-hev-premium',
            type: 'STEPWGN e:HEV PREMIUM',
            price: 750000000,
            priceFormatted: 'Rp 750.000.000',
            features: [
                '8-Seater Hybrid',
                'Magic Seats',
                'Dual Power Sliding Doors',
                'Panoramic Roof',
                'Honda SENSING 360',
                '11.4-inch Touchscreen'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        }
    ],
    description: 'Stepwgn e:HEV adalah MPV keluarga premium dengan teknologi hybrid dan konfigurasi kursi Magic Seats yang fleksibel.',
    shortDescription: 'MPV keluarga premium hybrid dengan Magic Seats yang fleksibel.',
    tags: [
        'MPV',
        'Hybrid',
        '8-Seater',
        'Premium',
        'Family'
    ],
    isFeatured: true,
    isNew: true,
    views: 834,
    relatedCars: [
        'all-new-br-v',
        'all-new-cr-v'
    ],
    createdAt: '2024-02-20',
    updatedAt: '2024-02-20'
};
}),
"[project]/data/cars/cityhatchback.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cityhatchback",
    ()=>cityhatchback
]);
const cityhatchback = {
    id: 'city-hatchback-rs-2024',
    slug: 'city-hatchback-rs',
    name: 'City Hatchback RS',
    model: 'City',
    category: 'Hatchback',
    priceRange: 'Rp 350 - 420 Juta',
    startingPrice: 350000000,
    typeCount: 3,
    year: 2024,
    images: {
        main: '/images/cars/city-hatchback-rs/main.jpg',
        gallery: [
            '/images/cars/city-hatchback-rs/gallery-1.jpg',
            '/images/cars/city-hatchback-rs/gallery-2.jpg',
            '/images/cars/city-hatchback-rs/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/city-hatchback-rs/thumbnail.jpg',
        colorOptions: [
            '/images/cars/city-hatchback-rs/colors/red.jpg',
            '/images/cars/city-hatchback-rs/colors/black.jpg',
            '/images/cars/city-hatchback-rs/colors/white.jpg'
        ]
    },
    variants: [
        {
            id: 'city-hatchback-rs-premium',
            type: 'CITY HATCHBACK RS PREMIUM',
            price: 420000000,
            priceFormatted: 'Rp 420.000.000',
            features: [
                'RS Body Kit',
                'LED Headlights dengan DRL',
                '8-inch Touchscreen',
                'Apple CarPlay & Android Auto',
                '6 Airbags',
                'Push Start Button'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    description: 'City Hatchback RS menghadirkan hatchback sporty dengan desain agresif khas RS dan fitur lengkap untuk mobilitas urban.',
    shortDescription: 'Hatchback sporty dengan desain agresif khas RS untuk mobilitas urban.',
    tags: [
        'Hatchback',
        'Sport',
        'RS',
        'City Car',
        'Premium'
    ],
    isFeatured: true,
    isNew: true,
    views: 987,
    relatedCars: [
        'all-new-brio',
        'all-new-civic-e-hev-rs'
    ],
    createdAt: '2024-03-01',
    updatedAt: '2024-03-01'
};
}),
"[project]/data/cars/civictyper.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "civicTypeR",
    ()=>civicTypeR
]);
const civicTypeR = {
    id: 'civic-type-r-2024',
    slug: 'all-new-civic-type-r',
    name: 'All New Civic Type R',
    model: 'Civic Type R',
    category: 'Sport',
    priceRange: 'Rp 1,2 - 1,5 Miliar',
    startingPrice: 1200000000,
    typeCount: 1,
    year: 2024,
    images: {
        main: '/images/cars/all-new-civic-type-r/main.jpg',
        gallery: [
            '/images/cars/all-new-civic-type-r/gallery-1.jpg',
            '/images/cars/all-new-civic-type-r/gallery-2.jpg',
            '/images/cars/all-new-civic-type-r/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-civic-type-r/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-civic-type-r/colors/red.jpg',
            '/images/cars/all-new-civic-type-r/colors/white.jpg',
            '/images/cars/all-new-civic-type-r/colors/blue.jpg'
        ]
    },
    variants: [
        {
            id: 'civic-type-r',
            type: 'ALL NEW CIVIC TYPE R',
            price: 1500000000,
            priceFormatted: 'Rp 1.500.000.000',
            features: [
                '2.0L VTEC Turbo Engine',
                '6-speed Manual Transmission',
                'Racing Bucket Seats',
                'Brembo Brakes',
                '20-inch Alloy Wheels',
                'Type R Body Kit'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '2.0L Turbo',
            available: true
        }
    ],
    description: 'All New Civic Type R adalah hatchback performa tinggi dengan teknologi balap terbaru, memberikan pengalaman berkendara yang ekstrem dan mendebarkan.',
    shortDescription: 'Hatchback performa tinggi dengan teknologi balap untuk pengalaman berkendara ekstrem.',
    tags: [
        'Sport',
        'Performance',
        'Type R',
        'Turbo',
        'Racing'
    ],
    isFeatured: true,
    isNew: true,
    views: 2345,
    relatedCars: [
        'all-new-civic-e-hev-rs',
        'city-hatchback-rs'
    ],
    createdAt: '2024-03-05',
    updatedAt: '2024-03-05'
};
}),
"[project]/data/cars/hrvehev.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hrvehev",
    ()=>hrvehev
]);
const hrvehev = {
    id: 'hrv-e-hev-2024',
    slug: 'all-new-hr-v-e-hev',
    name: 'All New HR-V e:HEV',
    model: 'HR-V e:HEV',
    category: 'SUV',
    priceRange: 'Rp 450 - 500 Juta',
    startingPrice: 450000000,
    typeCount: 2,
    year: 2024,
    images: {
        main: '/images/cars/all-new-hr-v-e-hev/main.jpg',
        gallery: [
            '/images/cars/all-new-hr-v-e-hev/gallery-1.jpg',
            '/images/cars/all-new-hr-v-e-hev/gallery-2.jpg',
            '/images/cars/all-new-hr-v-e-hev/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-hr-v-e-hev/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-hr-v-e-hev/colors/blue.jpg',
            '/images/cars/all-new-hr-v-e-hev/colors/white.jpg',
            '/images/cars/all-new-hr-v-e-hev/colors/gray.jpg'
        ]
    },
    variants: [
        {
            id: 'hrv-e-hev-premium',
            type: 'ALL NEW HR-V e:HEV PREMIUM',
            price: 500000000,
            priceFormatted: 'Rp 500.000.000',
            features: [
                'Hybrid System',
                'Full LED Headlights',
                'Panoramic Sunroof',
                'Wireless Charger',
                'Honda SENSING',
                'Leather Seats'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    description: 'All New HR-V e:HEV menghadirkan teknologi hybrid terbaru dengan efisiensi bahan bakar yang excellent dan performa responsif.',
    shortDescription: 'SUV hybrid dengan efisiensi bahan bakar excellent dan performa responsif.',
    tags: [
        'SUV',
        'Hybrid',
        'Eco-Friendly',
        'Premium'
    ],
    isFeatured: true,
    isNew: true,
    views: 1123,
    relatedCars: [
        'new-hr-v',
        'all-new-cr-v'
    ],
    createdAt: '2024-02-15',
    updatedAt: '2024-02-15'
};
}),
"[project]/data/cars/n7x.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "n7x",
    ()=>n7x
]);
const n7x = {
    id: 'brv-n7x-2024',
    slug: 'all-new-br-v-n7x',
    name: 'All New BR-V N7X',
    model: 'BR-V N7X',
    category: 'MPV',
    priceRange: 'Rp 310 - 380 Juta',
    startingPrice: 310000000,
    typeCount: 3,
    year: 2024,
    images: {
        main: '/images/cars/all-new-br-v-n7x/main.jpg',
        gallery: [
            '/images/cars/all-new-br-v-n7x/gallery-1.jpg',
            '/images/cars/all-new-br-v-n7x/gallery-2.jpg',
            '/images/cars/all-new-br-v-n7x/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-br-v-n7x/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-br-v-n7x/colors/red.jpg',
            '/images/cars/all-new-br-v-n7x/colors/black.jpg',
            '/images/cars/all-new-br-v-n7x/colors/white.jpg'
        ]
    },
    variants: [
        {
            id: 'brv-n7x-premium',
            type: 'ALL NEW BR-V N7X PREMIUM',
            price: 380000000,
            priceFormatted: 'Rp 380.000.000',
            features: [
                '7-Seater Premium',
                'Full LED Headlights',
                '8-inch Touchscreen',
                'Leather Seats',
                '6 Airbags',
                'Honda SENSING'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    description: 'All New BR-V N7X adalah varian premium dengan fitur dan teknologi terkini untuk pengalaman berkendara yang lebih eksklusif.',
    shortDescription: 'Varian premium BR-V dengan fitur dan teknologi terkini.',
    tags: [
        'MPV',
        'Premium',
        '7-Seater',
        'Honda SENSING'
    ],
    isFeatured: true,
    isNew: true,
    views: 678,
    relatedCars: [
        'all-new-br-v',
        'all-new-cr-v'
    ],
    createdAt: '2024-02-10',
    updatedAt: '2024-02-10'
};
}),
"[project]/data/cars/index.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cars",
    ()=>cars
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brio$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/brio.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/hrv.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$crv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/crv.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$wrv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/wrv.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/brv.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civic$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/civic.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$accord$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/accord.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$stepwgn$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/stepwgn.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$cityhatchback$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/cityhatchback.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civictyper$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/civictyper.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrvehev$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/hrvehev.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$n7x$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/n7x.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const cars = [
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brio$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["brio"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["hrv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$crv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["crv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$wrv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["wrv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["brv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civic$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["civic"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$accord$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["accord"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$stepwgn$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["stepwgn"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$cityhatchback$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cityhatchback"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civictyper$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["civicTypeR"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrvehev$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["hrvehev"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$n7x$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["n7x"]
];
}),
"[project]/types/car.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Car Variant Type
__turbopack_context__.s([]);
;
}),
"[project]/data/index.ts [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAllCarSlugs",
    ()=>getAllCarSlugs,
    "getAllCars",
    ()=>getAllCars,
    "getCarBySlug",
    ()=>getCarBySlug,
    "getCarsByCategory",
    ()=>getCarsByCategory,
    "getCarsByPriceRange",
    ()=>getCarsByPriceRange,
    "getFeaturedCars",
    ()=>getFeaturedCars,
    "getNewCars",
    ()=>getNewCars,
    "searchCars",
    ()=>searchCars
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/index.ts [app-rsc] (ecmascript)");
// Export types
var __TURBOPACK__imported__module__$5b$project$5d2f$types$2f$car$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/types/car.ts [app-rsc] (ecmascript)");
;
;
const getCarBySlug = (slug)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].find((car)=>car.slug === slug);
};
const getFeaturedCars = ()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].filter((car)=>car.isFeatured);
};
const getNewCars = ()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].filter((car)=>car.isNew);
};
const getCarsByCategory = (category)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].filter((car)=>car.category === category);
};
const getAllCarSlugs = ()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].map((car)=>car.slug);
};
const getAllCars = ()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"];
};
const searchCars = (query)=>{
    const lowerQuery = query.toLowerCase();
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].filter((car)=>car.name.toLowerCase().includes(lowerQuery) || car.model.toLowerCase().includes(lowerQuery) || car.tags.some((tag)=>tag.toLowerCase().includes(lowerQuery)) || car.category.toLowerCase().includes(lowerQuery));
};
const getCarsByPriceRange = (min, max)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].filter((car)=>car.startingPrice >= min && car.startingPrice <= max);
};
;
}),
"[project]/components/cars/CarHero.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/CarHero.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/CarHero.tsx <module evaluation>", "default");
}),
"[project]/components/cars/CarHero.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/CarHero.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/CarHero.tsx", "default");
}),
"[project]/components/cars/CarHero.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/CarHero.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/CarHero.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/cars/CarQuickInfo.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarQuickInfo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function CarQuickInfo({ car }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "bg-white py-8 border-b border-gray-200",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-600 text-sm mb-1",
                                    children: "Kategori"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 14,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-semibold text-lg",
                                    children: car.category
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 15,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 13,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-600 text-sm mb-1",
                                    children: "Tahun"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 19,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-semibold text-lg",
                                    children: car.year
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 20,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-600 text-sm mb-1",
                                    children: "Tipe Tersedia"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 24,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-semibold text-lg",
                                    children: [
                                        car.typeCount,
                                        " Varian"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 25,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-600 text-sm mb-1",
                                    children: "Dilihat"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 29,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-semibold text-lg",
                                    children: [
                                        car.views,
                                        "x"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 30,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                    lineNumber: 11,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 text-center max-w-3xl mx-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-700 text-lg leading-relaxed",
                        children: car.description
                    }, void 0, false, {
                        fileName: "[project]/components/cars/CarQuickInfo.tsx",
                        lineNumber: 36,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                    lineNumber: 35,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/cars/CarQuickInfo.tsx",
            lineNumber: 10,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/cars/CarQuickInfo.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/VariantsTable.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/VariantsTable.tsx <module evaluation>", "default");
}),
"[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/VariantsTable.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/VariantsTable.tsx", "default");
}),
"[project]/components/cars/VariantsTable.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/CarFeaturesTabs.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/CarFeaturesTabs.tsx <module evaluation>", "default");
}),
"[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/CarFeaturesTabs.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/CarFeaturesTabs.tsx", "default");
}),
"[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/cars/VideoSection.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/VideoSection.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/VideoSection.tsx <module evaluation>", "default");
}),
"[project]/components/cars/VideoSection.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/VideoSection.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/VideoSection.tsx", "default");
}),
"[project]/components/cars/VideoSection.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VideoSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/VideoSection.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VideoSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/VideoSection.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VideoSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/cars/TestDriveCTA.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TestDriveCTA
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function TestDriveCTA({ car }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-16 bg-gradient-to-r from-blue-600 to-blue-700 text-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4 text-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-3xl mx-auto",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-3xl md:text-4xl font-bold mb-6",
                        children: [
                            "Rasakan Sensasi Mengendarai ",
                            car.name
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/TestDriveCTA.tsx",
                        lineNumber: 10,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xl mb-8 opacity-90",
                        children: [
                            "Jadwalkan test drive gratis dan rasakan langsung performa ",
                            car.name,
                            " bersama Rendy Honda"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/TestDriveCTA.tsx",
                        lineNumber: 13,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: `https://wa.me/6287852432636?text=${encodeURIComponent(`Halo Rendy, saya ingin jadwalkan test drive untuk ${car.name}. Kapan tersedia?`)}`,
                        className: "inline-flex items-center gap-3 bg-white text-blue-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-6 h-6",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M13 10V3L4 14h7v7l9-11h-7z"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/TestDriveCTA.tsx",
                                    lineNumber: 21,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/cars/TestDriveCTA.tsx",
                                lineNumber: 20,
                                columnNumber: 13
                            }, this),
                            "Jadwalkan Test Drive Gratis"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/TestDriveCTA.tsx",
                        lineNumber: 16,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/cars/TestDriveCTA.tsx",
                lineNumber: 9,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/cars/TestDriveCTA.tsx",
            lineNumber: 8,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/cars/TestDriveCTA.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/cars/ColorOptions.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/ColorOptions.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/ColorOptions.tsx <module evaluation>", "default");
}),
"[project]/components/cars/ColorOptions.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/ColorOptions.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/ColorOptions.tsx", "default");
}),
"[project]/components/cars/ColorOptions.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$ColorOptions$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/ColorOptions.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$ColorOptions$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/ColorOptions.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$ColorOptions$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/cars/SpecificationHighlights.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SpecificationHighlights
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function SpecificationHighlights({ specs }) {
    const highlights = [
        {
            label: 'Konsumsi BBM',
            value: specs.performance.fuelConsumption,
            icon: '⛽'
        },
        {
            label: 'Mesin',
            value: specs.performance.engine,
            icon: '⚙️'
        },
        {
            label: 'Tenaga',
            value: specs.performance.maxPower,
            icon: '🐎'
        },
        {
            label: 'Transmisi',
            value: specs.performance.transmission,
            icon: '🔧'
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-12 bg-white border-b",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-2 md:grid-cols-4 gap-6",
                children: highlights.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center p-6 bg-gray-50 rounded-xl",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-2xl mb-3",
                                children: item.icon
                            }, void 0, false, {
                                fileName: "[project]/components/cars/SpecificationHighlights.tsx",
                                lineNumber: 35,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-2xl font-bold text-gray-900 mb-2",
                                children: item.value
                            }, void 0, false, {
                                fileName: "[project]/components/cars/SpecificationHighlights.tsx",
                                lineNumber: 36,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-gray-600 font-medium",
                                children: item.label
                            }, void 0, false, {
                                fileName: "[project]/components/cars/SpecificationHighlights.tsx",
                                lineNumber: 37,
                                columnNumber: 15
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/components/cars/SpecificationHighlights.tsx",
                        lineNumber: 34,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/cars/SpecificationHighlights.tsx",
                lineNumber: 32,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/cars/SpecificationHighlights.tsx",
            lineNumber: 31,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/cars/SpecificationHighlights.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/mobil/[slug]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarDetailPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/data/index.ts [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarHero.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarQuickInfo$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarQuickInfo.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/VariantsTable.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VideoSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/VideoSection.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$TestDriveCTA$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/TestDriveCTA.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$ColorOptions$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/ColorOptions.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$SpecificationHighlights$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/SpecificationHighlights.tsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
async function CarDetailPage({ params }) {
    const { slug } = await params;
    const car = (0, __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getCarBySlug"])(slug);
    if (!car) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                car: car
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarQuickInfo$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                car: car
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$SpecificationHighlights$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                specs: car.specs
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            car.images.colorOptions && car.images.colorOptions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$ColorOptions$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                colors: car.images.colorOptions,
                carName: car.name
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 38,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VideoSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                videoUrl: car.videoUrl,
                title: `Video ${car.name}`,
                description: `Lihat keunggulan dan fitur-fitur terbaru ${car.name} dalam video berikut`
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "harga",
                className: "py-16 bg-gray-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center mb-12",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-3xl md:text-4xl font-bold text-gray-900 mb-4",
                                    children: [
                                        "Pilihan Varian & Harga ",
                                        car.name
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                    lineNumber: 55,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-lg text-gray-600 max-w-2xl mx-auto",
                                    children: "Temukan varian yang tepat sesuai kebutuhan dan budget Anda"
                                }, void 0, false, {
                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                    lineNumber: 58,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-24 h-1 bg-red-600 mx-auto mt-6 rounded-full"
                                }, void 0, false, {
                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                    lineNumber: 61,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                            variants: car.variants,
                            carName: car.name
                        }, void 0, false, {
                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                            lineNumber: 63,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                features: car.features,
                specs: car.specs
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 68,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$TestDriveCTA$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                car: car
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "relative bg-gradient-to-br from-red-600 via-red-500 to-red-700 text-white py-20 overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 opacity-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute top-0 left-0 w-72 h-72 bg-white rounded-full -translate-x-1/2 -translate-y-1/2"
                            }, void 0, false, {
                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                lineNumber: 77,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full translate-x-1/3 translate-y-1/3"
                            }, void 0, false, {
                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                lineNumber: 78,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container mx-auto px-4 text-center relative z-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-10",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-4xl md:text-5xl font-bold mb-6 tracking-tight",
                                        children: [
                                            "Siap Memiliki ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-yellow-300",
                                                children: car.name
                                            }, void 0, false, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 85,
                                                columnNumber: 29
                                            }, this),
                                            "?"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                        lineNumber: 84,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-32 h-1 bg-yellow-400 mx-auto mb-8 rounded-full"
                                    }, void 0, false, {
                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                        lineNumber: 87,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xl md:text-2xl mb-6 max-w-3xl mx-auto leading-relaxed font-light",
                                        children: "Jangan lewatkan penawaran spesial dan dapatkan harga terbaik langsung dari Rendy Honda"
                                    }, void 0, false, {
                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                        lineNumber: 88,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                lineNumber: 83,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white/10 backdrop-blur-sm rounded-2xl p-8 mb-10 max-w-2xl mx-auto border border-white/20",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col md:flex-row items-center justify-between gap-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-left",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-2xl font-bold text-yellow-300 mb-2",
                                                    children: "Harga Mulai"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 97,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-3xl md:text-4xl font-bold",
                                                    children: car.priceRange
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 100,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-red-100 mt-2",
                                                    children: [
                                                        car.typeCount,
                                                        " Varian Tersedia"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 103,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                            lineNumber: 96,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col gap-2 text-left",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            className: "w-5 h-5 text-green-400",
                                                            fill: "currentColor",
                                                            viewBox: "0 0 20 20",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                fillRule: "evenodd",
                                                                d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                                                                clipRule: "evenodd"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                                lineNumber: 110,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                            lineNumber: 109,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: "DP Ringan"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                            lineNumber: 112,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 108,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            className: "w-5 h-5 text-green-400",
                                                            fill: "currentColor",
                                                            viewBox: "0 0 20 20",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                fillRule: "evenodd",
                                                                d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                                                                clipRule: "evenodd"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                                lineNumber: 116,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                            lineNumber: 115,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: "Bunga Kompetitif"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                            lineNumber: 118,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 114,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            className: "w-5 h-5 text-green-400",
                                                            fill: "currentColor",
                                                            viewBox: "0 0 20 20",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                fillRule: "evenodd",
                                                                d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                                                                clipRule: "evenodd"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                                lineNumber: 122,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                            lineNumber: 121,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: "Proses Cepat"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                            lineNumber: 124,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 120,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                            lineNumber: 107,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                    lineNumber: 95,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                lineNumber: 94,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col sm:flex-row gap-6 justify-center items-center max-w-2xl mx-auto",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: `https://wa.me/6287852432636?text=${encodeURIComponent(`Halo Rendy, saya tertarik dengan ${car.name} ${car.model} ${car.year}. Bisa info detail harga ${car.priceRange}, spesifikasi, dan penawaran terbaiknya?`)}`,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "group bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-10 py-5 rounded-2xl font-bold text-lg shadow-2xl hover:shadow-3xl hover:scale-105 transition-all duration-300 w-full sm:w-auto flex items-center justify-center gap-4 border-2 border-green-400 min-w-[280px]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-7 h-7",
                                                        fill: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            d: "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893-.001-3.189-1.248-6.189-3.515-8.452"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                            lineNumber: 141,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                        lineNumber: 140,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "absolute -top-1 -right-1 flex gap-1",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-2 h-2 bg-white rounded-full animate-ping"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                            lineNumber: 144,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                        lineNumber: 143,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 139,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-lg",
                                                children: "Chat WhatsApp"
                                            }, void 0, false, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 147,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-5 h-5 transform group-hover:translate-x-1 transition-transform",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M13 7l5 5m0 0l-5 5m5-5H6"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 149,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 148,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                        lineNumber: 133,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col sm:flex-row gap-4 w-full sm:w-auto",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "tel:087852432636",
                                                className: "group bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white px-8 py-4 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 w-full sm:w-auto flex items-center justify-center gap-3 border border-white/20 hover:border-white/40 min-w-[200px]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-6 h-6",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: 2,
                                                            d: "M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                            lineNumber: 161,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                        lineNumber: 160,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Telepon"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                        lineNumber: 163,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 156,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: `https://wa.me/6287852432636?text=${encodeURIComponent(`Halo Rendy, saya ingin jadwalkan test drive untuk ${car.name} ${car.model}. Kapan tersedia?`)}`,
                                                className: "group bg-yellow-500 hover:bg-yellow-600 text-gray-900 px-8 py-4 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 w-full sm:w-auto flex items-center justify-center gap-3 border border-yellow-400 min-w-[200px]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-6 h-6",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: 2,
                                                            d: "M13 10V3L4 14h7v7l9-11h-7z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                            lineNumber: 172,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                        lineNumber: 171,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Test Drive"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                        lineNumber: 174,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 167,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                        lineNumber: 154,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                lineNumber: 131,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-12 text-sm text-red-100 flex flex-col sm:flex-row justify-center items-center gap-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-5 h-5",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 183,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 182,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-semibold",
                                                children: "Respon Cepat 24 Jam"
                                            }, void 0, false, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 185,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                        lineNumber: 181,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "hidden sm:block w-1 h-1 bg-red-300 rounded-full"
                                    }, void 0, false, {
                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                        lineNumber: 187,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-5 h-5",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 190,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 189,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-semibold",
                                                children: "Penawaran Terbaik"
                                            }, void 0, false, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 192,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                        lineNumber: 188,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "hidden sm:block w-1 h-1 bg-red-300 rounded-full"
                                    }, void 0, false, {
                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                        lineNumber: 194,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-5 h-5",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M13 10V3L4 14h7v7l9-11h-7z"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 197,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 196,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-semibold",
                                                children: "Test Drive Gratis"
                                            }, void 0, false, {
                                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                lineNumber: 199,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                        lineNumber: 195,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                lineNumber: 180,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-10 pt-8 border-t border-red-400/30",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-wrap justify-center items-center gap-8 text-red-200",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    className: "w-5 h-5",
                                                    fill: "currentColor",
                                                    viewBox: "0 0 20 20",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        fillRule: "evenodd",
                                                        d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                                                        clipRule: "evenodd"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                        lineNumber: 208,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 207,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "Sales Resmi Honda"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 210,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                            lineNumber: 206,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    className: "w-5 h-5",
                                                    fill: "currentColor",
                                                    viewBox: "0 0 20 20",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        fillRule: "evenodd",
                                                        d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                                                        clipRule: "evenodd"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                        lineNumber: 214,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 213,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "Berpengalaman"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 216,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                            lineNumber: 212,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    className: "w-5 h-5",
                                                    fill: "currentColor",
                                                    viewBox: "0 0 20 20",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        fillRule: "evenodd",
                                                        d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                                                        clipRule: "evenodd"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                        lineNumber: 220,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 219,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "Terpercaya"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                                    lineNumber: 222,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                                            lineNumber: 218,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                    lineNumber: 205,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/mobil/[slug]/page.tsx",
                                lineNumber: 204,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                        lineNumber: 81,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/mobil/[slug]/page.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/mobil/[slug]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/mobil/[slug]/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__fbb64768._.js.map