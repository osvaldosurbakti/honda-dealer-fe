module.exports = [
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/data/cars.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cars",
    ()=>cars,
    "getAllCarSlugs",
    ()=>getAllCarSlugs,
    "getAllCars",
    ()=>getAllCars,
    "getCarBySlug",
    ()=>getCarBySlug,
    "getCarsByCategory",
    ()=>getCarsByCategory,
    "getFeaturedCars",
    ()=>getFeaturedCars,
    "getNewCars",
    ()=>getNewCars
]);
const cars = [
    // Existing cars
    {
        id: 'hrv-2024',
        slug: 'new-hr-v',
        name: 'All New HR-V',
        model: 'HR-V',
        category: 'SUV',
        priceRange: 'Rp 403,8 - 492 Juta',
        startingPrice: 403800000,
        typeCount: 7,
        year: 2024,
        images: {
            main: '/images/cars/new-hr-v/main.jpg',
            gallery: [
                '/images/cars/new-hr-v/gallery-1.jpg',
                '/images/cars/new-hr-v/gallery-2.jpg',
                '/images/cars/new-hr-v/gallery-3.jpg',
                '/images/cars/new-hr-v/gallery-4.jpg'
            ],
            thumbnail: '/images/cars/new-hr-v/thumbnail.jpg',
            colorOptions: [
                '/images/cars/new-hr-v/colors/red.jpg',
                '/images/cars/new-hr-v/colors/black.jpg',
                '/images/cars/new-hr-v/colors/white.jpg',
                '/images/cars/new-hr-v/colors/gray.jpg'
            ]
        },
        variants: [
            {
                id: 'hrv-e-cvt',
                type: 'ALL NEW HR-V E CVT',
                price: 403800000,
                priceFormatted: 'Rp 403.800.000',
                features: [
                    'LED Headlights',
                    '7-inch Touchscreen Display',
                    'Keyless Entry',
                    '6 Airbags',
                    'Vehicle Stability Assist'
                ],
                transmission: 'CVT',
                fuelType: 'Bensin',
                engineCapacity: '1.5L',
                available: true
            },
            {
                id: 'hrv-e-plus-cvt',
                type: 'ALL NEW HR-V E+ CVT',
                price: 425900000,
                priceFormatted: 'Rp 425.900.000',
                features: [
                    'LED Headlights with DRL',
                    '8-inch Touchscreen Display',
                    'Push Start Button',
                    'Rear View Camera',
                    'Parking Sensors'
                ],
                transmission: 'CVT',
                fuelType: 'Bensin',
                engineCapacity: '1.5L',
                available: true
            },
            {
                id: 'hrv-e-hev',
                type: 'ALL NEW HR-V e:HEV',
                price: 452900000,
                priceFormatted: 'Rp 452.900.000',
                features: [
                    'Full LED Headlights',
                    'Hybrid System',
                    'Wireless Charger',
                    'Panoramic Sunroof',
                    'Honda SENSING'
                ],
                transmission: 'CVT',
                fuelType: 'Hybrid',
                engineCapacity: '1.5L',
                available: true
            }
        ],
        specs: {
            dimensions: {
                length: '4385 mm',
                width: '1790 mm',
                height: '1590 mm',
                wheelbase: '2610 mm',
                weight: '1250 kg'
            },
            performance: {
                engine: '1.5L DOHC i-VTEC',
                displacement: '1498 cc',
                maxPower: '121 PS / 6600 rpm',
                maxTorque: '145 Nm / 4300 rpm',
                transmission: 'CVT dengan Earth Dreams Technology',
                fuelConsumption: '17,8 km/L',
                acceleration: '0-100 km/h dalam 11.2 detik',
                topSpeed: '185 km/jam'
            },
            capacity: {
                seating: '5 Seater',
                fuelTank: '40 Liter',
                luggage: '430 Liter (dapat diperluas hingga 1.200 Liter)',
                doors: '5 Pintu'
            },
            features: {
                exterior: [
                    'LED Headlights',
                    'Power Retractable Mirrors',
                    '17-inch Alloy Wheels'
                ],
                interior: [
                    'Floating Touchscreen',
                    'Digital Cluster',
                    'Leather Seats'
                ],
                safety: [
                    '6 Airbags',
                    'ABS + EBD',
                    'Vehicle Stability Assist'
                ],
                entertainment: [
                    'Apple CarPlay',
                    'Android Auto',
                    '6 Speakers'
                ]
            }
        },
        features: {
            exterior: {
                title: 'Desain Eksterior Modern & Sporty',
                description: 'HR-V generasi baru dengan desain lebih maskulin dan sporty, berkat penggunaan panel front grille dengan desain lebih lebar dan tebal, sebagai latar dari logo Honda.',
                features: [
                    'Full LED Headlights dengan LED Light Guide',
                    'Two-Tone 17-inch Alloy Wheels',
                    'Power Retractable Side Mirrors',
                    'Chrome Front Grille',
                    'LED Fog Lamps'
                ],
                images: [
                    '/images/cars/new-hr-v/features/exterior-1.jpg',
                    '/images/cars/new-hr-v/features/exterior-2.jpg'
                ]
            },
            interior: {
                title: 'Interior Mewah & Nyaman',
                description: 'Kabin yang didesain dengan material premium dan teknologi terkini untuk kenyamanan maksimal pengemudi dan penumpang.',
                features: [
                    'Floating 8-inch Touchscreen Display',
                    'Digital Meter Cluster 7-inch',
                    'Leather Seats dengan Electric Adjustment',
                    'Dual Zone Automatic AC',
                    'Panoramic Sunroof'
                ],
                images: [
                    '/images/cars/new-hr-v/features/interior-1.jpg',
                    '/images/cars/new-hr-v/features/interior-2.jpg'
                ]
            },
            safety: {
                title: 'Teknologi Keselamatan Terkini',
                description: 'Dilengkapi dengan Honda SENSING, suite teknologi keselamatan canggih yang memberikan perlindungan maksimal.',
                features: [
                    'Honda SENSING Safety Suite',
                    '6 SRS Airbags',
                    'Anti-lock Braking System (ABS)',
                    'Vehicle Stability Assist (VSA)',
                    'Hill Start Assist'
                ],
                images: [
                    '/images/cars/new-hr-v/features/safety-1.jpg',
                    '/images/cars/new-hr-v/features/safety-2.jpg'
                ]
            }
        },
        description: 'All New HR-V dengan desain terbaru yang lebih sporty dan teknologi canggih. SUV kompak yang sempurna untuk keluarga modern.',
        shortDescription: 'SUV kompak dengan desain modern dan teknologi canggih untuk keluarga urban.',
        tags: [
            'SUV',
            'Family',
            'City Car',
            'Hybrid',
            'Honda SENSING'
        ],
        isFeatured: true,
        isNew: true,
        views: 1247,
        relatedCars: [
            'new-cr-v',
            'new-br-v',
            'wr-v'
        ],
        createdAt: '2024-01-15',
        updatedAt: '2024-01-15'
    },
    {
        id: 'brio-2024',
        slug: 'all-new-brio',
        name: 'All New Brio',
        model: 'Brio',
        category: 'Hatchback',
        priceRange: 'Rp 182,1 - 250 Juta',
        startingPrice: 182100000,
        typeCount: 5,
        year: 2024,
        images: {
            main: '/images/cars/all-new-brio/main.jpg',
            gallery: [
                '/images/cars/all-new-brio/gallery-1.jpg',
                '/images/cars/all-new-brio/gallery-2.jpg',
                '/images/cars/all-new-brio/gallery-3.jpg'
            ],
            thumbnail: '/images/cars/all-new-brio/thumbnail.jpg',
            colorOptions: [
                '/images/cars/all-new-brio/colors/red.jpg',
                '/images/cars/all-new-brio/colors/blue.jpg',
                '/images/cars/all-new-brio/colors/white.jpg'
            ]
        },
        variants: [
            {
                id: 'brio-s-mt',
                type: 'ALL NEW BRIO S MT',
                price: 182100000,
                priceFormatted: 'Rp 182.100.000',
                features: [
                    'Front Dual SRS Airbags',
                    'ABS dengan EBD',
                    'Power Steering',
                    'AC Manual',
                    'Audio dengan USB'
                ],
                transmission: 'Manual',
                fuelType: 'Bensin',
                engineCapacity: '1.2L',
                available: true
            },
            {
                id: 'brio-rs-mt',
                type: 'ALL NEW BRIO RS MT',
                price: 215500000,
                priceFormatted: 'Rp 215.500.000',
                features: [
                    'RS Body Kit',
                    'Front Fog Lamps',
                    '14-inch Alloy Wheels',
                    'Touchscreen Audio',
                    'Rear Parking Sensor'
                ],
                transmission: 'Manual',
                fuelType: 'Bensin',
                engineCapacity: '1.2L',
                available: true
            }
        ],
        specs: {
            dimensions: {
                length: '3610 mm',
                width: '1680 mm',
                height: '1500 mm',
                wheelbase: '2345 mm',
                weight: '890 kg'
            },
            performance: {
                engine: '1.2L SOHC i-VTEC',
                displacement: '1198 cc',
                maxPower: '90 PS / 6000 rpm',
                maxTorque: '110 Nm / 4800 rpm',
                transmission: '5-speed Manual',
                fuelConsumption: '20,0 km/L',
                acceleration: '0-100 km/h dalam 13.5 detik',
                topSpeed: '160 km/jam'
            },
            capacity: {
                seating: '5 Seater',
                fuelTank: '35 Liter',
                luggage: '258 Liter',
                doors: '5 Pintu'
            }
        },
        description: 'All New Brio adalah hatchback kompak yang sempurna untuk mobilitas perkotaan. Dengan desain yang fun dan youthful.',
        shortDescription: 'Hatchback kompak yang fun dan efisien untuk mobilitas perkotaan.',
        tags: [
            'Hatchback',
            'City Car',
            'Economical',
            'Compact'
        ],
        isFeatured: true,
        isNew: true,
        views: 865,
        relatedCars: [
            'new-hr-v',
            'wr-v'
        ],
        createdAt: '2024-01-10',
        updatedAt: '2024-01-10'
    },
    {
        id: 'crv-2024',
        slug: 'all-new-cr-v',
        name: 'All New CR-V',
        model: 'CR-V',
        category: 'SUV',
        priceRange: 'Rp 828,7 - 950 Juta',
        startingPrice: 828700000,
        typeCount: 3,
        year: 2024,
        images: {
            main: '/images/cars/all-new-cr-v/main.jpg',
            gallery: [
                '/images/cars/all-new-cr-v/gallery-1.jpg',
                '/images/cars/all-new-cr-v/gallery-2.jpg',
                '/images/cars/all-new-cr-v/gallery-3.jpg',
                '/images/cars/all-new-cr-v/gallery-4.jpg'
            ],
            thumbnail: '/images/cars/all-new-cr-v/thumbnail.jpg',
            colorOptions: [
                '/images/cars/all-new-cr-v/colors/black.jpg',
                '/images/cars/all-new-cr-v/colors/white.jpg',
                '/images/cars/all-new-cr-v/colors/silver.jpg',
                '/images/cars/all-new-cr-v/colors/blue.jpg'
            ]
        },
        variants: [
            {
                id: 'crv-e-cvt',
                type: 'ALL NEW CR-V E CVT',
                price: 828700000,
                priceFormatted: 'Rp 828.700.000',
                features: [
                    'LED Headlights dengan DRL',
                    '18-inch Alloy Wheels',
                    '7-inch Touchscreen',
                    'Honda SENSING',
                    'Electric Parking Brake'
                ],
                transmission: 'CVT',
                fuelType: 'Bensin',
                engineCapacity: '1.5L Turbo',
                available: true
            },
            {
                id: 'crv-e-hev',
                type: 'ALL NEW CR-V e:HEV',
                price: 899000000,
                priceFormatted: 'Rp 899.000.000',
                features: [
                    'Full LED Headlights',
                    'Hybrid System',
                    '9-inch Touchscreen',
                    'Wireless Charger',
                    'Panoramic Sunroof'
                ],
                transmission: 'CVT',
                fuelType: 'Hybrid',
                engineCapacity: '2.0L',
                available: true
            }
        ],
        description: 'All New CR-V adalah SUV premium dengan desain yang elegan dan teknologi canggih. Menawarkan kenyamanan terbaik dan fitur keselamatan terlengkap.',
        shortDescription: 'SUV premium dengan teknologi canggih dan kenyamanan terbaik untuk keluarga.',
        tags: [
            'SUV',
            'Premium',
            'Family',
            '7-Seater',
            'Hybrid'
        ],
        isFeatured: true,
        isNew: true,
        views: 892,
        relatedCars: [
            'new-hr-v',
            'new-br-v'
        ],
        createdAt: '2024-01-20',
        updatedAt: '2024-01-20'
    },
    // New cars
    {
        id: 'wrv-2024',
        slug: 'all-new-wr-v',
        name: 'All New WR-V',
        model: 'WR-V',
        category: 'SUV',
        priceRange: 'Rp 320 - 380 Juta',
        startingPrice: 320000000,
        typeCount: 4,
        year: 2024,
        images: {
            main: '/images/cars/all-new-wr-v/main.jpg',
            gallery: [
                '/images/cars/all-new-wr-v/gallery-1.jpg',
                '/images/cars/all-new-wr-v/gallery-2.jpg',
                '/images/cars/all-new-wr-v/gallery-3.jpg'
            ],
            thumbnail: '/images/cars/all-new-wr-v/thumbnail.jpg',
            colorOptions: [
                '/images/cars/all-new-wr-v/colors/red.jpg',
                '/images/cars/all-new-wr-v/colors/black.jpg',
                '/images/cars/all-new-wr-v/colors/white.jpg'
            ]
        },
        variants: [
            {
                id: 'wrv-e-cvt',
                type: 'ALL NEW WR-V E CVT',
                price: 320000000,
                priceFormatted: 'Rp 320.000.000',
                features: [
                    'LED Headlights',
                    '7-inch Touchscreen',
                    'Keyless Entry',
                    '4 Airbags',
                    'Rear Camera'
                ],
                transmission: 'CVT',
                fuelType: 'Bensin',
                engineCapacity: '1.5L',
                available: true
            }
        ],
        description: 'All New WR-V menghadirkan SUV compact dengan desain adventurous dan kapabilitas tangguh untuk petualangan urban.',
        shortDescription: 'SUV compact dengan desain adventurous untuk petualangan urban.',
        tags: [
            'SUV',
            'Adventure',
            'Compact',
            'Urban'
        ],
        isFeatured: true,
        isNew: true,
        views: 756,
        relatedCars: [
            'all-new-brio',
            'new-hr-v'
        ],
        createdAt: '2024-02-01',
        updatedAt: '2024-02-01'
    },
    {
        id: 'brv-2024',
        slug: 'all-new-br-v',
        name: 'All New BR-V',
        model: 'BR-V',
        category: 'MPV',
        priceRange: 'Rp 280 - 350 Juta',
        startingPrice: 280000000,
        typeCount: 5,
        year: 2024,
        images: {
            main: '/images/cars/all-new-br-v/main.jpg',
            gallery: [
                '/images/cars/all-new-br-v/gallery-1.jpg',
                '/images/cars/all-new-br-v/gallery-2.jpg',
                '/images/cars/all-new-br-v/gallery-3.jpg'
            ],
            thumbnail: '/images/cars/all-new-br-v/thumbnail.jpg',
            colorOptions: [
                '/images/cars/all-new-br-v/colors/white.jpg',
                '/images/cars/all-new-br-v/colors/black.jpg',
                '/images/cars/all-new-br-v/colors/silver.jpg'
            ]
        },
        variants: [
            {
                id: 'brv-e-cvt',
                type: 'ALL NEW BR-V E CVT',
                price: 280000000,
                priceFormatted: 'Rp 280.000.000',
                features: [
                    '7-Seater',
                    'LED Headlights',
                    'Touchscreen Display',
                    'Rear AC',
                    '4 Airbags'
                ],
                transmission: 'CVT',
                fuelType: 'Bensin',
                engineCapacity: '1.5L',
                available: true
            }
        ],
        description: 'All New BR-V adalah MPV 7-seater dengan desain sporty dan ruang kabin yang luas, cocok untuk keluarga besar.',
        shortDescription: 'MPV 7-seater dengan desain sporty dan ruang luas untuk keluarga.',
        tags: [
            'MPV',
            '7-Seater',
            'Family',
            'Spacious'
        ],
        isFeatured: true,
        isNew: true,
        views: 923,
        relatedCars: [
            'all-new-cr-v',
            'all-new-hr-v'
        ],
        createdAt: '2024-02-05',
        updatedAt: '2024-02-05'
    },
    {
        id: 'brv-n7x-2024',
        slug: 'all-new-br-v-n7x',
        name: 'All New BR-V N7X',
        model: 'BR-V N7X',
        category: 'MPV',
        priceRange: 'Rp 310 - 380 Juta',
        startingPrice: 310000000,
        typeCount: 3,
        year: 2024,
        images: {
            main: '/images/cars/all-new-br-v-n7x/main.jpg',
            gallery: [
                '/images/cars/all-new-br-v-n7x/gallery-1.jpg',
                '/images/cars/all-new-br-v-n7x/gallery-2.jpg',
                '/images/cars/all-new-br-v-n7x/gallery-3.jpg'
            ],
            thumbnail: '/images/cars/all-new-br-v-n7x/thumbnail.jpg',
            colorOptions: [
                '/images/cars/all-new-br-v-n7x/colors/red.jpg',
                '/images/cars/all-new-br-v-n7x/colors/black.jpg',
                '/images/cars/all-new-br-v-n7x/colors/white.jpg'
            ]
        },
        variants: [
            {
                id: 'brv-n7x-premium',
                type: 'ALL NEW BR-V N7X PREMIUM',
                price: 380000000,
                priceFormatted: 'Rp 380.000.000',
                features: [
                    '7-Seater Premium',
                    'Full LED Headlights',
                    '8-inch Touchscreen',
                    'Leather Seats',
                    '6 Airbags',
                    'Honda SENSING'
                ],
                transmission: 'CVT',
                fuelType: 'Bensin',
                engineCapacity: '1.5L',
                available: true
            }
        ],
        description: 'All New BR-V N7X adalah varian premium dengan fitur dan teknologi terkini untuk pengalaman berkendara yang lebih eksklusif.',
        shortDescription: 'Varian premium BR-V dengan fitur dan teknologi terkini.',
        tags: [
            'MPV',
            'Premium',
            '7-Seater',
            'Honda SENSING'
        ],
        isFeatured: true,
        isNew: true,
        views: 678,
        relatedCars: [
            'all-new-br-v',
            'all-new-cr-v'
        ],
        createdAt: '2024-02-10',
        updatedAt: '2024-02-10'
    },
    {
        id: 'hrv-e-hev-2024',
        slug: 'all-new-hr-v-e-hev',
        name: 'All New HR-V e:HEV',
        model: 'HR-V e:HEV',
        category: 'SUV',
        priceRange: 'Rp 450 - 500 Juta',
        startingPrice: 450000000,
        typeCount: 2,
        year: 2024,
        images: {
            main: '/images/cars/all-new-hr-v-e-hev/main.jpg',
            gallery: [
                '/images/cars/all-new-hr-v-e-hev/gallery-1.jpg',
                '/images/cars/all-new-hr-v-e-hev/gallery-2.jpg',
                '/images/cars/all-new-hr-v-e-hev/gallery-3.jpg'
            ],
            thumbnail: '/images/cars/all-new-hr-v-e-hev/thumbnail.jpg',
            colorOptions: [
                '/images/cars/all-new-hr-v-e-hev/colors/blue.jpg',
                '/images/cars/all-new-hr-v-e-hev/colors/white.jpg',
                '/images/cars/all-new-hr-v-e-hev/colors/gray.jpg'
            ]
        },
        variants: [
            {
                id: 'hrv-e-hev-premium',
                type: 'ALL NEW HR-V e:HEV PREMIUM',
                price: 500000000,
                priceFormatted: 'Rp 500.000.000',
                features: [
                    'Hybrid System',
                    'Full LED Headlights',
                    'Panoramic Sunroof',
                    'Wireless Charger',
                    'Honda SENSING',
                    'Leather Seats'
                ],
                transmission: 'CVT',
                fuelType: 'Hybrid',
                engineCapacity: '1.5L',
                available: true
            }
        ],
        description: 'All New HR-V e:HEV menghadirkan teknologi hybrid terbaru dengan efisiensi bahan bakar yang excellent dan performa responsif.',
        shortDescription: 'SUV hybrid dengan efisiensi bahan bakar excellent dan performa responsif.',
        tags: [
            'SUV',
            'Hybrid',
            'Eco-Friendly',
            'Premium'
        ],
        isFeatured: true,
        isNew: true,
        views: 1123,
        relatedCars: [
            'new-hr-v',
            'all-new-cr-v'
        ],
        createdAt: '2024-02-15',
        updatedAt: '2024-02-15'
    },
    {
        id: 'stepwgn-e-hev-2024',
        slug: 'stepwgn-e-hev',
        name: 'Stepwgn e:HEV',
        model: 'Stepwgn',
        category: 'MPV',
        priceRange: 'Rp 650 - 750 Juta',
        startingPrice: 650000000,
        typeCount: 3,
        year: 2024,
        images: {
            main: '/images/cars/stepwgn-e-hev/main.jpg',
            gallery: [
                '/images/cars/stepwgn-e-hev/gallery-1.jpg',
                '/images/cars/stepwgn-e-hev/gallery-2.jpg',
                '/images/cars/stepwgn-e-hev/gallery-3.jpg'
            ],
            thumbnail: '/images/cars/stepwgn-e-hev/thumbnail.jpg',
            colorOptions: [
                '/images/cars/stepwgn-e-hev/colors/white.jpg',
                '/images/cars/stepwgn-e-hev/colors/black.jpg',
                '/images/cars/stepwgn-e-hev/colors/silver.jpg'
            ]
        },
        variants: [
            {
                id: 'stepwgn-e-hev-premium',
                type: 'STEPWGN e:HEV PREMIUM',
                price: 750000000,
                priceFormatted: 'Rp 750.000.000',
                features: [
                    '8-Seater Hybrid',
                    'Magic Seats',
                    'Dual Power Sliding Doors',
                    'Panoramic Roof',
                    'Honda SENSING 360',
                    '11.4-inch Touchscreen'
                ],
                transmission: 'CVT',
                fuelType: 'Hybrid',
                engineCapacity: '2.0L',
                available: true
            }
        ],
        description: 'Stepwgn e:HEV adalah MPV keluarga premium dengan teknologi hybrid dan konfigurasi kursi Magic Seats yang fleksibel.',
        shortDescription: 'MPV keluarga premium hybrid dengan Magic Seats yang fleksibel.',
        tags: [
            'MPV',
            'Hybrid',
            '8-Seater',
            'Premium',
            'Family'
        ],
        isFeatured: true,
        isNew: true,
        views: 834,
        relatedCars: [
            'all-new-br-v',
            'all-new-cr-v'
        ],
        createdAt: '2024-02-20',
        updatedAt: '2024-02-20'
    },
    {
        id: 'civic-e-hev-rs-2024',
        slug: 'all-new-civic-e-hev-rs',
        name: 'All New Civic e:HEV RS',
        model: 'Civic',
        category: 'Sedan',
        priceRange: 'Rp 680 - 750 Juta',
        startingPrice: 680000000,
        typeCount: 2,
        year: 2024,
        images: {
            main: '/images/cars/all-new-civic-e-hev-rs/main.jpg',
            gallery: [
                '/images/cars/all-new-civic-e-hev-rs/gallery-1.jpg',
                '/images/cars/all-new-civic-e-hev-rs/gallery-2.jpg',
                '/images/cars/all-new-civic-e-hev-rs/gallery-3.jpg'
            ],
            thumbnail: '/images/cars/all-new-civic-e-hev-rs/thumbnail.jpg',
            colorOptions: [
                '/images/cars/all-new-civic-e-hev-rs/colors/red.jpg',
                '/images/cars/all-new-civic-e-hev-rs/colors/black.jpg',
                '/images/cars/all-new-civic-e-hev-rs/colors/white.jpg'
            ]
        },
        variants: [
            {
                id: 'civic-e-hev-rs',
                type: 'ALL NEW CIVIC e:HEV RS',
                price: 750000000,
                priceFormatted: 'Rp 750.000.000',
                features: [
                    'RS Body Kit',
                    'Hybrid System',
                    'Full LED Headlights',
                    '10.2-inch Digital Cluster',
                    'Bose Premium Audio',
                    'Honda SENSING'
                ],
                transmission: 'CVT',
                fuelType: 'Hybrid',
                engineCapacity: '2.0L',
                available: true
            }
        ],
        description: 'All New Civic e:HEV RS menghadirkan sedan sport hybrid dengan performa tangguh dan desain agresif khas RS.',
        shortDescription: 'Sedan sport hybrid dengan desain agresif khas RS dan performa tangguh.',
        tags: [
            'Sedan',
            'Hybrid',
            'Sport',
            'RS',
            'Premium'
        ],
        isFeatured: true,
        isNew: true,
        views: 1567,
        relatedCars: [
            'all-new-civic-type-r',
            'city-hatchback-rs'
        ],
        createdAt: '2024-02-25',
        updatedAt: '2024-02-25'
    },
    {
        id: 'city-hatchback-rs-2024',
        slug: 'city-hatchback-rs',
        name: 'City Hatchback RS',
        model: 'City',
        category: 'Hatchback',
        priceRange: 'Rp 350 - 420 Juta',
        startingPrice: 350000000,
        typeCount: 3,
        year: 2024,
        images: {
            main: '/images/cars/city-hatchback-rs/main.jpg',
            gallery: [
                '/images/cars/city-hatchback-rs/gallery-1.jpg',
                '/images/cars/city-hatchback-rs/gallery-2.jpg',
                '/images/cars/city-hatchback-rs/gallery-3.jpg'
            ],
            thumbnail: '/images/cars/city-hatchback-rs/thumbnail.jpg',
            colorOptions: [
                '/images/cars/city-hatchback-rs/colors/red.jpg',
                '/images/cars/city-hatchback-rs/colors/black.jpg',
                '/images/cars/city-hatchback-rs/colors/white.jpg'
            ]
        },
        variants: [
            {
                id: 'city-hatchback-rs-premium',
                type: 'CITY HATCHBACK RS PREMIUM',
                price: 420000000,
                priceFormatted: 'Rp 420.000.000',
                features: [
                    'RS Body Kit',
                    'LED Headlights dengan DRL',
                    '8-inch Touchscreen',
                    'Apple CarPlay & Android Auto',
                    '6 Airbags',
                    'Push Start Button'
                ],
                transmission: 'CVT',
                fuelType: 'Bensin',
                engineCapacity: '1.5L',
                available: true
            }
        ],
        description: 'City Hatchback RS menghadirkan hatchback sporty dengan desain agresif khas RS dan fitur lengkap untuk mobilitas urban.',
        shortDescription: 'Hatchback sporty dengan desain agresif khas RS untuk mobilitas urban.',
        tags: [
            'Hatchback',
            'Sport',
            'RS',
            'City Car',
            'Premium'
        ],
        isFeatured: true,
        isNew: true,
        views: 987,
        relatedCars: [
            'all-new-brio',
            'all-new-civic-e-hev-rs'
        ],
        createdAt: '2024-03-01',
        updatedAt: '2024-03-01'
    },
    {
        id: 'civic-type-r-2024',
        slug: 'all-new-civic-type-r',
        name: 'All New Civic Type R',
        model: 'Civic Type R',
        category: 'Sport',
        priceRange: 'Rp 1,2 - 1,5 Miliar',
        startingPrice: 1200000000,
        typeCount: 1,
        year: 2024,
        images: {
            main: '/images/cars/all-new-civic-type-r/main.jpg',
            gallery: [
                '/images/cars/all-new-civic-type-r/gallery-1.jpg',
                '/images/cars/all-new-civic-type-r/gallery-2.jpg',
                '/images/cars/all-new-civic-type-r/gallery-3.jpg'
            ],
            thumbnail: '/images/cars/all-new-civic-type-r/thumbnail.jpg',
            colorOptions: [
                '/images/cars/all-new-civic-type-r/colors/red.jpg',
                '/images/cars/all-new-civic-type-r/colors/white.jpg',
                '/images/cars/all-new-civic-type-r/colors/blue.jpg'
            ]
        },
        variants: [
            {
                id: 'civic-type-r',
                type: 'ALL NEW CIVIC TYPE R',
                price: 1500000000,
                priceFormatted: 'Rp 1.500.000.000',
                features: [
                    '2.0L VTEC Turbo Engine',
                    '6-speed Manual Transmission',
                    'Racing Bucket Seats',
                    'Brembo Brakes',
                    '20-inch Alloy Wheels',
                    'Type R Body Kit'
                ],
                transmission: 'Manual',
                fuelType: 'Bensin',
                engineCapacity: '2.0L Turbo',
                available: true
            }
        ],
        description: 'All New Civic Type R adalah hatchback performa tinggi dengan teknologi balap terbaru, memberikan pengalaman berkendara yang ekstrem dan mendebarkan.',
        shortDescription: 'Hatchback performa tinggi dengan teknologi balap untuk pengalaman berkendara ekstrem.',
        tags: [
            'Sport',
            'Performance',
            'Type R',
            'Turbo',
            'Racing'
        ],
        isFeatured: true,
        isNew: true,
        views: 2345,
        relatedCars: [
            'all-new-civic-e-hev-rs',
            'city-hatchback-rs'
        ],
        createdAt: '2024-03-05',
        updatedAt: '2024-03-05'
    }
];
const getCarBySlug = (slug)=>{
    return cars.find((car)=>car.slug === slug);
};
const getFeaturedCars = ()=>{
    return cars.filter((car)=>car.isFeatured);
};
const getNewCars = ()=>{
    return cars.filter((car)=>car.isNew);
};
const getCarsByCategory = (category)=>{
    return cars.filter((car)=>car.category === category);
};
const getAllCarSlugs = ()=>{
    return cars.map((car)=>car.slug);
};
const getAllCars = ()=>{
    return cars;
};
}),
"[project]/components/cars/CarHero.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarHero
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/phone.js [app-rsc] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-rsc] (ecmascript) <export default as MessageCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/settings.js [app-rsc] (ecmascript) <export default as Settings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$fuel$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Fuel$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/fuel.js [app-rsc] (ecmascript) <export default as Fuel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/users.js [app-rsc] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$luggage$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Luggage$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/luggage.js [app-rsc] (ecmascript) <export default as Luggage>");
;
;
;
;
function CarHero({ car }) {
    // Fallback image URL
    const fallbackImage = 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=800&h=600&fit=crop';
    // Fallback values untuk data yang optional
    const transmission = car.variants[0]?.transmission || 'CVT';
    const fuelType = car.variants[0]?.fuelType || 'Bensin';
    const seating = car.specs?.capacity?.seating || '5 Seater';
    const luggage = car.specs?.capacity?.luggage || '400 Liter';
    const startingPrice = car.variants[0]?.priceFormatted || `Rp ${car.startingPrice.toLocaleString('id-ID')}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "jsx-4ff5c963f8d25c47" + " " + "bg-gray-900 text-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-4ff5c963f8d25c47" + " " + "container mx-auto px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "jsx-4ff5c963f8d25c47" + " " + "flex flex-col lg:flex-row items-center py-6 lg:py-12",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-4ff5c963f8d25c47" + " " + "w-full lg:w-1/2 mb-6 lg:mb-0 lg:pr-8",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-4ff5c963f8d25c47" + " " + "relative h-64 sm:h-80 lg:h-96 bg-gray-800 rounded-xl lg:rounded-2xl overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                        src: car.images.main || fallbackImage,
                                        alt: car.name,
                                        fill: true,
                                        className: "object-cover",
                                        priority: true
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarHero.tsx",
                                        lineNumber: 27,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-4ff5c963f8d25c47" + " " + "absolute top-3 left-3 lg:top-4 lg:left-4 flex flex-col space-y-2",
                                        children: [
                                            car.isNew && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-4ff5c963f8d25c47" + " " + "bg-green-500 text-white text-xs sm:text-sm px-2 sm:px-3 py-1 rounded-full font-semibold",
                                                children: "NEW"
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarHero.tsx",
                                                lineNumber: 38,
                                                columnNumber: 19
                                            }, this),
                                            car.isFeatured && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-4ff5c963f8d25c47" + " " + "bg-red-600 text-white text-xs sm:text-sm px-2 sm:px-3 py-1 rounded-full font-semibold",
                                                children: "FEATURED"
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarHero.tsx",
                                                lineNumber: 43,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/cars/CarHero.tsx",
                                        lineNumber: 36,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-4ff5c963f8d25c47" + " " + "absolute top-3 right-3 lg:top-4 lg:right-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "jsx-4ff5c963f8d25c47" + " " + "bg-gray-900/80 text-white text-xs sm:text-sm px-2 sm:px-3 py-1 rounded-full font-semibold",
                                            children: car.category
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/CarHero.tsx",
                                            lineNumber: 51,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarHero.tsx",
                                        lineNumber: 50,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-4ff5c963f8d25c47" + " " + "absolute bottom-3 left-3 lg:bottom-4 lg:left-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "jsx-4ff5c963f8d25c47" + " " + "bg-black/70 text-white text-xs sm:text-sm px-2 sm:px-3 py-1 rounded-full",
                                            children: car.year
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/CarHero.tsx",
                                            lineNumber: 58,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarHero.tsx",
                                        lineNumber: 57,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/CarHero.tsx",
                                lineNumber: 26,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/cars/CarHero.tsx",
                            lineNumber: 25,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-4ff5c963f8d25c47" + " " + "w-full lg:w-1/2 text-center lg:text-left",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-4ff5c963f8d25c47" + " " + "text-sm text-gray-400 mb-3 lg:mb-4",
                                    children: [
                                        "Home / Mobil / ",
                                        car.category,
                                        " / ",
                                        car.name
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarHero.tsx",
                                    lineNumber: 68,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "jsx-4ff5c963f8d25c47" + " " + "text-2xl sm:text-3xl lg:text-5xl font-bold mb-3 lg:mb-4",
                                    children: car.name
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarHero.tsx",
                                    lineNumber: 72,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "jsx-4ff5c963f8d25c47" + " " + "text-base sm:text-lg lg:text-xl text-gray-300 mb-4 lg:mb-6 leading-relaxed",
                                    children: car.shortDescription
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarHero.tsx",
                                    lineNumber: 76,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-4ff5c963f8d25c47" + " " + "mb-6 lg:mb-8",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-4ff5c963f8d25c47" + " " + "flex lg:grid lg:grid-cols-4 gap-3 lg:gap-4 overflow-x-auto pb-2 lg:pb-0 hide-scrollbar",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-4ff5c963f8d25c47" + " " + "flex-shrink-0 w-32 lg:w-auto bg-gray-800/50 rounded-lg p-3 lg:p-0 lg:bg-transparent",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex flex-col items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"], {
                                                            className: "w-6 h-6 lg:w-8 lg:h-8 text-red-500 mb-1 lg:mb-2"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 86,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-xs lg:text-sm text-gray-400 mb-1",
                                                            children: "Transmisi"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 87,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-sm lg:text-base font-semibold",
                                                            children: transmission
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 88,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 85,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarHero.tsx",
                                                lineNumber: 84,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-4ff5c963f8d25c47" + " " + "flex-shrink-0 w-32 lg:w-auto bg-gray-800/50 rounded-lg p-3 lg:p-0 lg:bg-transparent",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex flex-col items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$fuel$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Fuel$3e$__["Fuel"], {
                                                            className: "w-6 h-6 lg:w-8 lg:h-8 text-blue-500 mb-1 lg:mb-2"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 95,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-xs lg:text-sm text-gray-400 mb-1",
                                                            children: "Bahan Bakar"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 96,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-sm lg:text-base font-semibold",
                                                            children: fuelType
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 97,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 94,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarHero.tsx",
                                                lineNumber: 93,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-4ff5c963f8d25c47" + " " + "flex-shrink-0 w-32 lg:w-auto bg-gray-800/50 rounded-lg p-3 lg:p-0 lg:bg-transparent",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex flex-col items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                                            className: "w-6 h-6 lg:w-8 lg:h-8 text-green-500 mb-1 lg:mb-2"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 104,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-xs lg:text-sm text-gray-400 mb-1",
                                                            children: "Kapasitas"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 105,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-sm lg:text-base font-semibold",
                                                            children: seating
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 106,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 103,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarHero.tsx",
                                                lineNumber: 102,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-4ff5c963f8d25c47" + " " + "flex-shrink-0 w-32 lg:w-auto bg-gray-800/50 rounded-lg p-3 lg:p-0 lg:bg-transparent",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex flex-col items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$luggage$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Luggage$3e$__["Luggage"], {
                                                            className: "w-6 h-6 lg:w-8 lg:h-8 text-yellow-500 mb-1 lg:mb-2"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 113,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-xs lg:text-sm text-gray-400 mb-1",
                                                            children: "Bagasi"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 114,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-sm lg:text-base font-semibold",
                                                            children: luggage
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 115,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 112,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarHero.tsx",
                                                lineNumber: 111,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/cars/CarHero.tsx",
                                        lineNumber: 82,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarHero.tsx",
                                    lineNumber: 81,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-4ff5c963f8d25c47" + " " + "mb-6 lg:mb-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-gray-400 text-sm mb-2",
                                            children: "Harga Mulai Dari"
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/CarHero.tsx",
                                            lineNumber: 123,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-2xl sm:text-3xl lg:text-4xl font-bold text-red-600",
                                            children: startingPrice
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/CarHero.tsx",
                                            lineNumber: 124,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-gray-400 text-xs sm:text-sm mt-1",
                                            children: [
                                                car.priceRange,
                                                " • ",
                                                car.typeCount,
                                                " tipe tersedia"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/CarHero.tsx",
                                            lineNumber: 127,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarHero.tsx",
                                    lineNumber: 122,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex flex-col sm:flex-row gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: "#variants",
                                            className: "jsx-4ff5c963f8d25c47" + " " + "flex-1 bg-red-600 text-white px-4 sm:px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition text-center flex items-center justify-center gap-2 group",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "jsx-4ff5c963f8d25c47",
                                                    children: "Lihat Semua Tipe"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 138,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    fill: "none",
                                                    stroke: "currentColor",
                                                    viewBox: "0 0 24 24",
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "w-4 h-4 group-hover:translate-x-1 transition-transform",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round",
                                                        strokeWidth: 2,
                                                        d: "M9 5l7 7-7 7",
                                                        className: "jsx-4ff5c963f8d25c47"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/cars/CarHero.tsx",
                                                        lineNumber: 145,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 139,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/CarHero.tsx",
                                            lineNumber: 134,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "jsx-4ff5c963f8d25c47" + " " + "flex flex-row gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: `https://wa.me/6287852432636?text=${encodeURIComponent(`Halo, saya tertarik dengan ${car.name} ${car.year}. Bisa info detail dan test drive?`)}`,
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex-1 bg-green-500 text-white px-4 py-3 rounded-lg font-semibold hover:bg-green-600 transition text-center flex items-center justify-center gap-2 group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                                                            className: "w-4 h-4"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 156,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "hidden sm:inline",
                                                            children: "WhatsApp"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 157,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 150,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "tel:087852432636",
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex-1 bg-blue-500 text-white px-4 py-3 rounded-lg font-semibold hover:bg-blue-600 transition text-center flex items-center justify-center gap-2 group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                            className: "w-4 h-4"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 164,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "hidden sm:inline",
                                                            children: "Telepon"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 165,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 160,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/CarHero.tsx",
                                            lineNumber: 149,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarHero.tsx",
                                    lineNumber: 133,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-4ff5c963f8d25c47" + " " + "mt-4 lg:mt-6 p-3 bg-gray-800/30 rounded-lg",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-4ff5c963f8d25c47" + " " + "text-xs text-gray-400 text-center lg:text-left",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "jsx-4ff5c963f8d25c47" + " " + "flex flex-wrap justify-center lg:justify-start gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex items-center gap-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-green-400",
                                                            children: "✓"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 175,
                                                            columnNumber: 21
                                                        }, this),
                                                        " Test drive gratis"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 174,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex items-center gap-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-green-400",
                                                            children: "✓"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 178,
                                                            columnNumber: 21
                                                        }, this),
                                                        " Stok tersedia"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 177,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex items-center gap-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-green-400",
                                                            children: "✓"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 181,
                                                            columnNumber: 21
                                                        }, this),
                                                        " Garansi resmi"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 180,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "jsx-4ff5c963f8d25c47" + " " + "flex items-center gap-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-4ff5c963f8d25c47" + " " + "text-green-400",
                                                            children: "✓"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/cars/CarHero.tsx",
                                                            lineNumber: 184,
                                                            columnNumber: 21
                                                        }, this),
                                                        " Lokasi Surabaya"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarHero.tsx",
                                                    lineNumber: 183,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/CarHero.tsx",
                                            lineNumber: 173,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarHero.tsx",
                                        lineNumber: 172,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarHero.tsx",
                                    lineNumber: 171,
                                    columnNumber: 13
                                }, this),
                                car.tags && car.tags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-4ff5c963f8d25c47" + " " + "mt-4 lg:mt-6",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-4ff5c963f8d25c47" + " " + "flex flex-wrap gap-2 justify-center lg:justify-start",
                                        children: car.tags.slice(0, 4).map((tag, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-4ff5c963f8d25c47" + " " + "bg-gray-700 text-gray-300 text-xs px-2 py-1 rounded-full border border-gray-600",
                                                children: tag
                                            }, index, false, {
                                                fileName: "[project]/components/cars/CarHero.tsx",
                                                lineNumber: 195,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarHero.tsx",
                                        lineNumber: 193,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarHero.tsx",
                                    lineNumber: 192,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarHero.tsx",
                            lineNumber: 66,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/cars/CarHero.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/cars/CarHero.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(void 0, {
                id: "4ff5c963f8d25c47",
                children: ".hide-scrollbar.jsx-4ff5c963f8d25c47{-ms-overflow-style:none;scrollbar-width:none}.hide-scrollbar.jsx-4ff5c963f8d25c47::-webkit-scrollbar{display:none}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/cars/CarHero.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/cars/CarQuickInfo.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarQuickInfo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function CarQuickInfo({ car }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "bg-white py-8 border-b border-gray-200",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-600 text-sm mb-1",
                                    children: "Kategori"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 14,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-semibold text-lg",
                                    children: car.category
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 15,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 13,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-600 text-sm mb-1",
                                    children: "Tahun"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 19,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-semibold text-lg",
                                    children: car.year
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 20,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-600 text-sm mb-1",
                                    children: "Tipe Tersedia"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 24,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-semibold text-lg",
                                    children: [
                                        car.typeCount,
                                        " Varian"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 25,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-600 text-sm mb-1",
                                    children: "Dilihat"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 29,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-semibold text-lg",
                                    children: [
                                        car.views,
                                        "x"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 30,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                    lineNumber: 11,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 text-center max-w-3xl mx-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-700 text-lg leading-relaxed",
                        children: car.description
                    }, void 0, false, {
                        fileName: "[project]/components/cars/CarQuickInfo.tsx",
                        lineNumber: 36,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                    lineNumber: 35,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/cars/CarQuickInfo.tsx",
            lineNumber: 10,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/cars/CarQuickInfo.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/VariantsTable.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/VariantsTable.tsx <module evaluation>", "default");
}),
"[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/VariantsTable.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/VariantsTable.tsx", "default");
}),
"[project]/components/cars/VariantsTable.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/CarFeaturesTabs.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/CarFeaturesTabs.tsx <module evaluation>", "default");
}),
"[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/CarFeaturesTabs.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/CarFeaturesTabs.tsx", "default");
}),
"[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/app/mobil/[slug]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarDetailPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarHero.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarQuickInfo$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarQuickInfo.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/VariantsTable.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
async function CarDetailPage({ params }) {
    // Await params sebelum digunakan
    const { slug } = await params;
    const car = (0, __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getCarBySlug"])(slug);
    if (!car) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                car: car
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarQuickInfo$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                car: car
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                variants: car.variants,
                carName: car.name
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                features: car.features,
                specs: car.specs
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "bg-red-600 text-white py-12",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4 text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-3xl font-bold mb-4",
                            children: [
                                "Tertarik dengan ",
                                car.name,
                                "?"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                            lineNumber: 32,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xl mb-8 max-w-2xl mx-auto",
                            children: "Hubungi sales consultant kami sekarang untuk informasi lebih detail, test drive, dan penawaran spesial."
                        }, void 0, false, {
                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                            lineNumber: 35,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col sm:flex-row gap-4 justify-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: `https://wa.me/6287852432636?text=${encodeURIComponent(`Halo, saya tertarik dengan ${car.name}. Bisa info detail dan test drive?`)}`,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "bg-green-500 text-white px-8 py-4 rounded-lg font-semibold hover:bg-green-600 transition text-lg",
                                    children: "💬 WhatsApp Sales"
                                }, void 0, false, {
                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                    lineNumber: 40,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "tel:087852432636",
                                    className: "bg-white text-red-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition text-lg",
                                    children: "📞 Telepon Sekarang"
                                }, void 0, false, {
                                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                                    lineNumber: 48,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/mobil/[slug]/page.tsx",
                            lineNumber: 39,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                    lineNumber: 31,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/mobil/[slug]/page.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/mobil/[slug]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/mobil/[slug]/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__7f7f9959._.js.map