module.exports = [
"[project]/.next-internal/server/app/test-drive/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_test-drive_page_actions_29bbcf11.js.map