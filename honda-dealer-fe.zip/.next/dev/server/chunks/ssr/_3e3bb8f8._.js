module.exports = [
"[project]/data/cars/brio.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "brio",
    ()=>brio
]);
const brio = {
    id: 'brio-2024',
    slug: 'all-new-brio',
    name: 'All New BRIO',
    model: 'BRIO',
    category: 'Hatchback',
    priceRange: 'Rp 182,1 - 271,3 Juta',
    startingPrice: 182100000,
    typeCount: 7,
    year: 2024,
    images: {
        main: '/images/cars/all-new-brio/main.jpg',
        gallery: [
            '/images/cars/all-new-brio/gallery-1.jpg',
            '/images/cars/all-new-brio/gallery-2.jpg',
            '/images/cars/all-new-brio/gallery-3.jpg',
            '/images/cars/all-new-brio/gallery-4.jpg'
        ],
        thumbnail: '/images/cars/all-new-brio/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-brio/colors/red.jpg',
            '/images/cars/all-new-brio/colors/blue.jpg',
            '/images/cars/all-new-brio/colors/white.jpg',
            '/images/cars/all-new-brio/colors/black.jpg',
            '/images/cars/all-new-brio/colors/silver.jpg',
            '/images/cars/all-new-brio/colors/orange.jpg'
        ]
    },
    variants: [
        {
            id: 'brio-s-mt',
            type: 'ALL NEW BRIO S MT',
            price: 182100000,
            priceFormatted: 'Rp 182.100.000',
            features: [
                'Front Dual SRS Airbags',
                'ABS dengan EBD',
                'Power Steering',
                'AC Manual',
                'Audio dengan USB',
                'Rem Depan Cakram',
                'Rem Belakang Tromol',
                'Velg Steel 14"',
                'Seat Fabric',
                'Immobilizer System',
                'Rear Defogger'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-e-mt',
            type: 'ALL NEW BRIO E MT',
            price: 195200000,
            priceFormatted: 'Rp 195.200.000',
            features: [
                'Front Dual SRS Airbags',
                'ABS dengan EBD',
                'Power Steering',
                'AC Manual',
                'Audio dengan USB & Bluetooth',
                'Power Window Depan',
                'Central Door Lock',
                'Remote Keyless Entry',
                'Velg Steel 14" dengan Cover',
                'Body Color Door Handle & Mirror',
                'Rear Spoiler'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-e-cvt',
            type: 'ALL NEW BRIO E CVT',
            price: 213200000,
            priceFormatted: 'Rp 213.200.000',
            features: [
                'Front Dual SRS Airbags',
                'ABS dengan EBD',
                'Power Steering',
                'AC Manual',
                'Audio dengan USB & Bluetooth',
                'Power Window Depan',
                'Central Door Lock',
                'Remote Keyless Entry',
                'Transmisi CVT',
                'Econ Mode',
                'Body Color Door Handle & Mirror',
                'Rear Spoiler'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-mt',
            type: 'ALL NEW BRIO RS MT',
            price: 258600000,
            priceFormatted: 'Rp 258.600.000',
            features: [
                'RS Body Kit & Grille',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-mt-tt',
            type: 'ALL NEW BRIO RS MT TWO TONE',
            price: 261100000,
            priceFormatted: 'Rp 261.100.000',
            features: [
                'RS Body Kit & Grille',
                'Two-Tone Color',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher',
                'Black Roof'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-cvt',
            type: 'ALL NEW BRIO RS CVT',
            price: 268800000,
            priceFormatted: 'Rp 268.800.000',
            features: [
                'RS Body Kit & Grille',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'Transmisi CVT',
                'Econ Mode',
                'Paddle Shift',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-cvt-tt',
            type: 'ALL NEW BRIO RS CVT TWO TONE',
            price: 271300000,
            priceFormatted: 'Rp 271.300.000',
            features: [
                'RS Body Kit & Grille',
                'Two-Tone Color',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'Transmisi CVT',
                'Econ Mode',
                'Paddle Shift',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher',
                'Black Roof'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '3610 mm',
            width: '1680 mm',
            height: '1500 mm',
            wheelbase: '2345 mm',
            weight: '890 - 920 kg'
        },
        performance: {
            engine: '1.2L SOHC i-VTEC',
            displacement: '1198 cc',
            maxPower: '90 PS / 6000 rpm',
            maxTorque: '110 Nm / 4800 rpm',
            transmission: '5-speed Manual / CVT',
            fuelConsumption: '20,0 km/L (MT) / 19,0 km/L (CVT)',
            acceleration: '0-100 km/h dalam 13.5 detik',
            topSpeed: '160 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '35 Liter',
            luggage: '258 Liter',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'LED Headlights (RS)',
                'Front Fog Lamps (RS)',
                '14-inch Alloy Wheels (RS)',
                'RS Body Kit'
            ],
            interior: [
                'Touchscreen Audio',
                'Multi-Info Display',
                'Fabric Seats',
                'RS Seat Fabric'
            ],
            safety: [
                'Dual SRS Airbags',
                'ABS dengan EBD',
                'Immobilizer',
                'Rear Parking Sensor (RS)'
            ],
            entertainment: [
                'USB & Bluetooth Audio',
                '4 Speakers',
                'Steering Audio Control (RS)'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Fun & Youthful',
            description: 'Brio hadir dengan desain yang fun, youthful, dan compact, perfect untuk mobilitas perkotaan. Varian RS dilengkapi dengan body kit sporty yang membuat tampilannya semakin aggressive.',
            features: [
                'Compact Hatchback Design',
                'RS Body Kit (Varian RS)',
                '14-inch Alloy Wheels (RS)',
                'Front Fog Lamps (RS)',
                'Two-Tone Color Options',
                'Chrome Accents'
            ],
            images: [
                '/images/cars/all-new-brio/features/exterior-1.jpg',
                '/images/cars/all-new-brio/features/exterior-2.jpg'
            ]
        },
        interior: {
            title: 'Interior Praktis & Fungsional',
            description: 'Kabin yang didesain dengan layout praktis dan fungsional, menawarkan kenyamanan dan kemudahan penggunaan dalam berkendara sehari-hari.',
            features: [
                'Touchscreen Audio System',
                'Multi-Info Display',
                'Fabric Seats dengan RS Variant',
                'Power Windows',
                'Steering Wheel dengan Audio Control (RS)',
                'Cabin Storage yang Luas'
            ],
            images: [
                '/images/cars/all-new-brio/features/interior-1.jpg',
                '/images/cars/all-new-brio/features/interior-2.jpg'
            ]
        },
        safety: {
            title: 'Keselamatan yang Terjangkau',
            description: 'Dilengkapi dengan fitur keselamatan dasar yang essential untuk perlindungan pengemudi dan penumpang dalam berkendara sehari-hari.',
            features: [
                'Dual Front SRS Airbags',
                'Anti-lock Braking System (ABS)',
                'Electronic Brake-force Distribution (EBD)',
                'Immobilizer System',
                'Rear Parking Sensor (RS)',
                'High-Mounted Stop Lamp'
            ],
            images: [
                '/images/cars/all-new-brio/features/safety-1.jpg',
                '/images/cars/all-new-brio/features/safety-2.jpg'
            ]
        },
        technology: {
            title: 'Teknologi untuk Kenyamanan Berkendara',
            description: 'Berbagai fitur teknologi yang mendukung kenyamanan dan efisiensi dalam berkendara sehari-hari.',
            features: [
                'ECON Mode (CVT)',
                'Paddle Shift (RS CVT)',
                'Remote Keyless Entry',
                'Power Steering',
                'Multi-Info Display',
                'Audio System dengan USB & Bluetooth'
            ],
            images: [
                '/images/cars/all-new-brio/features/tech-1.jpg',
                '/images/cars/all-new-brio/features/tech-2.jpg'
            ]
        }
    },
    description: 'All New Brio adalah hatchback kompak yang sempurna untuk mobilitas perkotaan. Dengan desain yang fun dan youthful, Brio menawarkan efisiensi bahan bakar yang excellent dan kemudahan dalam bermanuver. Tersedia dalam berbagai varian mulai dari S hingga RS dengan pilihan transmisi Manual dan CVT, dilengkapi dengan fitur keselamatan dan teknologi yang memadai untuk kebutuhan sehari-hari.',
    shortDescription: 'Hatchback kompak yang fun dan efisien untuk mobilitas perkotaan dengan pilihan 7 varian termasuk RS yang sporty.',
    tags: [
        'Hatchback',
        'City Car',
        'Economical',
        'Compact',
        'RS Model',
        'Two-Tone',
        'Fuel Efficient'
    ],
    isFeatured: true,
    isNew: true,
    views: 865,
    relatedCars: [
        'new-hr-v',
        'wr-v',
        'mobilio'
    ],
    createdAt: '2024-01-10',
    updatedAt: '2024-01-10'
};
}),
"[project]/data/cars/hrv.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hrv",
    ()=>hrv
]);
const hrv = {
    id: 'hrv-2024',
    slug: 'new-hr-v',
    name: 'All New HR-V',
    model: 'HR-V',
    category: 'SUV',
    priceRange: 'Rp 403,8 - 428,4 Juta',
    startingPrice: 403800000,
    typeCount: 4,
    year: 2024,
    images: {
        main: '/images/cars/all-new-hr-v/main.jpg',
        gallery: [
            '/images/cars/all-new-hr-v/gallery-1.jpg',
            '/images/cars/all-new-hr-v/gallery-2.jpg',
            '/images/cars/all-new-hr-v/gallery-3.jpg',
            '/images/cars/all-new-hr-v/gallery-4.jpg'
        ],
        thumbnail: '/images/cars/all-new-hr-v/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-hr-v/colors/red.jpg',
            '/images/cars/all-new-hr-v/colors/black.jpg',
            '/images/cars/all-new-hr-v/colors/white.jpg',
            '/images/cars/all-new-hr-v/colors/gray.jpg',
            '/images/cars/all-new-hr-v/colors/silver.jpg'
        ]
    },
    variants: [
        {
            id: 'hrv-e-cvt',
            type: 'ALL NEW HR-V E CVT',
            price: 403800000,
            priceFormatted: 'Rp 403.800.000',
            features: [
                'LED Headlights',
                '7-inch Touchscreen Display',
                'Keyless Entry',
                '6 Airbags',
                'Vehicle Stability Assist',
                'Rear View Camera',
                'Manual AC',
                'Fabric Seats',
                '4 Speakers',
                '16-inch Alloy Wheels'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'hrv-e-cvt-tt',
            type: 'ALL NEW HR-V E CVT TWO TONE',
            price: 406300000,
            priceFormatted: 'Rp 406.300.000',
            features: [
                'LED Headlights',
                '7-inch Touchscreen Display',
                'Keyless Entry',
                '6 Airbags',
                'Vehicle Stability Assist',
                'Rear View Camera',
                'Manual AC',
                'Fabric Seats',
                '4 Speakers',
                '16-inch Alloy Wheels',
                'Two-Tone Color',
                'Black Roof'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'hrv-e-plus-cvt',
            type: 'ALL NEW HR-V E+ CVT',
            price: 425900000,
            priceFormatted: 'Rp 425.900.000',
            features: [
                'LED Headlights with DRL',
                '8-inch Touchscreen Display',
                'Push Start Button',
                'Rear View Camera',
                'Parking Sensors',
                'Auto AC',
                'Fabric Seats',
                '6 Speakers',
                '17-inch Alloy Wheels',
                'Paddle Shift',
                'Multi-View Camera'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'hrv-e-plus-cvt-tt',
            type: 'ALL NEW HR-V E+ CVT TWO TONE',
            price: 428400000,
            priceFormatted: 'Rp 428.400.000',
            features: [
                'LED Headlights with DRL',
                '8-inch Touchscreen Display',
                'Push Start Button',
                'Rear View Camera',
                'Parking Sensors',
                'Auto AC',
                'Fabric Seats',
                '6 Speakers',
                '17-inch Alloy Wheels',
                'Paddle Shift',
                'Multi-View Camera',
                'Two-Tone Color',
                'Black Roof',
                'Chrome Accents'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4385 mm',
            width: '1790 mm',
            height: '1590 mm',
            wheelbase: '2610 mm',
            weight: '1250 - 1280 kg'
        },
        performance: {
            engine: '1.5L DOHC i-VTEC',
            displacement: '1498 cc',
            maxPower: '121 PS / 6600 rpm',
            maxTorque: '145 Nm / 4300 rpm',
            transmission: 'CVT dengan Earth Dreams Technology',
            fuelConsumption: '17,8 km/L',
            acceleration: '0-100 km/h dalam 11.2 detik',
            topSpeed: '185 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '40 Liter',
            luggage: '430 Liter (dapat diperluas hingga 1.200 Liter)',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'LED Headlights',
                'Power Retractable Mirrors',
                '16-17 inch Alloy Wheels'
            ],
            interior: [
                'Floating Touchscreen',
                'Digital Cluster',
                'Fabric Seats',
                'Manual/Auto AC'
            ],
            safety: [
                '6 Airbags',
                'ABS + EBD',
                'Vehicle Stability Assist',
                'Rear View Camera'
            ],
            entertainment: [
                'Apple CarPlay',
                'Android Auto',
                '4-6 Speakers'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Modern & Sporty',
            description: 'HR-V generasi baru dengan desain lebih maskulin dan sporty, berkat penggunaan panel front grille dengan desain lebih lebar dan tebal, sebagai latar dari logo Honda.',
            features: [
                'LED Headlights dengan DRL',
                '16-17 inch Alloy Wheels',
                'Power Retractable Side Mirrors',
                'Chrome Front Grille',
                'LED Fog Lamps (E+)',
                'Two-Tone Color Options'
            ],
            images: [
                '/images/cars/all-new-hr-v/features/exterior-1.jpg',
                '/images/cars/all-new-hr-v/features/exterior-2.jpg'
            ]
        },
        interior: {
            title: 'Interior Nyaman & Teknologi Terkini',
            description: 'Kabin yang didesain dengan material berkualitas dan teknologi terkini untuk kenyamanan maksimal pengemudi dan penumpang.',
            features: [
                'Floating 7-8 inch Touchscreen Display',
                'Digital Meter Cluster',
                'Fabric Seats',
                'Manual / Auto AC',
                'Paddle Shift (E+)',
                'Multi-View Camera (E+)'
            ],
            images: [
                '/images/cars/all-new-hr-v/features/interior-1.jpg',
                '/images/cars/all-new-hr-v/features/interior-2.jpg'
            ]
        },
        safety: {
            title: 'Teknologi Keselamatan Komprehensif',
            description: 'Dilengkapi dengan berbagai fitur keselamatan canggih yang memberikan perlindungan maksimal untuk pengemudi dan penumpang.',
            features: [
                '6 SRS Airbags',
                'Anti-lock Braking System (ABS)',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Rear View Camera',
                'Parking Sensors (E+)'
            ],
            images: [
                '/images/cars/all-new-hr-v/features/safety-1.jpg',
                '/images/cars/all-new-hr-v/features/safety-2.jpg'
            ]
        }
    },
    description: 'All New HR-V dengan desain terbaru yang lebih sporty dan teknologi canggih. SUV kompak yang sempurna untuk keluarga modern. Tersedia dalam 4 varian dengan pilihan warna Two-Tone.',
    shortDescription: 'SUV kompak dengan desain modern dan teknologi canggih untuk keluarga urban, tersedia dalam 4 varian.',
    tags: [
        'SUV',
        'Family',
        'City Car',
        'Two-Tone',
        'Compact SUV'
    ],
    isFeatured: true,
    isNew: true,
    views: 1247,
    relatedCars: [
        'new-cr-v',
        'new-br-v',
        'wr-v'
    ],
    createdAt: '2024-01-15',
    updatedAt: '2024-01-15'
};
}),
"[project]/data/cars/crv.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "crv",
    ()=>crv
]);
const crv = {
    id: 'crv-2024',
    slug: 'all-new-cr-v',
    name: 'All New CR-V',
    model: 'CR-V',
    category: 'SUV',
    priceRange: 'Rp 828,7 - 950 Juta',
    startingPrice: 828700000,
    typeCount: 3,
    year: 2024,
    images: {
        main: '/images/cars/all-new-cr-v/main.jpg',
        gallery: [
            '/images/cars/all-new-cr-v/gallery-1.jpg',
            '/images/cars/all-new-cr-v/gallery-2.jpg',
            '/images/cars/all-new-cr-v/gallery-3.jpg',
            '/images/cars/all-new-cr-v/gallery-4.jpg'
        ],
        thumbnail: '/images/cars/all-new-cr-v/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-cr-v/colors/black.jpg',
            '/images/cars/all-new-cr-v/colors/white.jpg',
            '/images/cars/all-new-cr-v/colors/silver.jpg',
            '/images/cars/all-new-cr-v/colors/blue.jpg'
        ]
    },
    variants: [
        {
            id: 'crv-e-cvt',
            type: 'ALL NEW CR-V E CVT',
            price: 828700000,
            priceFormatted: 'Rp 828.700.000',
            features: [
                'LED Headlights dengan DRL',
                '18-inch Alloy Wheels',
                '7-inch Touchscreen',
                'Honda SENSING',
                'Electric Parking Brake'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L Turbo',
            available: true
        },
        {
            id: 'crv-e-hev',
            type: 'ALL NEW CR-V e:HEV',
            price: 899000000,
            priceFormatted: 'Rp 899.000.000',
            features: [
                'Full LED Headlights',
                'Hybrid System',
                '9-inch Touchscreen',
                'Wireless Charger',
                'Panoramic Sunroof'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        }
    ],
    description: 'All New CR-V adalah SUV premium dengan desain yang elegan dan teknologi canggih. Menawarkan kenyamanan terbaik dan fitur keselamatan terlengkap.',
    shortDescription: 'SUV premium dengan teknologi canggih dan kenyamanan terbaik untuk keluarga.',
    tags: [
        'SUV',
        'Premium',
        'Family',
        '7-Seater',
        'Hybrid'
    ],
    isFeatured: true,
    isNew: true,
    views: 892,
    relatedCars: [
        'new-hr-v',
        'new-br-v'
    ],
    createdAt: '2024-01-20',
    updatedAt: '2024-01-20'
};
}),
"[project]/data/cars/wrv.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "wrv",
    ()=>wrv
]);
const wrv = {
    id: 'wrv-2024',
    slug: 'all-new-wr-v',
    name: 'All New WR-V',
    model: 'WR-V',
    category: 'SUV',
    priceRange: 'Rp 320 - 380 Juta',
    startingPrice: 320000000,
    typeCount: 4,
    year: 2024,
    images: {
        main: '/images/cars/all-new-wr-v/main.jpg',
        gallery: [
            '/images/cars/all-new-wr-v/gallery-1.jpg',
            '/images/cars/all-new-wr-v/gallery-2.jpg',
            '/images/cars/all-new-wr-v/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-wr-v/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-wr-v/colors/red.jpg',
            '/images/cars/all-new-wr-v/colors/black.jpg',
            '/images/cars/all-new-wr-v/colors/white.jpg'
        ]
    },
    variants: [
        {
            id: 'wrv-e-cvt',
            type: 'ALL NEW WR-V E CVT',
            price: 320000000,
            priceFormatted: 'Rp 320.000.000',
            features: [
                'LED Headlights',
                '7-inch Touchscreen',
                'Keyless Entry',
                '4 Airbags',
                'Rear Camera'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    description: 'All New WR-V menghadirkan SUV compact dengan desain adventurous dan kapabilitas tangguh untuk petualangan urban.',
    shortDescription: 'SUV compact dengan desain adventurous untuk petualangan urban.',
    tags: [
        'SUV',
        'Adventure',
        'Compact',
        'Urban'
    ],
    isFeatured: true,
    isNew: true,
    views: 756,
    relatedCars: [
        'all-new-brio',
        'new-hr-v'
    ],
    createdAt: '2024-02-01',
    updatedAt: '2024-02-01'
};
}),
"[project]/data/cars/brv.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "brv",
    ()=>brv
]);
const brv = {
    id: 'brv-2024',
    slug: 'all-new-br-v',
    name: 'All New BR-V',
    model: 'BR-V',
    category: 'MPV',
    priceRange: 'Rp 280 - 350 Juta',
    startingPrice: 280000000,
    typeCount: 5,
    year: 2024,
    images: {
        main: '/images/cars/all-new-br-v/main.jpg',
        gallery: [
            '/images/cars/all-new-br-v/gallery-1.jpg',
            '/images/cars/all-new-br-v/gallery-2.jpg',
            '/images/cars/all-new-br-v/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-br-v/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-br-v/colors/white.jpg',
            '/images/cars/all-new-br-v/colors/black.jpg',
            '/images/cars/all-new-br-v/colors/silver.jpg'
        ]
    },
    variants: [
        {
            id: 'brv-e-cvt',
            type: 'ALL NEW BR-V E CVT',
            price: 280000000,
            priceFormatted: 'Rp 280.000.000',
            features: [
                '7-Seater',
                'LED Headlights',
                'Touchscreen Display',
                'Rear AC',
                '4 Airbags'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    description: 'All New BR-V adalah MPV 7-seater dengan desain sporty dan ruang kabin yang luas, cocok untuk keluarga besar.',
    shortDescription: 'MPV 7-seater dengan desain sporty dan ruang luas untuk keluarga.',
    tags: [
        'MPV',
        '7-Seater',
        'Family',
        'Spacious'
    ],
    isFeatured: true,
    isNew: true,
    views: 923,
    relatedCars: [
        'all-new-cr-v',
        'all-new-hr-v'
    ],
    createdAt: '2024-02-05',
    updatedAt: '2024-02-05'
};
}),
"[project]/data/cars/civic.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "civic",
    ()=>civic
]);
const civic = {
    id: 'civic-e-hev-rs-2024',
    slug: 'all-new-civic-e-hev-rs',
    name: 'All New Civic e:HEV RS',
    model: 'Civic',
    category: 'Sedan',
    priceRange: 'Rp 680 - 750 Juta',
    startingPrice: 680000000,
    typeCount: 2,
    year: 2024,
    images: {
        main: '/images/cars/all-new-civic-e-hev-rs/main.jpg',
        gallery: [
            '/images/cars/all-new-civic-e-hev-rs/gallery-1.jpg',
            '/images/cars/all-new-civic-e-hev-rs/gallery-2.jpg',
            '/images/cars/all-new-civic-e-hev-rs/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-civic-e-hev-rs/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-civic-e-hev-rs/colors/red.jpg',
            '/images/cars/all-new-civic-e-hev-rs/colors/black.jpg',
            '/images/cars/all-new-civic-e-hev-rs/colors/white.jpg'
        ]
    },
    variants: [
        {
            id: 'civic-e-hev-rs',
            type: 'ALL NEW CIVIC e:HEV RS',
            price: 750000000,
            priceFormatted: 'Rp 750.000.000',
            features: [
                'RS Body Kit',
                'Hybrid System',
                'Full LED Headlights',
                '10.2-inch Digital Cluster',
                'Bose Premium Audio',
                'Honda SENSING'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        }
    ],
    description: 'All New Civic e:HEV RS menghadirkan sedan sport hybrid dengan performa tangguh dan desain agresif khas RS.',
    shortDescription: 'Sedan sport hybrid dengan desain agresif khas RS dan performa tangguh.',
    tags: [
        'Sedan',
        'Hybrid',
        'Sport',
        'RS',
        'Premium'
    ],
    isFeatured: true,
    isNew: true,
    views: 1567,
    relatedCars: [
        'all-new-civic-type-r',
        'city-hatchback-rs'
    ],
    createdAt: '2024-02-25',
    updatedAt: '2024-02-25'
};
}),
"[project]/data/cars/accord.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "accord",
    ()=>accord
]);
const accord = {
    id: 'accord-ehev-2024',
    slug: 'all-new-accord-ehev',
    name: 'All New Accord e:HEV',
    model: 'Accord',
    category: 'Sedan',
    priceRange: 'Rp 825 - 925 Juta',
    startingPrice: 825000000,
    typeCount: 3,
    year: 2024,
    images: {
        main: '/images/cars/all-new-accord-ehev/main.jpg',
        gallery: [
            '/images/cars/all-new-accord-ehev/gallery-1.jpg',
            '/images/cars/all-new-accord-ehev/gallery-2.jpg',
            '/images/cars/all-new-accord-ehev/gallery-3.jpg',
            '/images/cars/all-new-accord-ehev/gallery-4.jpg'
        ],
        thumbnail: '/images/cars/all-new-accord-ehev/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-accord-ehev/colors/white.jpg',
            '/images/cars/all-new-accord-ehev/colors/black.jpg',
            '/images/cars/all-new-accord-ehev/colors/silver.jpg',
            '/images/cars/all-new-accord-ehev/colors/blue.jpg'
        ]
    },
    variants: [
        {
            id: 'accord-ehev-luxury',
            type: 'ACCORD e:HEV LUXURY',
            price: 825000000,
            priceFormatted: 'Rp 825.000.000',
            features: [
                'Hybrid System 2.0L',
                '12.3-inch Touchscreen Display',
                'Digital Cluster 10.2-inch',
                'Leather Seats dengan Memory Function',
                'Honda SENSING 360',
                '8 Airbags',
                'Panoramic Sunroof',
                'Wireless Charger'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        },
        {
            id: 'accord-ehev-prestige',
            type: 'ACCORD e:HEV PRESTIGE',
            price: 875000000,
            priceFormatted: 'Rp 875.000.000',
            features: [
                'Advanced Hybrid System',
                'Head-up Display',
                'Bose Premium Audio System',
                'Ventilated & Heated Seats',
                '360-degree Camera',
                'Parking Assist',
                'Ambient Lighting',
                'Power Rear Sunshade'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        },
        {
            id: 'accord-ehev-flagship',
            type: 'ACCORD e:HEV FLAGSHIP',
            price: 925000000,
            priceFormatted: 'Rp 925.000.000',
            features: [
                'Full LED Matrix Headlights',
                '12-speaker Bose Audio',
                'Semi-autonomous Driving',
                'Remote Parking Assist',
                'Wireless Apple CarPlay & Android Auto',
                'Digital Key',
                'Traffic Jam Assist',
                'Premium Nappa Leather'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4970 mm',
            width: '1860 mm',
            height: '1450 mm',
            wheelbase: '2830 mm',
            weight: '1580 kg'
        },
        performance: {
            engine: '2.0L Atkinson Cycle i-VTEC + Dual Motor',
            displacement: '1993 cc',
            maxPower: '204 PS (combined)',
            maxTorque: '335 Nm (combined)',
            transmission: 'e-CVT',
            fuelConsumption: '23,8 km/L',
            acceleration: '0-100 km/h dalam 7,6 detik',
            topSpeed: '180 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '48 Liter',
            luggage: '450 Liter',
            doors: '4 Pintu'
        },
        features: {
            exterior: [
                'Full LED Headlights',
                '18-inch Alloy Wheels',
                'Power Sunroof',
                'Smart Entry'
            ],
            interior: [
                'Leather Seats',
                'Dual Zone Climate Control',
                'Power Seats',
                'Push Start'
            ],
            safety: [
                'Honda SENSING 360',
                '8 Airbags',
                'ABS + EBD',
                'Vehicle Stability Assist'
            ],
            entertainment: [
                '12.3-inch Display',
                'Bose Audio',
                'Wireless Connectivity',
                'Navigation'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Elegant & Futuristik',
            description: 'Accord generasi terbaru dengan desain yang lebih premium dan elegan, menampilkan garis-garis yang tajam dan proporsi yang sempurna untuk sedan executive modern.',
            features: [
                'Full LED Matrix Headlights dengan Adaptive Beam',
                '18-inch Premium Alloy Wheels',
                'Panoramic Glass Roof',
                'Chrome Accents & Body Kit',
                'Power Folding Side Mirrors'
            ],
            images: [
                '/images/cars/all-new-accord-ehev/features/exterior-1.jpg',
                '/images/cars/all-new-accord-ehev/features/exterior-2.jpg'
            ]
        },
        interior: {
            title: 'Interior Luxury & Technology',
            description: 'Kabin mewah dengan material premium dan teknologi terkini, menawarkan kenyamanan tertinggi dan pengalaman berkendara yang sophisticated.',
            features: [
                '12.3-inch Advanced Touchscreen Display',
                '10.2-inch Digital Meter Cluster',
                'Leather Seats dengan Memory & Ventilation',
                'Bose Premium Audio System 12-speaker',
                'Ambient Lighting dengan Multiple Colors'
            ],
            images: [
                '/images/cars/all-new-accord-ehev/features/interior-1.jpg',
                '/images/cars/all-new-accord-ehev/features/interior-2.jpg'
            ]
        },
        safety: {
            title: 'Advanced Safety Suite',
            description: 'Dilengkapi dengan Honda SENSING 360 yang memberikan perlindungan menyeluruh dengan berbagai fitur keselamatan canggih untuk perlindungan maksimal.',
            features: [
                'Honda SENSING 360 dengan 360-degree Camera',
                '8 SRS Airbags dengan Knee Airbag',
                'Blind Spot Information System',
                'Cross Traffic Monitor',
                'Traffic Jam Assist'
            ],
            images: [
                '/images/cars/all-new-accord-ehev/features/safety-1.jpg',
                '/images/cars/all-new-accord-ehev/features/safety-2.jpg'
            ]
        },
        technology: {
            title: 'Cutting-Edge Technology',
            description: 'Terintegrasi dengan teknologi paling mutakhir untuk pengalaman berkendara yang terhubung, aman, dan menyenangkan di era digital.',
            features: [
                'Wireless Apple CarPlay & Android Auto',
                'Head-up Display dengan AR Navigation',
                'Digital Key dengan Smartphone Integration',
                'Wireless Smartphone Charger',
                'Honda CONNECT dengan 5G Connectivity'
            ],
            images: [
                '/images/cars/all-new-accord-ehev/features/technology-1.jpg',
                '/images/cars/all-new-accord-ehev/features/technology-2.jpg'
            ]
        }
    },
    description: 'All New Honda Accord e:HEV adalah sedan executive premium dengan teknologi hybrid terdepan. Menghadirkan kombinasi sempurna antara performa, efisiensi, dan kemewahan dengan fitur-fitur canggih untuk pengalaman berkendara yang tak tertandingi.',
    shortDescription: 'Sedan executive premium hybrid dengan teknologi canggih dan kemewahan terbaik di kelasnya.',
    tags: [
        'Sedan',
        'Premium',
        'Hybrid',
        'Executive',
        'Honda SENSING',
        'Luxury'
    ],
    isFeatured: true,
    isNew: true,
    views: 1568,
    relatedCars: [
        'all-new-civic-e-hev-rs',
        'all-new-cr-v',
        'all-new-civic-type-r'
    ],
    createdAt: '2024-03-10',
    updatedAt: '2024-03-10'
};
}),
"[project]/data/cars/stepwgn.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stepwgn",
    ()=>stepwgn
]);
const stepwgn = {
    id: 'stepwgn-e-hev-2024',
    slug: 'stepwgn-e-hev',
    name: 'Stepwgn e:HEV',
    model: 'Stepwgn',
    category: 'MPV',
    priceRange: 'Rp 650 - 750 Juta',
    startingPrice: 650000000,
    typeCount: 3,
    year: 2024,
    images: {
        main: '/images/cars/stepwgn-e-hev/main.jpg',
        gallery: [
            '/images/cars/stepwgn-e-hev/gallery-1.jpg',
            '/images/cars/stepwgn-e-hev/gallery-2.jpg',
            '/images/cars/stepwgn-e-hev/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/stepwgn-e-hev/thumbnail.jpg',
        colorOptions: [
            '/images/cars/stepwgn-e-hev/colors/white.jpg',
            '/images/cars/stepwgn-e-hev/colors/black.jpg',
            '/images/cars/stepwgn-e-hev/colors/silver.jpg'
        ]
    },
    variants: [
        {
            id: 'stepwgn-e-hev-premium',
            type: 'STEPWGN e:HEV PREMIUM',
            price: 750000000,
            priceFormatted: 'Rp 750.000.000',
            features: [
                '8-Seater Hybrid',
                'Magic Seats',
                'Dual Power Sliding Doors',
                'Panoramic Roof',
                'Honda SENSING 360',
                '11.4-inch Touchscreen'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        }
    ],
    description: 'Stepwgn e:HEV adalah MPV keluarga premium dengan teknologi hybrid dan konfigurasi kursi Magic Seats yang fleksibel.',
    shortDescription: 'MPV keluarga premium hybrid dengan Magic Seats yang fleksibel.',
    tags: [
        'MPV',
        'Hybrid',
        '8-Seater',
        'Premium',
        'Family'
    ],
    isFeatured: true,
    isNew: true,
    views: 834,
    relatedCars: [
        'all-new-br-v',
        'all-new-cr-v'
    ],
    createdAt: '2024-02-20',
    updatedAt: '2024-02-20'
};
}),
"[project]/data/cars/cityhatchback.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cityhatchback",
    ()=>cityhatchback
]);
const cityhatchback = {
    id: 'city-hatchback-rs-2024',
    slug: 'city-hatchback-rs',
    name: 'City Hatchback RS',
    model: 'City',
    category: 'Hatchback',
    priceRange: 'Rp 350 - 420 Juta',
    startingPrice: 350000000,
    typeCount: 3,
    year: 2024,
    images: {
        main: '/images/cars/city-hatchback-rs/main.jpg',
        gallery: [
            '/images/cars/city-hatchback-rs/gallery-1.jpg',
            '/images/cars/city-hatchback-rs/gallery-2.jpg',
            '/images/cars/city-hatchback-rs/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/city-hatchback-rs/thumbnail.jpg',
        colorOptions: [
            '/images/cars/city-hatchback-rs/colors/red.jpg',
            '/images/cars/city-hatchback-rs/colors/black.jpg',
            '/images/cars/city-hatchback-rs/colors/white.jpg'
        ]
    },
    variants: [
        {
            id: 'city-hatchback-rs-premium',
            type: 'CITY HATCHBACK RS PREMIUM',
            price: 420000000,
            priceFormatted: 'Rp 420.000.000',
            features: [
                'RS Body Kit',
                'LED Headlights dengan DRL',
                '8-inch Touchscreen',
                'Apple CarPlay & Android Auto',
                '6 Airbags',
                'Push Start Button'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    description: 'City Hatchback RS menghadirkan hatchback sporty dengan desain agresif khas RS dan fitur lengkap untuk mobilitas urban.',
    shortDescription: 'Hatchback sporty dengan desain agresif khas RS untuk mobilitas urban.',
    tags: [
        'Hatchback',
        'Sport',
        'RS',
        'City Car',
        'Premium'
    ],
    isFeatured: true,
    isNew: true,
    views: 987,
    relatedCars: [
        'all-new-brio',
        'all-new-civic-e-hev-rs'
    ],
    createdAt: '2024-03-01',
    updatedAt: '2024-03-01'
};
}),
"[project]/data/cars/civictyper.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "civicTypeR",
    ()=>civicTypeR
]);
const civicTypeR = {
    id: 'civic-type-r-2024',
    slug: 'all-new-civic-type-r',
    name: 'All New Civic Type R',
    model: 'Civic Type R',
    category: 'Sport',
    priceRange: 'Rp 1,2 - 1,5 Miliar',
    startingPrice: 1200000000,
    typeCount: 1,
    year: 2024,
    images: {
        main: '/images/cars/all-new-civic-type-r/main.jpg',
        gallery: [
            '/images/cars/all-new-civic-type-r/gallery-1.jpg',
            '/images/cars/all-new-civic-type-r/gallery-2.jpg',
            '/images/cars/all-new-civic-type-r/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-civic-type-r/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-civic-type-r/colors/red.jpg',
            '/images/cars/all-new-civic-type-r/colors/white.jpg',
            '/images/cars/all-new-civic-type-r/colors/blue.jpg'
        ]
    },
    variants: [
        {
            id: 'civic-type-r',
            type: 'ALL NEW CIVIC TYPE R',
            price: 1500000000,
            priceFormatted: 'Rp 1.500.000.000',
            features: [
                '2.0L VTEC Turbo Engine',
                '6-speed Manual Transmission',
                'Racing Bucket Seats',
                'Brembo Brakes',
                '20-inch Alloy Wheels',
                'Type R Body Kit'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '2.0L Turbo',
            available: true
        }
    ],
    description: 'All New Civic Type R adalah hatchback performa tinggi dengan teknologi balap terbaru, memberikan pengalaman berkendara yang ekstrem dan mendebarkan.',
    shortDescription: 'Hatchback performa tinggi dengan teknologi balap untuk pengalaman berkendara ekstrem.',
    tags: [
        'Sport',
        'Performance',
        'Type R',
        'Turbo',
        'Racing'
    ],
    isFeatured: true,
    isNew: true,
    views: 2345,
    relatedCars: [
        'all-new-civic-e-hev-rs',
        'city-hatchback-rs'
    ],
    createdAt: '2024-03-05',
    updatedAt: '2024-03-05'
};
}),
"[project]/data/cars/hrvehev.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hrvehev",
    ()=>hrvehev
]);
const hrvehev = {
    id: 'hrv-e-hev-2024',
    slug: 'all-new-hr-v-e-hev',
    name: 'All New HR-V e:HEV',
    model: 'HR-V e:HEV',
    category: 'SUV',
    priceRange: 'Rp 450 - 500 Juta',
    startingPrice: 450000000,
    typeCount: 2,
    year: 2024,
    images: {
        main: '/images/cars/all-new-hr-v-e-hev/main.jpg',
        gallery: [
            '/images/cars/all-new-hr-v-e-hev/gallery-1.jpg',
            '/images/cars/all-new-hr-v-e-hev/gallery-2.jpg',
            '/images/cars/all-new-hr-v-e-hev/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-hr-v-e-hev/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-hr-v-e-hev/colors/blue.jpg',
            '/images/cars/all-new-hr-v-e-hev/colors/white.jpg',
            '/images/cars/all-new-hr-v-e-hev/colors/gray.jpg'
        ]
    },
    variants: [
        {
            id: 'hrv-e-hev-premium',
            type: 'ALL NEW HR-V e:HEV PREMIUM',
            price: 500000000,
            priceFormatted: 'Rp 500.000.000',
            features: [
                'Hybrid System',
                'Full LED Headlights',
                'Panoramic Sunroof',
                'Wireless Charger',
                'Honda SENSING',
                'Leather Seats'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    description: 'All New HR-V e:HEV menghadirkan teknologi hybrid terbaru dengan efisiensi bahan bakar yang excellent dan performa responsif.',
    shortDescription: 'SUV hybrid dengan efisiensi bahan bakar excellent dan performa responsif.',
    tags: [
        'SUV',
        'Hybrid',
        'Eco-Friendly',
        'Premium'
    ],
    isFeatured: true,
    isNew: true,
    views: 1123,
    relatedCars: [
        'new-hr-v',
        'all-new-cr-v'
    ],
    createdAt: '2024-02-15',
    updatedAt: '2024-02-15'
};
}),
"[project]/data/cars/n7x.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "n7x",
    ()=>n7x
]);
const n7x = {
    id: 'brv-n7x-2024',
    slug: 'all-new-br-v-n7x',
    name: 'All New BR-V N7X',
    model: 'BR-V N7X',
    category: 'MPV',
    priceRange: 'Rp 310 - 380 Juta',
    startingPrice: 310000000,
    typeCount: 3,
    year: 2024,
    images: {
        main: '/images/cars/all-new-br-v-n7x/main.jpg',
        gallery: [
            '/images/cars/all-new-br-v-n7x/gallery-1.jpg',
            '/images/cars/all-new-br-v-n7x/gallery-2.jpg',
            '/images/cars/all-new-br-v-n7x/gallery-3.jpg'
        ],
        thumbnail: '/images/cars/all-new-br-v-n7x/thumbnail.jpg',
        colorOptions: [
            '/images/cars/all-new-br-v-n7x/colors/red.jpg',
            '/images/cars/all-new-br-v-n7x/colors/black.jpg',
            '/images/cars/all-new-br-v-n7x/colors/white.jpg'
        ]
    },
    variants: [
        {
            id: 'brv-n7x-premium',
            type: 'ALL NEW BR-V N7X PREMIUM',
            price: 380000000,
            priceFormatted: 'Rp 380.000.000',
            features: [
                '7-Seater Premium',
                'Full LED Headlights',
                '8-inch Touchscreen',
                'Leather Seats',
                '6 Airbags',
                'Honda SENSING'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    description: 'All New BR-V N7X adalah varian premium dengan fitur dan teknologi terkini untuk pengalaman berkendara yang lebih eksklusif.',
    shortDescription: 'Varian premium BR-V dengan fitur dan teknologi terkini.',
    tags: [
        'MPV',
        'Premium',
        '7-Seater',
        'Honda SENSING'
    ],
    isFeatured: true,
    isNew: true,
    views: 678,
    relatedCars: [
        'all-new-br-v',
        'all-new-cr-v'
    ],
    createdAt: '2024-02-10',
    updatedAt: '2024-02-10'
};
}),
"[project]/data/cars/index.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cars",
    ()=>cars
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brio$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/brio.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrv$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/hrv.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$crv$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/crv.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$wrv$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/wrv.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brv$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/brv.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civic$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/civic.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$accord$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/accord.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$stepwgn$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/stepwgn.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$cityhatchback$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/cityhatchback.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civictyper$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/civictyper.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrvehev$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/hrvehev.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$n7x$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/n7x.ts [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const cars = [
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brio$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["brio"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrv$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hrv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$crv$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["crv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$wrv$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["wrv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brv$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["brv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civic$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["civic"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$accord$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["accord"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$stepwgn$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["stepwgn"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$cityhatchback$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cityhatchback"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civictyper$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["civicTypeR"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrvehev$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hrvehev"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$n7x$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["n7x"]
];
}),
"[project]/components/ui/Card.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Card
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const paddingStyles = {
    none: '',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8'
};
const shadowStyles = {
    none: '',
    sm: 'shadow-sm',
    md: 'shadow-md',
    lg: 'shadow-lg'
};
function Card({ children, className = '', padding = 'md', shadow = 'md', border = true, hover = false }) {
    const borderStyle = border ? 'border border-gray-200' : '';
    const hoverStyle = hover ? 'hover:shadow-xl transition-shadow duration-300' : '';
    const combinedClassName = `
    bg-white rounded-xl
    ${paddingStyles[padding]}
    ${shadowStyles[shadow]}
    ${borderStyle}
    ${hoverStyle}
    ${className}
  `.trim();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: combinedClassName,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/Card.tsx",
        lineNumber: 47,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/cars/CarCard.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/star.js [app-ssr] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$fuel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Fuel$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/fuel.js [app-ssr] (ecmascript) <export default as Fuel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/users.js [app-ssr] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/settings.js [app-ssr] (ecmascript) <export default as Settings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-ssr] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-ssr] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$badge$2d$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BadgeCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/badge-check.js [app-ssr] (ecmascript) <export default as BadgeCheck>");
;
;
;
;
;
function CarCard({ car, className = '' }) {
    const formatPrice = (price)=>{
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(price);
    };
    // Fallback untuk data yang optional
    const firstVariant = car.variants[0];
    const transmission = firstVariant?.transmission || 'CVT';
    const fuelType = firstVariant?.fuelType || 'Bensin';
    const engineCapacity = firstVariant?.engineCapacity || '1.5L';
    const seating = car.specs?.capacity?.seating || '5';
    const fuelConsumption = car.specs?.performance?.fuelConsumption || '18 KM/L';
    // Get transmission icon
    const getTransmissionIcon = (transmission)=>{
        switch(transmission){
            case 'Manual':
                return '🚗';
            case 'Automatic':
                return '⚡';
            case 'CVT':
                return '🔄';
            default:
                return '🚗';
        }
    };
    // Get fuel type color
    const getFuelTypeColor = (fuelType)=>{
        switch(fuelType){
            case 'Bensin':
                return 'bg-blue-100 text-blue-800 border-blue-200';
            case 'Diesel':
                return 'bg-gray-100 text-gray-800 border-gray-200';
            case 'Hybrid':
                return 'bg-green-100 text-green-800 border-green-200';
            case 'Electric':
                return 'bg-purple-100 text-purple-800 border-purple-200';
            default:
                return 'bg-gray-100 text-gray-800 border-gray-200';
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        hover: true,
        className: `h-full flex flex-col group overflow-hidden ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative h-52 bg-gradient-to-br from-gray-50 to-gray-100 rounded-t-xl overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: car.images.main || '/images/car-placeholder.jpg',
                        alt: car.name,
                        fill: true,
                        className: "object-cover group-hover:scale-105 transition duration-500",
                        sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    }, void 0, false, {
                        fileName: "[project]/components/cars/CarCard.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    }, void 0, false, {
                        fileName: "[project]/components/cars/CarCard.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-3 left-3 flex flex-col space-y-2",
                        children: [
                            car.isNew && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "bg-gradient-to-r from-green-500 to-emerald-600 text-white text-xs px-3 py-1.5 rounded-full font-bold shadow-lg flex items-center space-x-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$badge$2d$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BadgeCheck$3e$__["BadgeCheck"], {
                                        className: "w-3 h-3"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarCard.tsx",
                                        lineNumber: 79,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "BARU"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarCard.tsx",
                                        lineNumber: 80,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/CarCard.tsx",
                                lineNumber: 78,
                                columnNumber: 13
                            }, this),
                            car.isFeatured && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "bg-gradient-to-r from-yellow-500 to-orange-500 text-white text-xs px-3 py-1.5 rounded-full font-bold shadow-lg flex items-center space-x-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                                        className: "w-3 h-3 fill-current"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarCard.tsx",
                                        lineNumber: 85,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "FEATURED"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarCard.tsx",
                                        lineNumber: 86,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/CarCard.tsx",
                                lineNumber: 84,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/CarCard.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-3 right-3 flex flex-col space-y-2 items-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "bg-white/90 backdrop-blur-sm text-gray-900 text-xs px-3 py-1.5 rounded-full font-semibold border border-white/50",
                                children: car.category
                            }, void 0, false, {
                                fileName: "[project]/components/cars/CarCard.tsx",
                                lineNumber: 94,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-black/70 text-white text-xs px-2 py-1 rounded-full flex items-center space-x-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                                className: "w-3 h-3"
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarCard.tsx",
                                                lineNumber: 101,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: car.views
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarCard.tsx",
                                                lineNumber: 102,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/cars/CarCard.tsx",
                                        lineNumber: 100,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-black/70 text-white text-xs px-2 py-1 rounded-full",
                                        children: [
                                            car.variants.length,
                                            " Varian"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/cars/CarCard.tsx",
                                        lineNumber: 104,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/CarCard.tsx",
                                lineNumber: 99,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/CarCard.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-3 left-3 right-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gradient-to-r from-green-500 to-emerald-600 text-white p-3 rounded-xl shadow-lg",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-sm font-bold",
                                    children: formatPrice(car.startingPrice)
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarCard.tsx",
                                    lineNumber: 113,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-xs opacity-90 mt-1",
                                    children: car.priceRange
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarCard.tsx",
                                    lineNumber: 114,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarCard.tsx",
                            lineNumber: 112,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/cars/CarCard.tsx",
                        lineNumber: 111,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/cars/CarCard.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grow p-5 flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-start mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-bold text-gray-900 line-clamp-1 pr-2",
                                    children: car.name
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarCard.tsx",
                                    lineNumber: 124,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/cars/CarCard.tsx",
                                lineNumber: 123,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-600 text-sm flex items-center space-x-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                            className: "w-3 h-3"
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/CarCard.tsx",
                                            lineNumber: 131,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: car.model
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/CarCard.tsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarCard.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/cars/CarCard.tsx",
                                lineNumber: 129,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-600 text-sm line-clamp-2 leading-relaxed",
                                children: car.shortDescription
                            }, void 0, false, {
                                fileName: "[project]/components/cars/CarCard.tsx",
                                lineNumber: 136,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/CarCard.tsx",
                        lineNumber: 122,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4 p-3 bg-gray-50 rounded-lg",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-2 gap-3 text-xs",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center space-x-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-sm",
                                                children: getTransmissionIcon(transmission)
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarCard.tsx",
                                                lineNumber: 146,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/CarCard.tsx",
                                            lineNumber: 145,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-900 font-semibold capitalize",
                                                    children: transmission
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/CarCard.tsx",
                                                    lineNumber: 149,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-500",
                                                    children: "Transmisi"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/CarCard.tsx",
                                                    lineNumber: 150,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/CarCard.tsx",
                                            lineNumber: 148,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarCard.tsx",
                                    lineNumber: 144,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center space-x-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$fuel$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Fuel$3e$__["Fuel"], {
                                                className: "w-4 h-4 text-blue-500"
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarCard.tsx",
                                                lineNumber: 156,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/CarCard.tsx",
                                            lineNumber: 155,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-900 font-semibold",
                                                    children: fuelType
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/CarCard.tsx",
                                                    lineNumber: 159,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-500",
                                                    children: "Bahan Bakar"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/CarCard.tsx",
                                                    lineNumber: 160,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/CarCard.tsx",
                                            lineNumber: 158,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarCard.tsx",
                                    lineNumber: 154,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center space-x-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                                className: "w-4 h-4 text-green-500"
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarCard.tsx",
                                                lineNumber: 166,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/CarCard.tsx",
                                            lineNumber: 165,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-900 font-semibold",
                                                    children: [
                                                        seating,
                                                        " Kursi"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/cars/CarCard.tsx",
                                                    lineNumber: 169,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-500",
                                                    children: "Kapasitas"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/CarCard.tsx",
                                                    lineNumber: 170,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/CarCard.tsx",
                                            lineNumber: 168,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarCard.tsx",
                                    lineNumber: 164,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center space-x-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"], {
                                                className: "w-4 h-4 text-purple-500"
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/CarCard.tsx",
                                                lineNumber: 176,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/CarCard.tsx",
                                            lineNumber: 175,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-900 font-semibold",
                                                    children: engineCapacity
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/CarCard.tsx",
                                                    lineNumber: 179,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-gray-500",
                                                    children: "Mesin"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/CarCard.tsx",
                                                    lineNumber: 180,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/CarCard.tsx",
                                            lineNumber: 178,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarCard.tsx",
                                    lineNumber: 174,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarCard.tsx",
                            lineNumber: 143,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/cars/CarCard.tsx",
                        lineNumber: 142,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex space-x-2 mt-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: `/mobil/${car.slug}`,
                                className: "flex-1 bg-gradient-to-r from-gray-900 to-gray-700 text-white text-center py-3 px-4 rounded-xl font-semibold hover:from-gray-800 hover:to-gray-600 transition-all duration-300 shadow-lg hover:shadow-xl group flex items-center justify-center space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Detail Mobil"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarCard.tsx",
                                        lineNumber: 192,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-1 h-1 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarCard.tsx",
                                        lineNumber: 193,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/CarCard.tsx",
                                lineNumber: 188,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: `https://wa.me/6287852432636?text=${encodeURIComponent(`Halo, saya tertarik dengan ${car.name} ${car.model} ${car.year}. Bisa info lebih lanjut mengenai harga, spesifikasi, dan test drive?`)}`,
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "flex-1 bg-gradient-to-r from-green-500 to-green-600 text-white text-center py-3 px-4 rounded-xl font-semibold hover:from-green-600 hover:to-green-700 transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "WhatsApp"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarCard.tsx",
                                        lineNumber: 202,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-1 h-1 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarCard.tsx",
                                        lineNumber: 203,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/CarCard.tsx",
                                lineNumber: 196,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/CarCard.tsx",
                        lineNumber: 187,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/cars/CarCard.tsx",
                lineNumber: 120,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/cars/CarCard.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/cars/CarGrid.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarCard.tsx [app-ssr] (ecmascript)");
;
;
function CarGrid({ cars, loading = false }) {
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
            children: [
                ...Array(6)
            ].map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "animate-pulse",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-gray-200 h-64 rounded-xl"
                    }, void 0, false, {
                        fileName: "[project]/components/cars/CarGrid.tsx",
                        lineNumber: 15,
                        columnNumber: 13
                    }, this)
                }, index, false, {
                    fileName: "[project]/components/cars/CarGrid.tsx",
                    lineNumber: 14,
                    columnNumber: 11
                }, this))
        }, void 0, false, {
            fileName: "[project]/components/cars/CarGrid.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this);
    }
    if (cars.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center py-12",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-6xl mb-4",
                    children: "🚗"
                }, void 0, false, {
                    fileName: "[project]/components/cars/CarGrid.tsx",
                    lineNumber: 25,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-xl font-semibold text-gray-600 mb-2",
                    children: "Mobil tidak ditemukan"
                }, void 0, false, {
                    fileName: "[project]/components/cars/CarGrid.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-500",
                    children: "Coba gunakan filter yang berbeda atau hubungi sales kami untuk informasi lebih lanjut."
                }, void 0, false, {
                    fileName: "[project]/components/cars/CarGrid.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/cars/CarGrid.tsx",
            lineNumber: 24,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
        children: cars.map((car)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                car: car
            }, car.id, false, {
                fileName: "[project]/components/cars/CarGrid.tsx",
                lineNumber: 39,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/components/cars/CarGrid.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/cars/CarFilter.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarFilter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Card.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
function CarFilter({ cars, onFilterChange }) {
    const [filters, setFilters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        category: '',
        searchQuery: ''
    });
    // Extract unique categories
    const categories = [
        'All',
        ...new Set(cars.map((car)=>car.category))
    ];
    const handleFilterChange = (newFilters)=>{
        const updatedFilters = {
            ...filters,
            ...newFilters
        };
        setFilters(updatedFilters);
        // Apply filters
        let filtered = cars;
        // Search filter
        if (updatedFilters.searchQuery) {
            filtered = filtered.filter((car)=>car.name.toLowerCase().includes(updatedFilters.searchQuery.toLowerCase()) || car.model.toLowerCase().includes(updatedFilters.searchQuery.toLowerCase()) || car.description.toLowerCase().includes(updatedFilters.searchQuery.toLowerCase()));
        }
        // Category filter
        if (updatedFilters.category && updatedFilters.category !== 'All') {
            filtered = filtered.filter((car)=>car.category === updatedFilters.category);
        }
        onFilterChange(filtered);
    };
    const clearFilters = ()=>{
        setFilters({
            category: '',
            searchQuery: ''
        });
        onFilterChange(cars);
    };
    const hasActiveFilters = filters.category || filters.searchQuery;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        className: "mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    placeholder: "Cari mobil Honda...",
                                    value: filters.searchQuery,
                                    onChange: (e)=>handleFilterChange({
                                            searchQuery: e.target.value
                                        }),
                                    className: "w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-honda-red focus:border-transparent"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarFilter.tsx",
                                    lineNumber: 63,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute right-3 top-3 text-gray-400",
                                    children: "🔍"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarFilter.tsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarFilter.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/cars/CarFilter.tsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center space-x-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: filters.category,
                                onChange: (e)=>handleFilterChange({
                                        category: e.target.value
                                    }),
                                className: "px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-honda-red focus:border-transparent",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: "Semua Kategori"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/CarFilter.tsx",
                                        lineNumber: 81,
                                        columnNumber: 13
                                    }, this),
                                    categories.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: category,
                                            children: category
                                        }, category, false, {
                                            fileName: "[project]/components/cars/CarFilter.tsx",
                                            lineNumber: 83,
                                            columnNumber: 15
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/CarFilter.tsx",
                                lineNumber: 76,
                                columnNumber: 11
                            }, this),
                            hasActiveFilters && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: clearFilters,
                                className: "px-4 py-3 text-gray-600 hover:text-gray-800 transition font-semibold",
                                children: "Clear"
                            }, void 0, false, {
                                fileName: "[project]/components/cars/CarFilter.tsx",
                                lineNumber: 91,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/CarFilter.tsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/cars/CarFilter.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            hasActiveFilters && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 flex items-center space-x-2 text-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-gray-600",
                        children: "Filter aktif:"
                    }, void 0, false, {
                        fileName: "[project]/components/cars/CarFilter.tsx",
                        lineNumber: 104,
                        columnNumber: 11
                    }, this),
                    filters.searchQuery && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "bg-blue-100 text-blue-800 px-2 py-1 rounded-full",
                        children: [
                            'Search: "',
                            filters.searchQuery,
                            '"'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/CarFilter.tsx",
                        lineNumber: 106,
                        columnNumber: 13
                    }, this),
                    filters.category && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "bg-green-100 text-green-800 px-2 py-1 rounded-full",
                        children: [
                            "Kategori: ",
                            filters.category
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/CarFilter.tsx",
                        lineNumber: 111,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/cars/CarFilter.tsx",
                lineNumber: 103,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/cars/CarFilter.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/mobil/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MobilPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/index.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarGrid$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarGrid.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFilter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarFilter.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
function MobilPage() {
    const [filteredCars, setFilteredCars] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cars"]);
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    // Stats untuk display
    const stats = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const totalCars = __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cars"].length;
        const totalModels = new Set(__TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cars"].map((car)=>car.model)).size;
        const totalCategories = new Set(__TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cars"].map((car)=>car.category)).size;
        return {
            totalCars,
            totalModels,
            totalCategories
        };
    }, []);
    const handleFilterChange = (filteredCars)=>{
        setFilteredCars(filteredCars);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gray-50 py-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center mb-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-4xl md:text-5xl font-bold text-gray-900 mb-4",
                            children: "Katalog Mobil Honda"
                        }, void 0, false, {
                            fileName: "[project]/app/mobil/page.tsx",
                            lineNumber: 31,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xl text-gray-600 max-w-3xl mx-auto mb-6",
                            children: "Temukan mobil Honda impian Anda dengan berbagai pilihan model terbaru dan teknologi canggih dari dealer resmi Honda Surabaya."
                        }, void 0, false, {
                            fileName: "[project]/app/mobil/page.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-white rounded-lg p-4 shadow-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-2xl font-bold text-honda-red",
                                            children: stats.totalCars
                                        }, void 0, false, {
                                            fileName: "[project]/app/mobil/page.tsx",
                                            lineNumber: 42,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-600",
                                            children: "Total Mobil"
                                        }, void 0, false, {
                                            fileName: "[project]/app/mobil/page.tsx",
                                            lineNumber: 43,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/mobil/page.tsx",
                                    lineNumber: 41,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-white rounded-lg p-4 shadow-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-2xl font-bold text-honda-red",
                                            children: stats.totalModels
                                        }, void 0, false, {
                                            fileName: "[project]/app/mobil/page.tsx",
                                            lineNumber: 46,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-600",
                                            children: "Model Tersedia"
                                        }, void 0, false, {
                                            fileName: "[project]/app/mobil/page.tsx",
                                            lineNumber: 47,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/mobil/page.tsx",
                                    lineNumber: 45,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-white rounded-lg p-4 shadow-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-2xl font-bold text-honda-red",
                                            children: stats.totalCategories
                                        }, void 0, false, {
                                            fileName: "[project]/app/mobil/page.tsx",
                                            lineNumber: 50,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-600",
                                            children: "Kategori"
                                        }, void 0, false, {
                                            fileName: "[project]/app/mobil/page.tsx",
                                            lineNumber: 51,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/mobil/page.tsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/mobil/page.tsx",
                            lineNumber: 40,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/mobil/page.tsx",
                    lineNumber: 30,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFilter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    cars: __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cars"],
                    onFilterChange: handleFilterChange
                }, void 0, false, {
                    fileName: "[project]/app/mobil/page.tsx",
                    lineNumber: 57,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-between items-center mb-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-2xl font-semibold text-gray-900",
                                    children: "Semua Mobil Honda"
                                }, void 0, false, {
                                    fileName: "[project]/app/mobil/page.tsx",
                                    lineNumber: 62,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-gray-600",
                                    children: [
                                        "Menampilkan ",
                                        filteredCars.length,
                                        " dari ",
                                        __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cars"].length,
                                        " mobil"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/mobil/page.tsx",
                                    lineNumber: 65,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/mobil/page.tsx",
                            lineNumber: 61,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "hidden md:block",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                className: "px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-honda-red",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        children: "Urutkan: Rekomendasi"
                                    }, void 0, false, {
                                        fileName: "[project]/app/mobil/page.tsx",
                                        lineNumber: 73,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        children: "Harga: Terendah ke Tertinggi"
                                    }, void 0, false, {
                                        fileName: "[project]/app/mobil/page.tsx",
                                        lineNumber: 74,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        children: "Harga: Tertinggi ke Terendah"
                                    }, void 0, false, {
                                        fileName: "[project]/app/mobil/page.tsx",
                                        lineNumber: 75,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        children: "Nama: A-Z"
                                    }, void 0, false, {
                                        fileName: "[project]/app/mobil/page.tsx",
                                        lineNumber: 76,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/mobil/page.tsx",
                                lineNumber: 72,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/mobil/page.tsx",
                            lineNumber: 71,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/mobil/page.tsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarGrid$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    cars: filteredCars
                }, void 0, false, {
                    fileName: "[project]/app/mobil/page.tsx",
                    lineNumber: 82,
                    columnNumber: 9
                }, this),
                filteredCars.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-12 text-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white rounded-xl p-8 shadow-lg max-w-2xl mx-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-2xl font-bold text-gray-900 mb-4",
                                children: "Tidak menemukan yang sesuai?"
                            }, void 0, false, {
                                fileName: "[project]/app/mobil/page.tsx",
                                lineNumber: 88,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-600 mb-6",
                                children: "Hubungi sales consultant kami untuk informasi lebih lengkap tentang model, warna, dan ketersediaan unit."
                            }, void 0, false, {
                                fileName: "[project]/app/mobil/page.tsx",
                                lineNumber: 91,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col sm:flex-row gap-4 justify-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "https://wa.me/6287852432636",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "bg-green-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-600 transition",
                                        children: "💬 Chat WhatsApp"
                                    }, void 0, false, {
                                        fileName: "[project]/app/mobil/page.tsx",
                                        lineNumber: 96,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "tel:087852432636",
                                        className: "bg-honda-red text-white px-8 py-3 rounded-lg font-semibold hover:bg-red-700 transition",
                                        children: "📞 Telepon Sekarang"
                                    }, void 0, false, {
                                        fileName: "[project]/app/mobil/page.tsx",
                                        lineNumber: 104,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/mobil/page.tsx",
                                lineNumber: 95,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/mobil/page.tsx",
                        lineNumber: 87,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/mobil/page.tsx",
                    lineNumber: 86,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/mobil/page.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/mobil/page.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=_3e3bb8f8._.js.map