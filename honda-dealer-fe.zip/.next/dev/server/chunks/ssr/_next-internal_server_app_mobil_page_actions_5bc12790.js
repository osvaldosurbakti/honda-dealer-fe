module.exports = [
"[project]/.next-internal/server/app/mobil/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_mobil_page_actions_5bc12790.js.map