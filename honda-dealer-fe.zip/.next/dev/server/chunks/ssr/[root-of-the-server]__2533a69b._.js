module.exports = [
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/data/cars/brio.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "brio",
    ()=>brio
]);
const brio = {
    id: 'brio-2024',
    slug: 'all-new-brio',
    name: 'All New BRIO',
    model: 'BRIO',
    category: 'Hatchback',
    priceRange: 'Rp 182,1 - 271,3 Juta',
    startingPrice: 182100000,
    videoUrl: 'https://youtu.be/BZhddbB5pvo?si=GBaeeLA6Kf7l9cJc',
    typeCount: 7,
    images: {
        main: '/images/cars/all-new-brio/main.jpg'
    },
    variants: [
        {
            id: 'brio-s-mt',
            type: 'ALL NEW BRIO S MT',
            price: 182100000,
            priceFormatted: 'Rp 182.100.000',
            features: [
                'Front Dual SRS Airbags',
                'ABS dengan EBD',
                'Power Steering',
                'AC Manual',
                'Audio dengan USB',
                'Rem Depan Cakram',
                'Rem Belakang Tromol',
                'Velg Steel 14"',
                'Seat Fabric',
                'Immobilizer System',
                'Rear Defogger'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-e-mt',
            type: 'ALL NEW BRIO E MT',
            price: 195200000,
            priceFormatted: 'Rp 195.200.000',
            features: [
                'Front Dual SRS Airbags',
                'ABS dengan EBD',
                'Power Steering',
                'AC Manual',
                'Audio dengan USB & Bluetooth',
                'Power Window Depan',
                'Central Door Lock',
                'Remote Keyless Entry',
                'Velg Steel 14" dengan Cover',
                'Body Color Door Handle & Mirror',
                'Rear Spoiler'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-e-cvt',
            type: 'ALL NEW BRIO E CVT',
            price: 213200000,
            priceFormatted: 'Rp 213.200.000',
            features: [
                'Front Dual SRS Airbags',
                'ABS dengan EBD',
                'Power Steering',
                'AC Manual',
                'Audio dengan USB & Bluetooth',
                'Power Window Depan',
                'Central Door Lock',
                'Remote Keyless Entry',
                'Transmisi CVT',
                'Econ Mode',
                'Body Color Door Handle & Mirror',
                'Rear Spoiler'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-mt',
            type: 'ALL NEW BRIO RS MT',
            price: 258600000,
            priceFormatted: 'Rp 258.600.000',
            features: [
                'RS Body Kit & Grille',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-mt-tt',
            type: 'ALL NEW BRIO RS MT TWO TONE',
            price: 261100000,
            priceFormatted: 'Rp 261.100.000',
            features: [
                'RS Body Kit & Grille',
                'Two-Tone Color',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher',
                'Black Roof'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-cvt',
            type: 'ALL NEW BRIO RS CVT',
            price: 268800000,
            priceFormatted: 'Rp 268.800.000',
            features: [
                'RS Body Kit & Grille',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'Transmisi CVT',
                'Econ Mode',
                'Paddle Shift',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        },
        {
            id: 'brio-rs-cvt-tt',
            type: 'ALL NEW BRIO RS CVT TWO TONE',
            price: 271300000,
            priceFormatted: 'Rp 271.300.000',
            features: [
                'RS Body Kit & Grille',
                'Two-Tone Color',
                'Front Fog Lamps',
                '14-inch Alloy Wheels',
                'Touchscreen Audio dengan USB & Bluetooth',
                'Rear Parking Sensor',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'RS Seat Fabric',
                'Multi-Info Display',
                'Transmisi CVT',
                'Econ Mode',
                'Paddle Shift',
                'RS Front & Rear Bumper',
                'Chrome Exhaust Finisher',
                'Black Roof'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.2L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '3610 mm',
            width: '1680 mm',
            height: '1500 mm',
            wheelbase: '2345 mm',
            weight: '890 - 920 kg'
        },
        performance: {
            engine: '1.2L SOHC i-VTEC',
            displacement: '1198 cc',
            maxPower: '90 PS / 6000 rpm',
            maxTorque: '110 Nm / 4800 rpm',
            transmission: '5-speed Manual / CVT',
            fuelConsumption: '20,0 km/L (MT) / 19,0 km/L (CVT)',
            acceleration: '0-100 km/h dalam 13.5 detik',
            topSpeed: '160 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '35 Liter',
            luggage: '258 Liter',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'LED Headlights (RS)',
                'Front Fog Lamps (RS)',
                '14-inch Alloy Wheels (RS)',
                'RS Body Kit'
            ],
            interior: [
                'Touchscreen Audio',
                'Multi-Info Display',
                'Fabric Seats',
                'RS Seat Fabric'
            ],
            safety: [
                'Dual SRS Airbags',
                'ABS dengan EBD',
                'Immobilizer',
                'Rear Parking Sensor (RS)'
            ],
            entertainment: [
                'USB & Bluetooth Audio',
                '4 Speakers',
                'Steering Audio Control (RS)'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Fun & Youthful',
            description: 'Brio hadir dengan desain yang fun, youthful, dan compact, perfect untuk mobilitas perkotaan. Varian RS dilengkapi dengan body kit sporty yang membuat tampilannya semakin aggressive.',
            features: [
                'Compact Hatchback Design',
                'RS Body Kit (Varian RS)',
                '14-inch Alloy Wheels (RS)',
                'Front Fog Lamps (RS)',
                'Two-Tone Color Options',
                'Chrome Accents'
            ]
        },
        interior: {
            title: 'Interior Praktis & Fungsional',
            description: 'Kabin yang didesain dengan layout praktis dan fungsional, menawarkan kenyamanan dan kemudahan penggunaan dalam berkendara sehari-hari.',
            features: [
                'Touchscreen Audio System',
                'Multi-Info Display',
                'Fabric Seats dengan RS Variant',
                'Power Windows',
                'Steering Wheel dengan Audio Control (RS)',
                'Cabin Storage yang Luas'
            ]
        },
        safety: {
            title: 'Keselamatan yang Terjangkau',
            description: 'Dilengkapi dengan fitur keselamatan dasar yang essential untuk perlindungan pengemudi dan penumpang dalam berkendara sehari-hari.',
            features: [
                'Dual Front SRS Airbags',
                'Anti-lock Braking System (ABS)',
                'Electronic Brake-force Distribution (EBD)',
                'Immobilizer System',
                'Rear Parking Sensor (RS)',
                'High-Mounted Stop Lamp'
            ]
        },
        technology: {
            title: 'Teknologi untuk Kenyamanan Berkendara',
            description: 'Berbagai fitur teknologi yang mendukung kenyamanan dan efisiensi dalam berkendara sehari-hari.',
            features: [
                'ECON Mode (CVT)',
                'Paddle Shift (RS CVT)',
                'Remote Keyless Entry',
                'Power Steering',
                'Multi-Info Display',
                'Audio System dengan USB & Bluetooth'
            ]
        }
    },
    description: 'All New Brio adalah hatchback kompak yang sempurna untuk mobilitas perkotaan. Dengan desain yang fun dan youthful, Brio menawarkan efisiensi bahan bakar yang excellent dan kemudahan dalam bermanuver. Tersedia dalam berbagai varian mulai dari S hingga RS dengan pilihan transmisi Manual dan CVT, dilengkapi dengan fitur keselamatan dan teknologi yang memadai untuk kebutuhan sehari-hari.',
    shortDescription: 'Hatchback kompak yang fun dan efisien untuk mobilitas perkotaan dengan pilihan 7 varian termasuk RS yang sporty.',
    tags: [
        'Hatchback',
        'City Car',
        'Economical',
        'Compact',
        'RS Model',
        'Two-Tone',
        'Fuel Efficient'
    ],
    isFeatured: true,
    isNew: true,
    views: 865,
    relatedCars: [
        'new-hr-v',
        'wr-v',
        'mobilio'
    ],
    createdAt: '2024-01-10',
    updatedAt: '2024-01-10'
};
}),
"[project]/data/cars/hrv.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hrv",
    ()=>hrv
]);
const hrv = {
    id: 'hrv-2024',
    slug: 'all-new-hr-v',
    name: 'All New HR-V',
    model: 'HR-V',
    category: 'SUV',
    priceRange: 'Rp 403,8 - 428,4 Juta',
    startingPrice: 403800000,
    typeCount: 4,
    videoUrl: 'https://www.youtube.com/watch?v=7YWZfOnIy6o',
    images: {
        main: '/images/cars/all-new-hr-v/main.jpg'
    },
    variants: [
        {
            id: 'hrv-e',
            type: 'ALL NEW HR-V E',
            price: 403800000,
            priceFormatted: 'Rp 403.800.000',
            features: [
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '4 SRS Airbags',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Multi-Angle Rearview Camera',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Auto AC',
                'Rear AC Vents',
                'Fabric Seats',
                'Power Adjustable Driver Seat',
                'Cruise Control',
                'Vehicle Stability Assist (VSA)',
                'Anti-Lock Braking System (ABS)',
                'Electronic Brake-force Distribution (EBD)',
                'Hill Start Assist'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'hrv-e-tt',
            type: 'ALL NEW HR-V E TWO TONE',
            price: 406300000,
            priceFormatted: 'Rp 406.300.000',
            features: [
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '4 SRS Airbags',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Multi-Angle Rearview Camera',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Auto AC',
                'Rear AC Vents',
                'Fabric Seats',
                'Power Adjustable Driver Seat',
                'Cruise Control',
                'Vehicle Stability Assist (VSA)',
                'Anti-Lock Braking System (ABS)',
                'Electronic Brake-force Distribution (EBD)',
                'Hill Start Assist',
                'Two-Tone Color',
                'Black Roof'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'hrv-e-plus',
            type: 'ALL NEW HR-V E+',
            price: 425900000,
            priceFormatted: 'Rp 425.900.000',
            features: [
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING',
                'LaneWatch Camera',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Multi-Angle Rearview Camera',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Auto AC',
                'Rear AC Vents',
                'Fabric Seats',
                'Power Adjustable Driver Seat',
                'Cruise Control',
                'Vehicle Stability Assist (VSA)',
                'Anti-Lock Braking System (ABS)',
                'Electronic Brake-force Distribution (EBD)',
                'Hill Start Assist',
                'Auto High Beam',
                'Rain Sensing Wipers',
                'Electrostatic Touch AC Panel'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'hrv-e-plus-tt',
            type: 'ALL NEW HR-V E+ TWO TONE',
            price: 428400000,
            priceFormatted: 'Rp 428.400.000',
            features: [
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING',
                'LaneWatch Camera',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Multi-Angle Rearview Camera',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Auto AC',
                'Rear AC Vents',
                'Fabric Seats',
                'Power Adjustable Driver Seat',
                'Cruise Control',
                'Vehicle Stability Assist (VSA)',
                'Anti-Lock Braking System (ABS)',
                'Electronic Brake-force Distribution (EBD)',
                'Hill Start Assist',
                'Auto High Beam',
                'Rain Sensing Wipers',
                'Electrostatic Touch AC Panel',
                'Two-Tone Color',
                'Black Roof'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4385 mm',
            width: '1790 mm',
            height: '1590 mm',
            wheelbase: '2610 mm',
            weight: '1245 - 1285 kg'
        },
        performance: {
            engine: '1.5L DOHC i-VTEC',
            displacement: '1498 cc',
            maxPower: '121 PS / 6600 rpm',
            maxTorque: '145 Nm / 4300 rpm',
            transmission: 'CVT',
            fuelConsumption: '15,9 km/L',
            acceleration: '0-100 km/h dalam 10.8 detik',
            topSpeed: '185 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '40 Liter',
            luggage: '437 Liter',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                'Two-Tone Color Options',
                'Power Slide Moonroof'
            ],
            interior: [
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                'Fabric Seats',
                'Auto AC',
                'Electrostatic Touch AC Panel (E+)'
            ],
            safety: [
                '6 SRS Airbags (E+)',
                'Honda SENSING (E+)',
                'Multi-Angle Rearview Camera',
                'Vehicle Stability Assist',
                'Hill Start Assist'
            ],
            entertainment: [
                'Apple CarPlay & Android Auto',
                '4 Speakers',
                'USB Charging Ports'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Elegant & Futuristik',
            description: 'HR-V menghadirkan desain SUV yang elegant dan futuristik dengan garis bodi yang tajam dan proporsi yang dinamis. Tampilan premium dilengkapi dengan fitur LED lengkap dan pilihan warna two-tone.',
            features: [
                'SUV Compact Design',
                'LED Headlights dengan Daytime Running Lights',
                '17-inch Alloy Wheels',
                'Two-Tone Color Options',
                'Power Slide Moonroof',
                'Chrome Accents',
                'Hidden Rear Door Handles'
            ]
        },
        interior: {
            title: 'Interior Premium & Spacious',
            description: 'Kabin yang luas dan premium dengan material berkualitas tinggi. Dilengkapi dengan teknologi terkini dan fitur kenyamanan untuk pengalaman berkendara yang luxurious.',
            features: [
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                'Magic Seat Configuration',
                'Electrostatic Touch AC Panel (E+)',
                'Auto AC dengan Rear Vents',
                'Power Adjustable Driver Seat',
                'Multi-Angle Rearview Camera'
            ]
        },
        safety: {
            title: 'Keselamatan Komprehensif dengan Honda SENSING',
            description: 'Dilengkapi dengan fitur keselamatan lengkap termasuk Honda SENSING pada varian E+ untuk perlindungan maksimal dalam setiap perjalanan.',
            features: [
                'Honda SENSING (E+)',
                '6 SRS Airbags (E+)',
                'Vehicle Stability Assist (VSA)',
                'Anti-Lock Braking System (ABS)',
                'Multi-Angle Rearview Camera',
                'Hill Start Assist',
                'Electric Parking Brake dengan Auto Brake Hold'
            ]
        },
        technology: {
            title: 'Teknologi Canggih untuk Kenyamanan Maksimal',
            description: 'Berbagai fitur teknologi modern yang mendukung kenyamanan, keselamatan, dan konektivitas dalam berkendara sehari-hari.',
            features: [
                'Honda SENSING (E+)',
                'Apple CarPlay & Android Auto',
                'Push Start Button',
                'Keyless Entry System',
                'Electrostatic Touch AC Panel (E+)',
                'Rain Sensing Wipers (E+)',
                'Auto High Beam (E+)'
            ]
        }
    },
    description: 'All New HR-V adalah SUV compact premium yang menghadirkan desain elegant, interior yang spacious, dan teknologi canggih. Dengan pilihan varian E dan E+ yang dilengkapi Honda SENSING, HR-V menawarkan pengalaman berkendara yang nyaman, aman, dan connected untuk perjalanan urban maupun adventure.',
    shortDescription: 'SUV compact premium dengan desain elegant, interior spacious, dan Honda SENSING pada varian E+.',
    tags: [
        'SUV',
        'Premium',
        'Compact',
        'Honda SENSING',
        'Two-Tone',
        'Magic Seat',
        'Urban Adventure'
    ],
    isFeatured: true,
    isNew: true,
    views: 892,
    relatedCars: [
        'wrv-2024',
        'cr-v-2024'
    ],
    createdAt: '2024-03-15',
    updatedAt: '2024-03-15'
};
}),
"[project]/data/cars/crv.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "crv",
    ()=>crv
]);
const crv = {
    id: 'crv-2024',
    slug: 'all-new-cr-v',
    name: 'All New CR-V',
    model: 'CR-V',
    category: 'SUV',
    priceRange: 'Rp 762,2 - 828,7 Juta',
    startingPrice: 762200000,
    typeCount: 2,
    videoUrl: 'https://www.youtube.com/watch?v=PQUu4bHEAqk',
    images: {
        main: '/images/cars/all-new-cr-v/main.jpg'
    },
    variants: [
        {
            id: 'crv-15-turbo',
            type: 'ALL NEW CR-V 1.5L Turbo',
            price: 762200000,
            priceFormatted: 'Rp 762.200.000',
            features: [
                'LED Headlights dengan DRL',
                '18-inch Alloy Wheels',
                '9-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                'Wireless Charger',
                '6 SRS Airbags',
                'Honda SENSING',
                '360° Camera System',
                'Rear View Camera',
                'Push Start Button',
                'Smart Keyless Entry',
                'Auto AC Dual Zone',
                'Rear AC Vents',
                'Leather Seats',
                'Power Adjustable Driver & Passenger Seats',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Blind Spot Information',
                'Cross Traffic Monitor',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Panoramic Sunroof',
                'Power Tailgate',
                'Ambient Lighting',
                'Digital Meter Cluster',
                'Paddle Shifters'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L Turbo',
            available: true
        },
        {
            id: 'crv-rs-ehev',
            type: 'ALL NEW CR-V RS e:HEV',
            price: 828700000,
            priceFormatted: 'Rp 828.700.000',
            features: [
                'RS Exterior Package',
                'LED Headlights dengan DRL',
                '19-inch Alloy Wheels RS',
                '9-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                'Wireless Charger',
                '10.2-inch Digital Meter Cluster',
                'Head-Up Display',
                '6 SRS Airbags',
                'Honda SENSING 360',
                '360° Camera System',
                'Rear View Camera',
                'Push Start Button',
                'Smart Keyless Entry',
                'Auto AC Dual Zone dengan Ionizer',
                'Rear AC Vents',
                'Leather Seats dengan RS Embroidery',
                'Power Adjustable Driver & Passenger Seats',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Blind Spot Information',
                'Cross Traffic Monitor',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Panoramic Sunroof',
                'Power Tailgate',
                'Ambient Lighting',
                'Paddle Shifters',
                'e:HEV Hybrid System',
                'EV Drive Mode',
                'RS Sport Pedals',
                'Acoustic Front Glass'
            ],
            transmission: 'e-CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L e:HEV',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4703 mm',
            width: '1866 mm',
            height: '1680 mm',
            wheelbase: '2700 mm',
            weight: '1580 - 1680 kg'
        },
        performance: {
            engine: '1.5L DOHC Turbo VTEC / 2.0L e:HEV',
            displacement: '1498 cc / 1993 cc',
            maxPower: '193 PS / 6000 rpm (Turbo) | 184 PS (Combined) e:HEV',
            maxTorque: '243 Nm / 1700-5000 rpm (Turbo) | 315 Nm (Electric) e:HEV',
            transmission: 'CVT / e-CVT',
            fuelConsumption: '14,2 km/L (Turbo) | 23,8 km/L (e:HEV)',
            acceleration: '0-100 km/h dalam 9.5 detik (Turbo) | 8.7 detik (e:HEV)',
            topSpeed: '190 km/jam (Turbo) | 180 km/jam (e:HEV)'
        },
        capacity: {
            seating: '7 Seater',
            fuelTank: '53 Liter (Turbo) | 46 Liter (e:HEV)',
            luggage: '204 Liter (7-seater) | 582 Liter (5-seater mode)',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'LED Headlights dengan DRL',
                '18-inch/19-inch Alloy Wheels',
                'RS Package (e:HEV)',
                'Panoramic Sunroof',
                'Power Tailgate'
            ],
            interior: [
                '9-inch Touchscreen Display Audio',
                'Digital Meter Cluster',
                'Leather Seats',
                'Auto AC Dual Zone',
                'Panoramic Sunroof',
                'Head-Up Display (e:HEV)'
            ],
            safety: [
                '6 SRS Airbags',
                'Honda SENSING',
                '360° Camera System',
                'Blind Spot Information',
                'Cross Traffic Monitor'
            ],
            entertainment: [
                'Apple CarPlay & Android Auto',
                'Wireless Charger',
                '8 Speakers',
                'Ambient Lighting'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Premium & Tangguh',
            description: 'CR-V menghadirkan desain SUV premium yang tangguh dengan proporsi yang elegan dan modern. Tampilan yang sophisticated dilengkapi dengan fitur LED lengkap dan paket RS eksklusif untuk varian e:HEV.',
            features: [
                'Premium SUV Design',
                'LED Headlights dengan Daytime Running Lights',
                '18-inch Alloy Wheels (Turbo) / 19-inch RS Wheels (e:HEV)',
                'RS Exterior Package (e:HEV)',
                'Panoramic Sunroof',
                'Power Tailgate',
                'Chrome Accents',
                'Dual Exhaust Tip (Turbo)'
            ]
        },
        interior: {
            title: 'Interior Luxurious & Teknologi Terdepan',
            description: 'Kabin yang luxurious dengan material premium dan teknologi terkini. Dilengkapi dengan fitur kenyamanan dan hiburan canggih untuk pengalaman berkendara yang exceptional.',
            features: [
                '9-inch Touchscreen Display Audio',
                '10.2-inch Digital Meter Cluster (e:HEV)',
                'Head-Up Display (e:HEV)',
                'Leather Seats dengan RS Embroidery (e:HEV)',
                'Auto AC Dual Zone dengan Ionizer',
                'Panoramic Sunroof',
                'Power Adjustable Seats',
                'Ambient Lighting',
                'Wireless Charger'
            ]
        },
        safety: {
            title: 'Keselamatan Komprehensif dengan Honda SENSING 360',
            description: 'Dilengkapi dengan fitur keselamatan paling mutakhir termasuk Honda SENSING 360 pada varian e:HEV untuk perlindungan menyeluruh dalam setiap kondisi berkendara.',
            features: [
                'Honda SENSING / Honda SENSING 360 (e:HEV)',
                '6 SRS Airbags',
                '360° Camera System',
                'Blind Spot Information',
                'Cross Traffic Monitor',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Vehicle Stability Assist'
            ]
        },
        technology: {
            title: 'Teknologi Hybrid Terdepan & Fitur Canggih',
            description: 'Menghadirkan teknologi e:HEV hybrid yang efisien dan berbagai fitur canggih yang mendukung kenyamanan, keselamatan, dan konektivitas premium.',
            features: [
                'e:HEV Hybrid System (RS)',
                'Honda SENSING 360 (RS)',
                'Head-Up Display (RS)',
                '9-inch Touchscreen dengan Smartphone Connection',
                'Wireless Charger',
                'Digital Meter Cluster',
                'EV Drive Mode (RS)',
                'Panoramic Sunroof',
                'Power Tailgate dengan Hands-free Access'
            ]
        }
    },
    description: 'All New CR-V adalah SUV premium terbaru yang menghadirkan desain elegant, teknologi canggih, dan performa tangguh. Tersedia dalam pilihan mesin 1.5L Turbo dan 2.0L RS e:HEV hybrid, CR-V menawarkan pengalaman berkendara yang luxurious, aman, dan efisien dengan fitur Honda SENSING terbaru dan interior yang spacious untuk 7 penumpang.',
    shortDescription: 'SUV premium dengan pilihan 1.5L Turbo dan RS e:HEV hybrid, dilengkapi Honda SENSING 360 dan interior 7-seater luxurious.',
    tags: [
        'SUV',
        'Premium',
        '7-Seater',
        'Hybrid',
        'Turbo',
        'RS Model',
        'Honda SENSING',
        'Luxury'
    ],
    isFeatured: true,
    isNew: true,
    views: 945,
    relatedCars: [
        'hrv-2024',
        'accord-2024'
    ],
    createdAt: '2024-04-01',
    updatedAt: '2024-04-01'
};
}),
"[project]/data/cars/wrv.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "wrv",
    ()=>wrv
]);
const wrv = {
    id: 'wrv-2024',
    slug: 'all-new-wr-v',
    name: 'All New WR-V',
    model: 'WR-V',
    category: 'SUV',
    priceRange: 'Rp 292 - 344,3 Juta',
    startingPrice: 292000000,
    typeCount: 6,
    videoUrl: 'https://youtu.be/2c21TZpic30?si=6RUqePBbA12OLRkG',
    images: {
        main: '/images/cars/all-new-wr-v/main.jpg'
    },
    variants: [
        {
            id: 'wrv-e-mt',
            type: 'ALL NEW WR-V E MT',
            price: 292000000,
            priceFormatted: 'Rp 292.000.000',
            features: [
                'LED Headlights',
                '7-inch Touchscreen Audio',
                'Keyless Entry',
                '4 SRS Airbags',
                'Rear Camera',
                'Power Steering',
                'AC Manual',
                'Fabric Seats',
                '16-inch Steel Wheels',
                'ABS dengan EBD',
                'Power Window Depan',
                'Central Door Lock'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'wrv-e-cvt',
            type: 'ALL NEW WR-V E CVT',
            price: 302000000,
            priceFormatted: 'Rp 302.000.000',
            features: [
                'LED Headlights',
                '7-inch Touchscreen Audio',
                'Keyless Entry',
                '4 SRS Airbags',
                'Rear Camera',
                'Transmisi CVT',
                'ECON Mode',
                'Power Steering',
                'AC Manual',
                'Fabric Seats',
                '16-inch Steel Wheels',
                'ABS dengan EBD',
                'Power Window Depan',
                'Central Door Lock'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'wrv-rs',
            type: 'ALL NEW WR-V RS',
            price: 321700000,
            priceFormatted: 'Rp 321.700.000',
            features: [
                'RS Body Kit',
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                '7-inch Touchscreen Audio dengan Smartphone Connection',
                '4 SRS Airbags',
                'Rear Camera',
                'Push Start Button',
                'Paddle Shift',
                'Multi-Info Display',
                'RS Seat Fabric',
                'Auto AC',
                'Power Window Depan & Belakang',
                'Rear Parking Sensor',
                'Steering Wheel dengan Audio Control'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'wrv-rs-tt',
            type: 'ALL NEW WR-V RS TWO TONE',
            price: 324200000,
            priceFormatted: 'Rp 324.200.000',
            features: [
                'RS Body Kit',
                'Two-Tone Color',
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                '7-inch Touchscreen Audio dengan Smartphone Connection',
                '4 SRS Airbags',
                'Rear Camera',
                'Push Start Button',
                'Paddle Shift',
                'Multi-Info Display',
                'RS Seat Fabric',
                'Auto AC',
                'Power Window Depan & Belakang',
                'Rear Parking Sensor',
                'Steering Wheel dengan Audio Control',
                'Black Roof'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'wrv-rs-hs',
            type: 'ALL NEW WR-V RS with Honda SENSING',
            price: 341800000,
            priceFormatted: 'Rp 341.800.000',
            features: [
                'RS Body Kit',
                'Honda SENSING',
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                '7-inch Touchscreen Audio dengan Smartphone Connection',
                '4 SRS Airbags',
                'Rear Camera',
                'Push Start Button',
                'Paddle Shift',
                'Multi-Info Display',
                'RS Seat Fabric',
                'Auto AC',
                'Power Window Depan & Belakang',
                'Rear Parking Sensor',
                'Steering Wheel dengan Audio Control',
                'LaneWatch Camera',
                'Auto High Beam'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'wrv-rs-hs-tt',
            type: 'ALL NEW WR-V RS with Honda SENSING TWO TONE',
            price: 344300000,
            priceFormatted: 'Rp 344.300.000',
            features: [
                'RS Body Kit',
                'Honda SENSING',
                'Two-Tone Color',
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                '7-inch Touchscreen Audio dengan Smartphone Connection',
                '4 SRS Airbags',
                'Rear Camera',
                'Push Start Button',
                'Paddle Shift',
                'Multi-Info Display',
                'RS Seat Fabric',
                'Auto AC',
                'Power Window Depan & Belakang',
                'Rear Parking Sensor',
                'Steering Wheel dengan Audio Control',
                'LaneWatch Camera',
                'Auto High Beam',
                'Black Roof'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4060 mm',
            width: '1780 mm',
            height: '1608 mm',
            wheelbase: '2485 mm',
            weight: '1180 - 1250 kg'
        },
        performance: {
            engine: '1.5L DOHC i-VTEC',
            displacement: '1498 cc',
            maxPower: '121 PS / 6600 rpm',
            maxTorque: '145 Nm / 4300 rpm',
            transmission: '6-speed Manual / CVT',
            fuelConsumption: '16,5 km/L (MT) / 15,8 km/L (CVT)',
            acceleration: '0-100 km/h dalam 11.2 detik',
            topSpeed: '180 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '40 Liter',
            luggage: '380 Liter',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'LED Headlights',
                '17-inch Alloy Wheels (RS)',
                'RS Body Kit',
                'Two-Tone Color'
            ],
            interior: [
                '7-inch Touchscreen Audio',
                'Multi-Info Display',
                'Fabric Seats',
                'RS Seat Fabric',
                'Auto AC'
            ],
            safety: [
                '4 SRS Airbags',
                'ABS dengan EBD',
                'Honda SENSING (RS High)',
                'Rear Camera',
                'Rear Parking Sensor'
            ],
            entertainment: [
                'Smartphone Connection',
                '4 Speakers',
                'Steering Audio Control (RS)'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Adventurous & Modern',
            description: 'WR-V menghadirkan desain SUV compact yang adventurous dengan proporsi yang tegas dan modern. Tampilan yang kokoh dilengkapi dengan fitur LED dan pilihan warna two-tone pada varian RS.',
            features: [
                'Compact SUV Design',
                'RS Body Kit (Varian RS)',
                '17-inch Alloy Wheels (RS)',
                'LED Headlights dengan DRL',
                'Two-Tone Color Options',
                'Chrome Accents',
                'Roof Rails'
            ]
        },
        interior: {
            title: 'Interior Spacious & Nyaman',
            description: 'Kabin yang luas dan nyaman dengan material berkualitas. Dilengkapi dengan berbagai fitur teknologi untuk pengalaman berkendara yang lebih menyenangkan.',
            features: [
                '7-inch Touchscreen Audio System',
                'Multi-Info Display',
                'RS Seat Fabric (Varian RS)',
                'Power Windows',
                'Steering Wheel dengan Audio Control (RS)',
                'Auto AC (RS)',
                'Push Start Button (RS)'
            ]
        },
        safety: {
            title: 'Keselamatan Komprehensif',
            description: 'Dilengkapi dengan fitur keselamatan lengkap termasuk Honda SENSING pada varian tertinggi untuk perlindungan maksimal pengemudi dan penumpang.',
            features: [
                '4 SRS Airbags',
                'Anti-lock Braking System (ABS)',
                'Electronic Brake-force Distribution (EBD)',
                'Honda SENSING (RS High)',
                'Rear Camera',
                'Rear Parking Sensor (RS)',
                'LaneWatch Camera (RS with HS)'
            ]
        },
        technology: {
            title: 'Teknologi Canggih untuk Kenyamanan',
            description: 'Berbagai fitur teknologi modern yang mendukung kenyamanan, keselamatan, dan efisiensi dalam berkendara.',
            features: [
                'Honda SENSING (RS High)',
                'ECON Mode (CVT)',
                'Paddle Shift (RS)',
                'Push Start Button (RS)',
                'Smartphone Connection',
                'Multi-Info Display',
                'Auto AC (RS)'
            ]
        }
    },
    description: 'All New WR-V adalah SUV compact yang menghadirkan desain adventurous dan kapabilitas tangguh untuk petualangan urban. Dilengkapi dengan pilihan varian lengkap mulai dari E hingga RS dengan Honda SENSING, WR-V menawarkan kombinasi sempurna antara gaya, kenyamanan, dan teknologi keselamatan canggih.',
    shortDescription: 'SUV compact dengan desain adventurous untuk petualangan urban, dilengkapi Honda SENSING pada varian tertinggi.',
    tags: [
        'SUV',
        'Adventure',
        'Compact',
        'Urban',
        'RS Model',
        'Two-Tone',
        'Honda SENSING'
    ],
    isFeatured: true,
    isNew: true,
    views: 756,
    relatedCars: [
        'brio-2024',
        'new-hr-v'
    ],
    createdAt: '2024-02-01',
    updatedAt: '2024-02-01'
};
}),
"[project]/data/cars/brv.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "brv",
    ()=>brv
]);
const brv = {
    id: 'brv-2024',
    slug: 'all-new-br-v',
    name: 'All New BR-V',
    model: 'BR-V',
    category: 'MPV',
    priceRange: 'Rp 313,4 - 329 Juta',
    startingPrice: 313400000,
    typeCount: 2,
    videoUrl: 'https://youtu.be/uIovfXg4W-E?si=JY0w1VK_TZBtoFLn',
    images: {
        main: '/images/cars/all-new-br-v/main.jpg'
    },
    variants: [
        {
            id: 'brv-s-mt',
            type: 'ALL NEW BR-V S MT',
            price: 313400000,
            priceFormatted: 'Rp 313.400.000',
            features: [
                'Halogen Headlights',
                '15-inch Steel Wheels',
                '7-inch Touchscreen Display Audio',
                'USB Charging Ports',
                '2 SRS Airbags',
                'Rear Parking Sensor',
                'Manual AC',
                'Fabric Seats',
                'Power Steering',
                'ABS dengan EBD',
                'Power Window Depan',
                'Central Door Lock',
                'Immobilizer System',
                'Rear Defogger',
                'Front Fog Lamps',
                'Roof Rail',
                '60:40 Split Fold 3rd Row Seat',
                '6 Speakers'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'brv-e-mt',
            type: 'ALL NEW BR-V E MT',
            price: 329000000,
            priceFormatted: 'Rp 329.000.000',
            features: [
                'LED Headlights dengan DRL',
                '16-inch Alloy Wheels',
                '7-inch Touchscreen Display Audio dengan Smartphone Connection',
                'Apple CarPlay & Android Auto',
                '4 SRS Airbags',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Auto AC',
                'Rear AC Vents',
                'Fabric Seats',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'ABS dengan EBD',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Front Fog Lamps',
                'Roof Rail',
                'Chrome Door Handle & Side Molding',
                '60:40 Split Fold 3rd Row Seat',
                '6 Speakers'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4490 mm',
            width: '1780 mm',
            height: '1685 mm',
            wheelbase: '2760 mm',
            weight: '1210 - 1250 kg'
        },
        performance: {
            engine: '1.5L DOHC i-VTEC',
            displacement: '1497 cc',
            maxPower: '121 PS / 6600 rpm',
            maxTorque: '145 Nm / 4300 rpm',
            transmission: '6-speed Manual',
            fuelConsumption: '16,4 km/L',
            acceleration: '0-100 km/h dalam 12.5 detik',
            topSpeed: '170 km/jam'
        },
        capacity: {
            seating: '7 Seater',
            fuelTank: '45 Liter',
            luggage: '223 Liter (7-seater) | 691 Liter (5-seater mode)',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'LED Headlights dengan DRL (E)',
                '16-inch Alloy Wheels (E)',
                'Roof Rail',
                'Front Fog Lamps',
                'Chrome Accents'
            ],
            interior: [
                '7-inch Touchscreen Display Audio',
                'Fabric Seats',
                '60:40 Split Fold 3rd Row',
                'Auto AC (E)',
                'Rear AC Vents (E)'
            ],
            safety: [
                '4 SRS Airbags (E)',
                'ABS dengan EBD',
                'Vehicle Stability Assist (E)',
                'Rear View Camera (E)',
                'Rear Parking Sensor'
            ],
            entertainment: [
                'Apple CarPlay & Android Auto (E)',
                '6 Speakers',
                'USB Charging Ports'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Sporty & Tangguh',
            description: 'BR-V menghadirkan desain MPV yang sporty dan tangguh dengan ground clearance yang tinggi untuk berbagai medan. Tampilan yang gagah dilengkapi dengan fitur LED pada varian E dan roof rail yang functional.',
            features: [
                'Sporty MPV Design',
                'LED Headlights dengan DRL (Varian E)',
                '16-inch Alloy Wheels (E) / 15-inch Steel Wheels (S)',
                'Roof Rail',
                'Front Fog Lamps',
                'Chrome Door Handle & Side Molding (E)',
                'High Ground Clearance'
            ]
        },
        interior: {
            title: 'Interior Spacious & Praktis 7-Seater',
            description: 'Kabin yang luas dan praktis dengan konfigurasi 7-seater yang flexible. Dilengkapi dengan fitur kenyamanan dan entertainment untuk perjalanan keluarga yang menyenangkan.',
            features: [
                '7-inch Touchscreen Display Audio',
                '7-Seater Configuration',
                '60:40 Split Fold 3rd Row Seat',
                'Auto AC dengan Rear Vents (E)',
                'Fabric Seats',
                'Power Windows',
                'Multiple Storage Compartments',
                'Steering Wheel dengan Audio Control (E)'
            ]
        },
        safety: {
            title: 'Keselamatan untuk Keluarga',
            description: 'Dilengkapi dengan fitur keselamatan essensial untuk melindungi seluruh penumpang dalam perjalanan keluarga, dengan tambahan fitur canggih pada varian E.',
            features: [
                '4 SRS Airbags (E) / 2 SRS Airbags (S)',
                'Anti-Lock Braking System (ABS)',
                'Electronic Brake-force Distribution (EBD)',
                'Vehicle Stability Assist (VSA) (E)',
                'Hill Start Assist (E)',
                'Rear View Camera (E)',
                'Rear Parking Sensor',
                'Immobilizer System'
            ]
        },
        technology: {
            title: 'Teknologi untuk Kenyamanan Berkendara',
            description: 'Berbagai fitur teknologi yang mendukung kenyamanan dan konektivitas dalam berkendara sehari-hari, khususnya untuk kebutuhan keluarga.',
            features: [
                'Smartphone Connection dengan Apple CarPlay & Android Auto (E)',
                'Push Start Button (E)',
                'Keyless Entry System (E)',
                'Electric Parking Brake dengan Auto Brake Hold (E)',
                'Steering Wheel Audio Control (E)',
                'Rear AC Vents (E)',
                'Multiple USB Charging Ports'
            ]
        }
    },
    description: 'All New BR-V adalah MPV 7-seater yang menghadirkan desain sporty, interior yang spacious, dan kapabilitas tangguh untuk keluarga modern. Dengan pilihan varian S dan E yang dilengkapi fitur keselamatan dan kenyamanan essensial, BR-V menjadi pilihan tepat untuk perjalanan keluarga yang aman dan nyaman.',
    shortDescription: 'MPV 7-seater sporty dengan interior spacious, cocok untuk perjalanan keluarga dengan fitur keselamatan essensial.',
    tags: [
        'MPV',
        '7-Seater',
        'Family Car',
        'Sporty',
        'Practical',
        'Fuel Efficient',
        'Urban'
    ],
    isFeatured: true,
    isNew: true,
    views: 723,
    relatedCars: [
        'mobilio-2024',
        'hrv-2024'
    ],
    createdAt: '2024-05-01',
    updatedAt: '2024-05-01'
};
}),
"[project]/data/cars/civic.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "civic",
    ()=>civic
]);
const civic = {
    id: 'civic-ehev-2024',
    slug: 'all-new-civic-e-hev-rs',
    name: 'All New Civic e:HEV RS',
    model: 'Civic e:HEV',
    category: 'Sedan',
    priceRange: 'Rp 704,8 Juta',
    startingPrice: 704800000,
    typeCount: 1,
    videoUrl: 'https://youtu.be/VqSQsMOsAdo?si=7s7WcsvM18Be6XM9',
    images: {
        main: '/images/cars/all-new-civic-e-hev-rs/main.jpg'
    },
    variants: [
        {
            id: 'civic-ehev-rs',
            type: 'ALL NEW CIVIC e:HEV RS',
            price: 704800000,
            priceFormatted: 'Rp 704.800.000',
            features: [
                'e:HEV RS Hybrid System',
                'LED Headlights dengan Adaptive Driving Beam',
                '18-inch Alloy Wheels RS Design',
                '9-inch Touchscreen Display Audio',
                '12.3-inch Digital Meter Cluster',
                'Apple CarPlay & Android Auto',
                'Wireless Charger',
                '10.2-inch Head-Up Display',
                '6 SRS Airbags',
                'Honda SENSING 360',
                '360° Camera System',
                'Rear View Camera',
                'Push Start Button',
                'Smart Keyless Entry',
                'Auto AC Dual Zone dengan Ionizer',
                'Rear AC Vents',
                'Leather Seats dengan RS Embroidery',
                'Power Adjustable Driver & Passenger Seats dengan Memory Function',
                'Heated & Ventilated Front Seats',
                'Steering Wheel dengan Paddle Shifters',
                'ABS dengan EBD',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Electric Parking Brake dengan Auto Brake Hold',
                'RS Body Kit',
                'RS Front Grille dengan Red Accent',
                'RS Rear Spoiler',
                'RS Side Skirts',
                'Adaptive Cruise Control dengan Low-Speed Follow',
                'Lane Keeping Assist System',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation System',
                'Auto High Beam',
                'Blind Spot Information',
                'Cross Traffic Monitor',
                'Front & Rear Parking Sensors',
                'Panoramic Sunroof',
                'Ambient Lighting dengan 8 Color Options',
                'Bose Premium Audio System dengan 12 Speakers',
                'Wireless Apple CarPlay & Android Auto',
                'Digital Key dengan Smartphone Integration',
                'Drive Mode Select (Econ, Normal, Sport, Individual)',
                'Regenerative Braking System',
                'EV Drive Mode',
                'Acoustic Front Glass',
                'Auto Dimming Rearview Mirror',
                'Power Rear Sunshade',
                'Hands-free Power Trunk'
            ],
            transmission: 'e-CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L e:HEV',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4675 mm',
            width: '1802 mm',
            height: '1415 mm',
            wheelbase: '2735 mm',
            weight: '1490 kg'
        },
        performance: {
            engine: '2.0L DOHC i-MMD e:HEV',
            displacement: '1993 cc',
            maxPower: '184 PS (Combined) | 141 PS (Engine) | 184 PS (Electric Motor)',
            maxTorque: '315 Nm (Electric Motor)',
            transmission: 'e-CVT',
            fuelConsumption: '26,5 km/L',
            acceleration: '0-100 km/h dalam 7.8 detik',
            topSpeed: '180 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '43 Liter',
            luggage: '408 Liter',
            doors: '4 Pintu'
        },
        features: {
            exterior: [
                'RS Body Kit',
                'LED Adaptive Headlights',
                '18-inch RS Alloy Wheels',
                'Panoramic Sunroof',
                'RS Rear Spoiler',
                'Chrome Accents'
            ],
            interior: [
                '12.3-inch Digital Meter Cluster',
                '9-inch Touchscreen',
                'Leather RS Seats',
                'Bose Premium Audio',
                'Head-Up Display',
                'Ambient Lighting'
            ],
            safety: [
                'Honda SENSING 360',
                '6 SRS Airbags',
                '360° Camera System',
                'Blind Spot Information',
                'Cross Traffic Monitor'
            ],
            entertainment: [
                'Bose 12-Speaker System',
                'Wireless Apple CarPlay & Android Auto',
                'Wireless Charger',
                'Digital Key'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Sporty & Elegant dengan Sentuhan RS',
            description: 'Civic e:HEV RS menghadirkan desain sedan sporty yang elegant dengan body kit RS eksklusif dan teknologi hybrid terdepan. Garis bodi yang tajam dan proporsi yang low-slung menciptakan kesan premium dan dynamic.',
            features: [
                'RS Body Kit Eksklusif',
                'LED Headlights dengan Adaptive Driving Beam',
                '18-inch Alloy Wheels RS Design',
                'RS Front Grille dengan Red Accent',
                'RS Rear Spoiler',
                'Panoramic Sunroof',
                'Chrome Window Surround',
                'Dual Exhaust Tip',
                'RS Badging'
            ]
        },
        interior: {
            title: 'Interior Premium dengan Teknologi Terdepan',
            description: 'Kabin yang luxurious dan sophisticated dengan material premium dan teknologi paling mutakhir. Setiap detail didesain untuk memberikan pengalaman berkendara yang exceptional dan comfortable.',
            features: [
                '12.3-inch Digital Meter Cluster',
                '9-inch Touchscreen Display Audio',
                '10.2-inch Head-Up Display',
                'Leather Seats dengan RS Embroidery',
                'Bose Premium Audio System 12 Speakers',
                'Heated & Ventilated Front Seats',
                'Power Adjustable Seats dengan Memory Function',
                'Ambient Lighting 8 Color',
                'Panoramic Sunroof'
            ]
        },
        safety: {
            title: 'Keselamatan Terdepan dengan Honda SENSING 360',
            description: 'Dilengkapi dengan Honda SENSING 360 yang memberikan perlindungan menyeluruh 360 derajat, kombinasi kamera dan radar untuk deteksi yang lebih akurat dalam berbagai kondisi berkendara.',
            features: [
                'Honda SENSING 360',
                '6 SRS Airbags',
                '360° Camera System',
                'Blind Spot Information',
                'Cross Traffic Monitor',
                'Adaptive Cruise Control dengan Low-Speed Follow',
                'Lane Keeping Assist System',
                'Collision Mitigation Braking System',
                'Front & Rear Parking Sensors'
            ]
        },
        technology: {
            title: 'Teknologi Hybrid e:HEV & Fitur Digital Canggih',
            description: 'Menghadirkan teknologi e:HEV hybrid generasi terbaru dengan sistem i-MMD yang lebih efisien, dilengkapi berbagai fitur digital dan konektivitas terkini untuk pengalaman berkendara yang smart dan connected.',
            features: [
                '2.0L e:HEV i-MMD Hybrid System',
                'Honda SENSING 360',
                '12.3-inch Digital Meter Cluster',
                '10.2-inch Head-Up Display',
                'Wireless Apple CarPlay & Android Auto',
                'Digital Key dengan Smartphone Integration',
                'Bose Premium Audio System',
                'Wireless Charger',
                '4 Drive Mode Selection'
            ]
        }
    },
    description: 'All New Civic e:HEV RS adalah sedan premium dengan teknologi hybrid terdepan yang menghadirkan kombinasi sempurna antara performa sporty, efisiensi bahan bakar exceptional, dan kemewahan. Dengan mesin 2.0L e:HEV yang bertenaga, body kit RS eksklusif, serta fitur teknologi dan keselamatan paling mutakhir termasuk Honda SENSING 360, Civic e:HEV RS menetapkan standar baru untuk sedan hybrid premium di Indonesia.',
    shortDescription: 'Sedan hybrid premium dengan teknologi 2.0L e:HEV, body kit RS eksklusif, Honda SENSING 360, dan interior luxurious.',
    tags: [
        'Sedan',
        'Hybrid',
        'e:HEV',
        'RS Model',
        'Premium',
        'Honda SENSING 360',
        'Sporty',
        'Luxury',
        'Bose Audio'
    ],
    isFeatured: true,
    isNew: true,
    views: 1567,
    relatedCars: [
        'civic-turbo-2024',
        'accord-ehev',
        'crv-2024'
    ],
    createdAt: '2024-09-01',
    updatedAt: '2024-09-01'
};
}),
"[project]/data/cars/accord.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "accord",
    ()=>accord
]);
const accord = {
    id: 'accord-ehev-2024',
    slug: 'all-new-accord-e-hev',
    name: 'All New Accord e:HEV',
    model: 'Accord e:HEV',
    category: 'Sedan',
    priceRange: 'Rp 815,9 Juta',
    startingPrice: 815900000,
    typeCount: 1,
    videoUrl: 'https://youtu.be/0F5qChzjxGU?si=PNdVnIt6nKDmesfd',
    images: {
        main: '/images/cars/all-new-accord-e-hev/main.jpg'
    },
    variants: [
        {
            id: 'accord-ehev',
            type: 'ALL NEW ACCORD e:HEV',
            price: 815900000,
            priceFormatted: 'Rp 815.900.000',
            features: [
                'e:HEV Hybrid System 2.0L',
                'LED Headlights dengan Adaptive Driving Beam',
                '19-inch Alloy Wheels',
                '12.3-inch Touchscreen Display Audio',
                '12.3-inch Digital Meter Cluster',
                '11.5-inch Head-Up Display',
                'Apple CarPlay & Android Auto',
                'Wireless Charger',
                '10 SRS Airbags',
                'Honda SENSING 360',
                '360° Camera System',
                'Rear View Camera',
                'Push Start Button',
                'Smart Keyless Entry',
                'Auto AC 4-Zone',
                'Rear AC Vents dengan Control Panel',
                'Leather Seats dengan Ventilasi & Pemanas',
                'Power Adjustable Driver & Passenger Seats dengan Memory Function',
                'Power Rear Sunshade',
                'Panoramic Sunroof',
                'Steering Wheel dengan Paddle Shifters',
                'ABS dengan EBD',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Adaptive Cruise Control dengan Low-Speed Follow',
                'Lane Keeping Assist System',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation System',
                'Auto High Beam',
                'Blind Spot Information',
                'Cross Traffic Monitor',
                'Front & Rear Parking Sensors',
                'Ambient Lighting dengan 12 Color Options',
                'Bose Premium Audio System dengan 12 Speakers',
                'Wireless Apple CarPlay & Android Auto',
                'Digital Key dengan Smartphone Integration',
                'Drive Mode Select (Econ, Normal, Sport, Individual)',
                'Regenerative Braking System',
                'EV Drive Mode',
                'Acoustic Front & Side Glass',
                'Auto Dimming Rearview Mirror',
                'Hands-free Power Trunk',
                'Remote Engine Start',
                'Traffic Jam Assist',
                'Parking Assist System'
            ],
            transmission: 'e-CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L e:HEV',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4970 mm',
            width: '1862 mm',
            height: '1450 mm',
            wheelbase: '2830 mm',
            weight: '1650 kg'
        },
        performance: {
            engine: '2.0L DOHC i-MMD e:HEV',
            displacement: '1993 cc',
            maxPower: '204 PS (Combined) | 148 PS (Engine) | 184 PS (Electric Motor)',
            maxTorque: '335 Nm (Electric Motor)',
            transmission: 'e-CVT',
            fuelConsumption: '25,8 km/L',
            acceleration: '0-100 km/h dalam 7.6 detik',
            topSpeed: '180 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '48 Liter',
            luggage: '430 Liter',
            doors: '4 Pintu'
        },
        features: {
            exterior: [
                'LED Adaptive Headlights',
                '19-inch Alloy Wheels',
                'Panoramic Sunroof',
                'Chrome Accents',
                'Dual Exhaust Tip'
            ],
            interior: [
                '12.3-inch Digital Meter Cluster',
                '12.3-inch Touchscreen',
                'Leather Seats',
                'Bose Premium Audio',
                'Head-Up Display',
                '4-Zone AC'
            ],
            safety: [
                'Honda SENSING 360',
                '10 SRS Airbags',
                '360° Camera System',
                'Blind Spot Information',
                'Parking Assist'
            ],
            entertainment: [
                'Bose 12-Speaker System',
                'Wireless Apple CarPlay & Android Auto',
                'Wireless Charger',
                'Digital Key'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Elegant & Premium',
            description: 'Accord e:HEV menghadirkan desain sedan executive yang elegant dan sophisticated dengan proporsi yang memukau. Garis bodi yang clean dan modern menciptakan kesan premium yang kuat.',
            features: [
                'LED Headlights dengan Adaptive Driving Beam',
                '19-inch Alloy Wheels Design',
                'Panoramic Sunroof',
                'Chrome Window Surround',
                'Dual Exhaust Tip',
                'Power Folding Side Mirrors',
                'Body Color Door Handles dengan Illumination'
            ]
        },
        interior: {
            title: 'Interior Executive dengan Teknologi Terdepan',
            description: 'Kabin yang luxurious dan spacious dengan material premium terbaik dan teknologi paling mutakhir. Setiap detail dirancang untuk kenyamanan executive class.',
            features: [
                '12.3-inch Digital Meter Cluster',
                '12.3-inch Touchscreen Display Audio',
                '11.5-inch Head-Up Display',
                'Leather Seats dengan Ventilasi & Pemanas',
                'Bose Premium Audio System 12 Speakers',
                '4-Zone Auto Climate Control',
                'Power Adjustable Seats dengan Memory Function',
                'Ambient Lighting 12 Color',
                'Panoramic Sunroof'
            ]
        },
        safety: {
            title: 'Keselamatan Terlengkap dengan Honda SENSING 360',
            description: 'Dilengkapi dengan Honda SENSING 360 yang paling lengkap dan 10 SRS Airbags untuk perlindungan maksimal dalam setiap kondisi berkendara.',
            features: [
                'Honda SENSING 360',
                '10 SRS Airbags',
                '360° Camera System',
                'Blind Spot Information',
                'Cross Traffic Monitor',
                'Parking Assist System',
                'Traffic Jam Assist',
                'Collision Mitigation Braking System',
                'Front & Rear Parking Sensors'
            ]
        },
        technology: {
            title: 'Teknologi Hybrid e:HEV & Fitur Digital Executive',
            description: 'Menghadirkan teknologi e:HEV hybrid generasi terbaru dengan performa tinggi, dilengkapi berbagai fitur digital dan konektivitas executive class.',
            features: [
                '2.0L e:HEV i-MMD Hybrid System',
                'Honda SENSING 360',
                '12.3-inch Digital Meter Cluster',
                '11.5-inch Head-Up Display',
                'Wireless Apple CarPlay & Android Auto',
                'Digital Key dengan Smartphone Integration',
                'Bose Premium Audio System',
                '4-Zone Auto Climate Control',
                'Parking Assist System'
            ]
        }
    },
    description: 'All New Accord e:HEV adalah sedan executive premium dengan teknologi hybrid terdepan yang menghadirkan kombinasi sempurna antara performa responsive, efisiensi bahan bakar exceptional, dan kemewahan executive class. Dengan mesin 2.0L e:HEV yang bertenaga 204 PS, interior yang luxurious dengan teknologi terkini, serta fitur keselamatan paling lengkap termasuk Honda SENSING 360 dan 10 SRS Airbags, Accord e:HEV menetapkan standar baru untuk sedan executive hybrid di Indonesia.',
    shortDescription: 'Sedan executive hybrid premium dengan teknologi 2.0L e:HEV 204 PS, Honda SENSING 360, dan interior luxurious dengan fitur executive class.',
    tags: [
        'Sedan',
        'Executive',
        'Hybrid',
        'e:HEV',
        'Premium',
        'Honda SENSING 360',
        'Luxury',
        'Bose Audio',
        'Panoramic Sunroof'
    ],
    isFeatured: true,
    isNew: true,
    views: 1342,
    relatedCars: [
        'civic-ehev-2024',
        'crv-2024',
        'crv-ehev-2024'
    ],
    createdAt: '2024-10-01',
    updatedAt: '2024-10-01'
};
}),
"[project]/data/cars/stepwgn.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stepwgn",
    ()=>stepwgn
]);
const stepwgn = {
    id: 'stepwgn-e-hev-2024',
    slug: 'stepwgn-e-hev',
    name: 'Stepwgn e:HEV',
    model: 'Stepwgn',
    category: 'MPV',
    priceRange: 'Rp 650 - 750 Juta',
    startingPrice: 650000000,
    typeCount: 3,
    videoUrl: 'https://youtu.be/lk3qq1VDRms?si=akzFR2ZBm5F6Jr0I',
    images: {
        main: '/images/cars/stepwgn-e-hev/main.jpg'
    },
    variants: [
        {
            id: 'stepwgn-e-hev-premium',
            type: 'STEPWGN e:HEV PREMIUM',
            price: 750000000,
            priceFormatted: 'Rp 750.000.000',
            features: [
                '8-Seater Hybrid',
                'Magic Seats',
                'Dual Power Sliding Doors',
                'Panoramic Roof',
                'Honda SENSING 360',
                '11.4-inch Touchscreen'
            ],
            transmission: 'CVT',
            fuelType: 'Hybrid',
            engineCapacity: '2.0L',
            available: true
        }
    ],
    description: 'Stepwgn e:HEV adalah MPV keluarga premium dengan teknologi hybrid dan konfigurasi kursi Magic Seats yang fleksibel.',
    shortDescription: 'MPV keluarga premium hybrid dengan Magic Seats yang fleksibel.',
    tags: [
        'MPV',
        'Hybrid',
        '8-Seater',
        'Premium',
        'Family'
    ],
    isFeatured: true,
    isNew: true,
    views: 834,
    relatedCars: [
        'all-new-br-v',
        'all-new-cr-v'
    ],
    createdAt: '2024-02-20',
    updatedAt: '2024-02-20'
};
}),
"[project]/data/cars/cityhatchback.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cityhatchback",
    ()=>cityhatchback
]);
const cityhatchback = {
    id: 'city-hatchback-2024',
    slug: 'city-hatchback-rs',
    name: 'City Hatchback RS',
    model: 'City Hatchback',
    category: 'Hatchback',
    priceRange: 'Rp 388,2 - 390,7 Juta',
    startingPrice: 388200000,
    typeCount: 2,
    videoUrl: 'https://www.youtube.com/watch?v=ZER-nEN3mno',
    images: {
        main: '/images/cars/city-hatchback-rs/main.jpg'
    },
    variants: [
        {
            id: 'city-hatchback-rs-hs',
            type: 'CITY HATCHBACK RS with Honda SENSING',
            price: 388200000,
            priceFormatted: 'Rp 388.200.000',
            features: [
                'RS Body Kit & Grille',
                'LED Headlights dengan DRL',
                '16-inch Alloy Wheels RS Design',
                '8-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING',
                'LaneWatch Camera',
                'Rear View Camera',
                'Push Start Button',
                'Smart Keyless Entry',
                'Auto AC Dual Zone',
                'Rear AC Vents',
                'Leather Seats dengan RS Embroidery',
                'Power Adjustable Driver Seat',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio & Phone Control',
                'Paddle Shifters',
                'ABS dengan EBD',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Front Fog Lamps',
                'Rear Spoiler',
                'Chrome Exhaust Finisher',
                'RS Front & Rear Bumper',
                'RS Side Skirts',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation',
                'Auto High Beam',
                'Lead Car Departure Notification',
                '8 Speakers',
                'Digital Meter Cluster',
                'ECON Mode',
                'Sport Mode'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'city-hatchback-rs-hs-tt',
            type: 'CITY HATCHBACK RS with Honda SENSING TWO TONE',
            price: 390700000,
            priceFormatted: 'Rp 390.700.000',
            features: [
                'RS Body Kit & Grille',
                'Two-Tone Color',
                'LED Headlights dengan DRL',
                '16-inch Alloy Wheels RS Design',
                '8-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING',
                'LaneWatch Camera',
                'Rear View Camera',
                'Push Start Button',
                'Smart Keyless Entry',
                'Auto AC Dual Zone',
                'Rear AC Vents',
                'Leather Seats dengan RS Embroidery',
                'Power Adjustable Driver Seat',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio & Phone Control',
                'Paddle Shifters',
                'ABS dengan EBD',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Front Fog Lamps',
                'Rear Spoiler',
                'Chrome Exhaust Finisher',
                'RS Front & Rear Bumper',
                'RS Side Skirts',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation',
                'Auto High Beam',
                'Lead Car Departure Notification',
                '8 Speakers',
                'Digital Meter Cluster',
                'ECON Mode',
                'Sport Mode',
                'Black Roof',
                'Two-Tone Exterior Mirrors'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4345 mm',
            width: '1748 mm',
            height: '1488 mm',
            wheelbase: '2589 mm',
            weight: '1180 - 1200 kg'
        },
        performance: {
            engine: '1.5L DOHC i-VTEC',
            displacement: '1498 cc',
            maxPower: '121 PS / 6600 rpm',
            maxTorque: '145 Nm / 4300 rpm',
            transmission: 'CVT dengan Paddle Shift',
            fuelConsumption: '18,4 km/L',
            acceleration: '0-100 km/h dalam 10.5 detik',
            topSpeed: '190 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '40 Liter',
            luggage: '289 Liter',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'RS Body Kit',
                'LED Headlights dengan DRL',
                '16-inch RS Alloy Wheels',
                'Rear Spoiler',
                'Two-Tone Color',
                'Chrome Exhaust Finisher'
            ],
            interior: [
                '8-inch Touchscreen Display Audio',
                'Leather Seats dengan RS Embroidery',
                'Digital Meter Cluster',
                'Auto AC Dual Zone',
                'Paddle Shifters'
            ],
            safety: [
                '6 SRS Airbags',
                'Honda SENSING',
                'LaneWatch Camera',
                'Rear View Camera',
                'Vehicle Stability Assist'
            ],
            entertainment: [
                'Apple CarPlay & Android Auto',
                '8 Speakers',
                'Steering Wheel Audio Control'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Sporty RS dengan Sentuhan Premium',
            description: 'City Hatchback RS menghadirkan desain hatchback yang sporty dan dynamic dengan body kit RS eksklusif. Tampilan yang aggressive dilengkapi dengan fitur LED lengkap dan pilihan two-tone yang stylish.',
            features: [
                'RS Body Kit Eksklusif',
                'LED Headlights dengan Daytime Running Lights',
                '16-inch Alloy Wheels RS Design',
                'RS Front Grille dengan Red Accent',
                'RS Rear Spoiler',
                'Two-Tone Color Options',
                'Chrome Exhaust Finisher',
                'RS Side Skirts',
                'Front Fog Lamps'
            ]
        },
        interior: {
            title: 'Interior Sporty dengan Teknologi Terkini',
            description: 'Kabin yang sporty dan modern dengan material premium dan embel-embel RS. Dilengkapi dengan teknologi terkini dan fitur kenyamanan untuk pengalaman berkendara yang menyenangkan.',
            features: [
                'Leather Seats dengan RS Embroidery',
                '8-inch Touchscreen Display Audio',
                'Digital Meter Cluster',
                'Paddle Shifters',
                'Auto AC Dual Zone',
                'Steering Wheel dengan Audio & Phone Control',
                'Power Adjustable Driver Seat',
                'Rear AC Vents',
                'Sport Mode Selection'
            ]
        },
        safety: {
            title: 'Keselamatan Lengkap dengan Honda SENSING',
            description: 'Dilengkapi dengan fitur keselamatan paling lengkap termasuk Honda SENSING untuk perlindungan maksimal dalam berbagai kondisi berkendara.',
            features: [
                'Honda SENSING',
                '6 SRS Airbags',
                'LaneWatch Camera',
                'Rear View Camera',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Electric Parking Brake dengan Auto Brake Hold'
            ]
        },
        technology: {
            title: 'Teknologi Canggih & Fitur Sporty',
            description: 'Berbagai fitur teknologi modern dan sporty yang mendukung performa, kenyamanan, dan konektivitas dalam berkendara sehari-hari.',
            features: [
                'Honda SENSING',
                '8-inch Touchscreen dengan Apple CarPlay & Android Auto',
                'Paddle Shifters',
                'Digital Meter Cluster',
                'Push Start Button',
                'Smart Keyless Entry',
                'ECON & Sport Mode',
                'LaneWatch Camera',
                '8 Speakers Premium Audio'
            ]
        }
    },
    description: 'City Hatchback RS adalah varian sporty teratas dari City Hatchback yang menghadirkan desain dynamic dengan body kit RS eksklusif, interior premium, dan teknologi keselamatan lengkap dengan Honda SENSING. Dengan performa responsive dan handling yang agile, City Hatchback RS menjadi pilihan tepat untuk pengendara yang menginginkan hatchback sporty dengan fitur lengkap dan teknologi canggih.',
    shortDescription: 'Hatchback sporty dengan body kit RS, Honda SENSING, dan interior premium untuk pengalaman berkendara yang dynamic.',
    tags: [
        'Hatchback',
        'RS Model',
        'Sporty',
        'Honda SENSING',
        'Two-Tone',
        'Premium',
        'City Car'
    ],
    isFeatured: true,
    isNew: true,
    views: 876,
    relatedCars: [
        'brio-2024',
        'city-sedan-2024',
        'civic-2024'
    ],
    createdAt: '2024-08-01',
    updatedAt: '2024-08-01'
};
}),
"[project]/data/cars/civictyper.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "civicTypeR",
    ()=>civicTypeR
]);
const civicTypeR = {
    id: 'civic-type-r-2024',
    slug: 'all-new-civic-type-r',
    name: 'All New Civic Type R',
    model: 'Civic Type R',
    category: 'Hot Hatch',
    priceRange: 'Rp 1.448,8 Juta',
    startingPrice: 1448800000,
    typeCount: 1,
    videoUrl: 'https://youtu.be/rRHmB_Ed2JQ?si=rS9gwPPWyK_ZaJdA',
    images: {
        main: '/images/cars/all-new-civic-type-r/main.jpg'
    },
    variants: [
        {
            id: 'civic-type-r',
            type: 'ALL NEW CIVIC TYPE R',
            price: 1448800000,
            priceFormatted: 'Rp 1.448.800.000',
            features: [
                '2.0L VTEC Turbo Engine',
                '6-speed Manual Transmission',
                'Type R Exclusive Body Kit',
                '20-inch Forged Aluminum Wheels',
                'Michelin Pilot Sport 4S Tires',
                'Brembo Brake System (Front 4-piston)',
                'Adaptive Damper System',
                'Limited Slip Differential (LSD)',
                'Triple Exhaust Tips',
                'Carbon Fiber Rear Spoiler',
                'LED Headlights dengan DRL',
                '12.3-inch Digital Meter Cluster dengan Type R Interface',
                '9-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                'Wireless Charger',
                '6 SRS Airbags',
                'Honda SENSING',
                'Rear View Camera',
                'Push Start Button dengan Red Illumination',
                'Smart Keyless Entry',
                'Dual Zone Auto AC',
                'Alcantara & Leather Sport Seats dengan Red Accent',
                'Custom Drive Mode System (Comfort, Sport, +R)',
                'Rev Matching System',
                'Steering Wheel dengan Alcantara & Red Stitching',
                'Metal Pedals & Foot Rest',
                'Type R Logos & Badging',
                'Red Interior Accent Lighting',
                'ABS dengan EBD',
                'Vehicle Stability Assist (VSA) dengan Sport Mode',
                'Hill Start Assist',
                'Adaptive Cruise Control',
                'Lane Keeping Assist System',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation System',
                'Auto High Beam',
                'Front & Rear Parking Sensors',
                '12 Speakers Premium Audio System',
                'Wireless Apple CarPlay & Android Auto',
                'Drive Mode Select (Comfort, Sport, +R, Individual)',
                'Launch Control System',
                'Performance Data Logger',
                'G-Meter Display',
                'Lap Timer',
                'Boost Gauge',
                'Oil Temperature Gauge',
                'Water Temperature Gauge',
                'Aluminum Sport Suspension',
                'Rigid Front Subframe',
                'Enhanced Body Rigidity',
                'Aero Underbody Covers',
                'Aggressive Front Bumper dengan Large Air Intakes',
                'Wide Fender Flares',
                'Red Brake Calipers',
                'Lightweight Hood'
            ],
            transmission: 'Manual',
            fuelType: 'Bensin',
            engineCapacity: '2.0L Turbo',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4595 mm',
            width: '1890 mm',
            height: '1405 mm',
            wheelbase: '2735 mm',
            weight: '1425 kg'
        },
        performance: {
            engine: '2.0L DOHC VTEC Turbo',
            displacement: '1996 cc',
            maxPower: '330 PS / 6500 rpm',
            maxTorque: '420 Nm / 2600-4000 rpm',
            transmission: '6-speed Manual',
            fuelConsumption: '11,4 km/L',
            acceleration: '0-100 km/h dalam 5.4 detik',
            topSpeed: '272 km/jam'
        },
        capacity: {
            seating: '4 Seater',
            fuelTank: '47 Liter',
            luggage: '410 Liter',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'Type R Body Kit',
                'Carbon Fiber Spoiler',
                '20-inch Forged Wheels',
                'Brembo Brakes',
                'Triple Exhaust',
                'Wide Fenders'
            ],
            interior: [
                'Alcantara Sport Seats',
                '12.3-inch Digital Cluster',
                '9-inch Touchscreen',
                'Red Accent Interior',
                'Metal Pedals'
            ],
            safety: [
                'Honda SENSING',
                '6 SRS Airbags',
                'Brembo Brake System',
                'Adaptive Damper',
                'Limited Slip Differential'
            ],
            entertainment: [
                'Premium Audio System',
                'Wireless Apple CarPlay & Android Auto',
                'Performance Data Logger'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Aggressive & Aerodynamic',
            description: 'Civic Type R menghadirkan desain hot hatch yang extreme dan functional dengan aerodynamics yang dioptimalkan untuk performa track. Setiap elemen didesain untuk menghasilkan downforce dan cooling yang optimal.',
            features: [
                'Type R Exclusive Aggressive Body Kit',
                'Carbon Fiber Rear Spoiler dengan Adjustable Gurney Flap',
                '20-inch Forged Aluminum Wheels',
                'Brembo 4-piston Brake Calipers (Front)',
                'Triple Center Exhaust System',
                'Wide Fender Flares',
                'Large Front Air Intakes',
                'Aero Underbody Covers',
                'Red Accent Badging'
            ]
        },
        interior: {
            title: 'Interior Sporty dengan Fokus Pengemudi',
            description: 'Kabin yang sepenuhnya berorientasi pada pengemudi dengan material sporty dan teknologi performa. Setiap kontrol dirancang untuk memberikan feedback yang langsung dan presisi.',
            features: [
                'Alcantara & Leather Sport Seats dengan Red Stitching',
                '12.3-inch Digital Meter Cluster dengan Type R Display',
                '9-inch Touchscreen Display Audio',
                'Alcantara Steering Wheel dengan Red Marker',
                'Metal Sport Pedals',
                'Custom Drive Mode System',
                'Rev Matching System',
                'Performance Data Logger',
                'Red Interior Accent Lighting'
            ]
        },
        safety: {
            title: 'Keselamatan dengan Teknologi Performa',
            description: 'Kombinasi sempurna antara teknologi keselamatan modern dan komponen performa racing-grade untuk memberikan kontrol maksimal dalam berbagai kondisi berkendara.',
            features: [
                'Honda SENSING',
                '6 SRS Airbags',
                'Brembo High-performance Brake System',
                'Adaptive Damper System',
                'Limited Slip Differential (LSD)',
                'Vehicle Stability Assist (VSA) dengan Sport Mode',
                'Hill Start Assist',
                'Michelin Pilot Sport 4S Tires',
                'Enhanced Body Rigidity'
            ]
        },
        technology: {
            title: 'Teknologi Performa & Data Racing',
            description: 'Teknologi canggih yang dikhususkan untuk mengoptimalkan performa berkendara, termasuk sistem data logger untuk menganalisis dan meningkatkan kemampuan track driving.',
            features: [
                'Custom Drive Mode System (Comfort, Sport, +R)',
                'Rev Matching System',
                'Performance Data Logger',
                'G-Meter & Lap Timer',
                'Launch Control System',
                'Boost & Temperature Gauges',
                '12.3-inch Digital Meter Cluster',
                '+R Mode untuk Performa Maksimal',
                'Individual Mode Customization'
            ]
        }
    },
    description: 'All New Civic Type R adalah hot hatch legendaris yang menghadirkan performa extreme dengan mesin 2.0L VTEC Turbo berdaya 330 PS dan torsi 420 Nm. Sebagai icon performa Honda, Civic Type R dilengkapi dengan teknologi racing terdepan termasuk Brembo brake system, adaptive damper, limited slip differential, dan rev matching system. Dengan transmisi manual 6-speed yang presisi dan aerodynamics yang dioptimalkan untuk track, Civic Type R menawarkan pengalaman berkendara pure performance yang tak tertandingi di kelasnya.',
    shortDescription: 'Hot hatch legendaris dengan mesin 2.0L Turbo 330 PS, transmisi manual 6-speed, dan teknologi racing terdepan untuk pengalaman berkendara pure performance.',
    tags: [
        'Hot Hatch',
        'Performance',
        'Type R',
        'Turbo',
        'Manual',
        'Track Car',
        'Brembo',
        'Racing',
        'Limited Edition'
    ],
    isFeatured: true,
    isNew: true,
    views: 2890,
    relatedCars: [
        'civic-ehev-2024',
        'civic-turbo-2024'
    ],
    createdAt: '2024-11-01',
    updatedAt: '2024-11-01'
};
}),
"[project]/data/cars/hrvehev.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hrvehev",
    ()=>hrvehev
]);
const hrvehev = {
    id: 'hrv-ehev-2024',
    slug: 'all-new-hr-v-e-hev',
    name: 'All New HR-V e:HEV',
    model: 'HR-V e:HEV',
    category: 'SUV',
    priceRange: 'Rp 452,9 - 494,5 Juta',
    startingPrice: 452900000,
    typeCount: 6,
    videoUrl: 'https://youtu.be/sGxjNclNXR0?si=3WKQRex-x5wL1C6v',
    images: {
        main: '/images/cars/all-new-hr-v-e-hev/main.jpg'
    },
    variants: [
        {
            id: 'hrv-ehev',
            type: 'ALL NEW HR-V e:HEV',
            price: 452900000,
            priceFormatted: 'Rp 452.900.000',
            features: [
                'e:HEV Hybrid System',
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING',
                'LaneWatch Camera',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Multi-Angle Rearview Camera',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Auto AC Dual Zone',
                'Rear AC Vents',
                'Fabric Seats',
                'Power Adjustable Driver Seat',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation',
                'Auto High Beam',
                'Rain Sensing Wipers',
                'Electrostatic Touch AC Panel',
                'EV Drive Mode',
                'Regenerative Braking',
                '4 Driving Modes (Econ, Normal, Sport, EV)'
            ],
            transmission: 'e-CVT',
            fuelType: 'Hybrid',
            engineCapacity: '1.5L e:HEV',
            available: true
        },
        {
            id: 'hrv-ehev-tt',
            type: 'ALL NEW HR-V e:HEV TWO TONE',
            price: 455400000,
            priceFormatted: 'Rp 455.400.000',
            features: [
                'e:HEV Hybrid System',
                'Two-Tone Color',
                'LED Headlights dengan DRL',
                '17-inch Alloy Wheels',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING',
                'LaneWatch Camera',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Multi-Angle Rearview Camera',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Auto AC Dual Zone',
                'Rear AC Vents',
                'Fabric Seats',
                'Power Adjustable Driver Seat',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation',
                'Auto High Beam',
                'Rain Sensing Wipers',
                'Electrostatic Touch AC Panel',
                'EV Drive Mode',
                'Regenerative Braking',
                '4 Driving Modes (Econ, Normal, Sport, EV)',
                'Black Roof'
            ],
            transmission: 'e-CVT',
            fuelType: 'Hybrid',
            engineCapacity: '1.5L e:HEV',
            available: true
        },
        {
            id: 'hrv-ehev-modulo',
            type: 'ALL NEW HR-V e:HEV Modulo',
            price: 464600000,
            priceFormatted: 'Rp 464.600.000',
            features: [
                'e:HEV Hybrid System',
                'Modulo Aero Kit',
                'LED Headlights dengan DRL',
                '17-inch Modulo Alloy Wheels',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING',
                'LaneWatch Camera',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Multi-Angle Rearview Camera',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Auto AC Dual Zone',
                'Rear AC Vents',
                'Leather Seats',
                'Power Adjustable Driver Seat',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation',
                'Auto High Beam',
                'Rain Sensing Wipers',
                'Electrostatic Touch AC Panel',
                'EV Drive Mode',
                'Regenerative Braking',
                '4 Driving Modes (Econ, Normal, Sport, EV)',
                'Modulo Front Spoiler',
                'Modulo Side Skirts',
                'Modulo Rear Spoiler',
                'Modulo Interior Accents'
            ],
            transmission: 'e-CVT',
            fuelType: 'Hybrid',
            engineCapacity: '1.5L e:HEV',
            available: true
        },
        {
            id: 'hrv-ehev-modulo-tt',
            type: 'ALL NEW HR-V e:HEV Modulo TWO TONE',
            price: 467100000,
            priceFormatted: 'Rp 467.100.000',
            features: [
                'e:HEV Hybrid System',
                'Modulo Aero Kit',
                'Two-Tone Color',
                'LED Headlights dengan DRL',
                '17-inch Modulo Alloy Wheels',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING',
                'LaneWatch Camera',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Multi-Angle Rearview Camera',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Auto AC Dual Zone',
                'Rear AC Vents',
                'Leather Seats',
                'Power Adjustable Driver Seat',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation',
                'Auto High Beam',
                'Rain Sensing Wipers',
                'Electrostatic Touch AC Panel',
                'EV Drive Mode',
                'Regenerative Braking',
                '4 Driving Modes (Econ, Normal, Sport, EV)',
                'Modulo Front Spoiler',
                'Modulo Side Skirts',
                'Modulo Rear Spoiler',
                'Modulo Interior Accents',
                'Black Roof'
            ],
            transmission: 'e-CVT',
            fuelType: 'Hybrid',
            engineCapacity: '1.5L e:HEV',
            available: true
        },
        {
            id: 'hrv-ehev-rs',
            type: 'ALL NEW HR-V e:HEV RS',
            price: 492000000,
            priceFormatted: 'Rp 492.000.000',
            features: [
                'e:HEV Hybrid System',
                'RS Aero Kit',
                'LED Headlights dengan DRL',
                '18-inch RS Alloy Wheels',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING 360',
                '360° Camera System',
                'Rear View Camera',
                'Push Start Button',
                'Smart Keyless Entry',
                'Multi-Angle Rearview Camera',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Auto AC Dual Zone dengan Ionizer',
                'Rear AC Vents',
                'Leather Seats dengan RS Embroidery',
                'Power Adjustable Driver & Passenger Seats',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation',
                'Auto High Beam',
                'Rain Sensing Wipers',
                'Electrostatic Touch AC Panel',
                'EV Drive Mode',
                'Regenerative Braking',
                '4 Driving Modes (Econ, Normal, Sport, EV)',
                'RS Front Grille',
                'RS Side Skirts',
                'RS Rear Diffuser',
                'RS Interior Accents',
                'Paddle Shifters',
                'Ambient Lighting',
                'Head-Up Display',
                'Wireless Charger',
                'Blind Spot Information',
                'Cross Traffic Monitor'
            ],
            transmission: 'e-CVT',
            fuelType: 'Hybrid',
            engineCapacity: '1.5L e:HEV',
            available: true
        },
        {
            id: 'hrv-ehev-rs-tt',
            type: 'ALL NEW HR-V e:HEV RS TWO TONE',
            price: 494500000,
            priceFormatted: 'Rp 494.500.000',
            features: [
                'e:HEV Hybrid System',
                'RS Aero Kit',
                'Two-Tone Color',
                'LED Headlights dengan DRL',
                '18-inch RS Alloy Wheels',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING 360',
                '360° Camera System',
                'Rear View Camera',
                'Push Start Button',
                'Smart Keyless Entry',
                'Multi-Angle Rearview Camera',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Auto AC Dual Zone dengan Ionizer',
                'Rear AC Vents',
                'Leather Seats dengan RS Embroidery',
                'Power Adjustable Driver & Passenger Seats',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation',
                'Auto High Beam',
                'Rain Sensing Wipers',
                'Electrostatic Touch AC Panel',
                'EV Drive Mode',
                'Regenerative Braking',
                '4 Driving Modes (Econ, Normal, Sport, EV)',
                'RS Front Grille',
                'RS Side Skirts',
                'RS Rear Diffuser',
                'RS Interior Accents',
                'Paddle Shifters',
                'Ambient Lighting',
                'Head-Up Display',
                'Wireless Charger',
                'Blind Spot Information',
                'Cross Traffic Monitor',
                'Black Roof',
                'RS Sport Pedals'
            ],
            transmission: 'e-CVT',
            fuelType: 'Hybrid',
            engineCapacity: '1.5L e:HEV',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4385 mm',
            width: '1790 mm',
            height: '1590 mm',
            wheelbase: '2610 mm',
            weight: '1320 - 1380 kg'
        },
        performance: {
            engine: '1.5L DOHC i-MMD e:HEV',
            displacement: '1498 cc',
            maxPower: '131 PS (Combined) | 109 PS (Engine) | 29 PS (Electric)',
            maxTorque: '253 Nm (Electric Motor)',
            transmission: 'e-CVT',
            fuelConsumption: '27,5 km/L',
            acceleration: '0-100 km/h dalam 9.8 detik',
            topSpeed: '175 km/jam'
        },
        capacity: {
            seating: '5 Seater',
            fuelTank: '40 Liter',
            luggage: '437 Liter',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'LED Headlights dengan DRL',
                '17-inch/18-inch Alloy Wheels',
                'RS/Modulo Aero Kit',
                'Two-Tone Color Options',
                'Power Slide Moonroof'
            ],
            interior: [
                '7-inch Touchscreen Display Audio',
                'Electrostatic Touch AC Panel',
                'Leather Seats (Modulo/RS)',
                'Auto AC Dual Zone',
                'Head-Up Display (RS)'
            ],
            safety: [
                '6 SRS Airbags',
                'Honda SENSING / Honda SENSING 360 (RS)',
                '360° Camera System (RS)',
                'Blind Spot Information (RS)',
                'Cross Traffic Monitor (RS)'
            ],
            entertainment: [
                'Apple CarPlay & Android Auto',
                'Wireless Charger (RS)',
                '6 Speakers',
                'Ambient Lighting (RS)'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior Premium dengan Teknologi Hybrid',
            description: 'HR-V e:HEV menghadirkan desain SUV premium yang elegant dilengkapi dengan teknologi hybrid terdepan. Varian RS dan Modulo menawarkan tampilan yang lebih sporty dengan aero kit eksklusif.',
            features: [
                'e:HEV Hybrid Badging',
                'LED Headlights dengan Daytime Running Lights',
                '18-inch RS Alloy Wheels / 17-inch Modulo Wheels',
                'RS Aero Kit / Modulo Aero Kit',
                'Two-Tone Color Options',
                'Power Slide Moonroof',
                'Chrome Accents',
                'Hidden Rear Door Handles'
            ]
        },
        interior: {
            title: 'Interior Canggih dengan Teknologi Hybrid',
            description: 'Kabin yang luxurious dengan teknologi hybrid yang sophisticated. Dilengkapi dengan fitur canggih seperti electrostatic touch panel dan driving mode selection untuk pengalaman berkendara hybrid yang optimal.',
            features: [
                '7-inch Touchscreen Display Audio',
                'Electrostatic Touch AC Panel',
                'Leather Seats dengan RS/Modulo Embroidery',
                '4 Driving Mode Selection',
                'EV Drive Mode Indicator',
                'Head-Up Display (RS)',
                'Power Adjustable Seats',
                'Ambient Lighting (RS)',
                'Wireless Charger (RS)'
            ]
        },
        safety: {
            title: 'Keselamatan Terdepan dengan Honda SENSING 360',
            description: 'Dilengkapi dengan fitur keselamatan paling mutakhir termasuk Honda SENSING 360 pada varian RS untuk perlindungan menyeluruh 360 derajat dalam setiap kondisi berkendara.',
            features: [
                'Honda SENSING 360 (RS)',
                '6 SRS Airbags',
                '360° Camera System (RS)',
                'Blind Spot Information (RS)',
                'Cross Traffic Monitor (RS)',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation'
            ]
        },
        technology: {
            title: 'Teknologi Hybrid e:HEV & Fitur Canggih',
            description: 'Menghadirkan teknologi e:HEV hybrid yang efisien dengan sistem i-MMD terbaru, dilengkapi berbagai fitur canggih untuk pengalaman berkendara yang connected dan sophisticated.',
            features: [
                'e:HEV i-MMD Hybrid System',
                'Honda SENSING 360 (RS)',
                '4 Driving Modes (Econ, Normal, Sport, EV)',
                'Regenerative Braking',
                'Head-Up Display (RS)',
                'Wireless Charger (RS)',
                'Apple CarPlay & Android Auto',
                'Electrostatic Touch AC Panel',
                'EV Drive Mode dengan Battery Indicator'
            ]
        }
    },
    description: 'All New HR-V e:HEV adalah SUV compact premium dengan teknologi hybrid terdepan yang menghadirkan efisiensi bahan bakar exceptional hingga 27,5 km/L. Dengan pilihan 6 varian termasuk Modulo dan RS, HR-V e:HEV menawarkan kombinasi sempurna antara performa responsif, kemewahan, dan teknologi keselamatan canggih dengan Honda SENSING 360.',
    shortDescription: 'SUV compact hybrid premium dengan efisiensi 27,5 km/L, pilihan varian Modulo & RS, dan Honda SENSING 360.',
    tags: [
        'SUV',
        'Hybrid',
        'e:HEV',
        'Premium',
        'Modulo',
        'RS Model',
        'Two-Tone',
        'Fuel Efficient',
        'Honda SENSING 360'
    ],
    isFeatured: true,
    isNew: true,
    views: 1123,
    relatedCars: [
        'hrv-2024',
        'crv-2024',
        'accord-ehev'
    ],
    createdAt: '2024-07-01',
    updatedAt: '2024-07-01'
};
}),
"[project]/data/cars/n7x.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "n7x",
    ()=>n7x
]);
const n7x = {
    id: 'brv-n7x-2024',
    slug: 'all-new-br-v-n7x-edition',
    name: 'All New BR-V N7X Edition',
    model: 'BR-V N7X',
    category: 'MPV',
    priceRange: 'Rp 341,7 - 386,7 Juta',
    startingPrice: 341700000,
    typeCount: 3,
    videoUrl: 'https://youtu.be/iI9I_FqpmeU?si=-MA6k_GR0Rp83-f8',
    images: {
        main: '/images/cars/all-new-br-v-n7x/main.jpg'
    },
    variants: [
        {
            id: 'brv-n7x-e-cvt',
            type: 'ALL NEW BR-V N7X E CVT',
            price: 341700000,
            priceFormatted: 'Rp 341.700.000',
            features: [
                'N7X Exclusive Body Kit',
                'LED Headlights dengan DRL',
                '16-inch Alloy Wheels N7X Design',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '4 SRS Airbags',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Auto AC',
                'Rear AC Vents',
                'Fabric Seats dengan N7X Badging',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio Control',
                'ABS dengan EBD',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Front Fog Lamps',
                'Roof Rail',
                'Chrome Door Handle & Side Molding',
                '60:40 Split Fold 3rd Row Seat',
                '6 Speakers',
                'N7X Front Grille',
                'N7X Side Skirting',
                'N7X Rear Spoiler'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'brv-n7x-prestige',
            type: 'ALL NEW BR-V N7X Prestige',
            price: 366700000,
            priceFormatted: 'Rp 366.700.000',
            features: [
                'N7X Exclusive Body Kit',
                'LED Headlights dengan DRL',
                '16-inch Alloy Wheels N7X Design',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Auto AC Dual Zone',
                'Rear AC Vents',
                'Leather Seats dengan N7X Embroidery',
                'Power Adjustable Driver Seat',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio & Phone Control',
                'ABS dengan EBD',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Front Fog Lamps',
                'Roof Rail',
                'Chrome Door Handle & Side Molding',
                '60:40 Split Fold 3rd Row Seat',
                '6 Speakers',
                'N7X Front Grille',
                'N7X Side Skirting',
                'N7X Rear Spoiler',
                'Panoramic Sunroof',
                'Ambient Lighting',
                'Auto Dimming Rearview Mirror'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        },
        {
            id: 'brv-n7x-prestige-hs',
            type: 'ALL NEW BR-V N7X Prestige with Honda SENSING',
            price: 386700000,
            priceFormatted: 'Rp 386.700.000',
            features: [
                'N7X Exclusive Body Kit',
                'LED Headlights dengan DRL',
                '16-inch Alloy Wheels N7X Design',
                '7-inch Touchscreen Display Audio',
                'Apple CarPlay & Android Auto',
                '6 SRS Airbags',
                'Honda SENSING',
                'Rear View Camera',
                'Push Start Button',
                'Keyless Entry System',
                'Auto AC Dual Zone',
                'Rear AC Vents',
                'Leather Seats dengan N7X Embroidery',
                'Power Adjustable Driver Seat',
                'Power Window Depan & Belakang',
                'Steering Wheel dengan Audio & Phone Control',
                'ABS dengan EBD',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Front Fog Lamps',
                'Roof Rail',
                'Chrome Door Handle & Side Molding',
                '60:40 Split Fold 3rd Row Seat',
                '6 Speakers',
                'N7X Front Grille',
                'N7X Side Skirting',
                'N7X Rear Spoiler',
                'Panoramic Sunroof',
                'Ambient Lighting',
                'Auto Dimming Rearview Mirror',
                'Adaptive Cruise Control',
                'Lane Keeping Assist',
                'Collision Mitigation Braking System',
                'Road Departure Mitigation',
                'Lane Watch Camera',
                'Auto High Beam'
            ],
            transmission: 'CVT',
            fuelType: 'Bensin',
            engineCapacity: '1.5L',
            available: true
        }
    ],
    specs: {
        dimensions: {
            length: '4490 mm',
            width: '1780 mm',
            height: '1685 mm',
            wheelbase: '2760 mm',
            weight: '1230 - 1270 kg'
        },
        performance: {
            engine: '1.5L DOHC i-VTEC',
            displacement: '1497 cc',
            maxPower: '121 PS / 6600 rpm',
            maxTorque: '145 Nm / 4300 rpm',
            transmission: 'CVT',
            fuelConsumption: '15,9 km/L',
            acceleration: '0-100 km/h dalam 12.8 detik',
            topSpeed: '170 km/jam'
        },
        capacity: {
            seating: '7 Seater',
            fuelTank: '45 Liter',
            luggage: '223 Liter (7-seater) | 691 Liter (5-seater mode)',
            doors: '5 Pintu'
        },
        features: {
            exterior: [
                'N7X Exclusive Body Kit',
                'LED Headlights dengan DRL',
                '16-inch N7X Alloy Wheels',
                'Roof Rail',
                'Front Fog Lamps',
                'Panoramic Sunroof (Prestige)'
            ],
            interior: [
                '7-inch Touchscreen Display Audio',
                'Leather Seats (Prestige)',
                '60:40 Split Fold 3rd Row',
                'Auto AC Dual Zone (Prestige)',
                'Panoramic Sunroof (Prestige)'
            ],
            safety: [
                '6 SRS Airbags (Prestige)',
                'Honda SENSING (Prestige HS)',
                'ABS dengan EBD',
                'Vehicle Stability Assist',
                'Rear View Camera'
            ],
            entertainment: [
                'Apple CarPlay & Android Auto',
                '6 Speakers',
                'Ambient Lighting (Prestige)'
            ]
        }
    },
    features: {
        exterior: {
            title: 'Desain Eksterior N7X Exclusive & Sporty',
            description: 'BR-V N7X Edition menghadirkan desain MPV yang lebih sporty dan exclusive dengan body kit khusus N7X. Tampilan yang lebih aggressive dan modern dengan sentuhan premium.',
            features: [
                'N7X Exclusive Body Kit',
                'LED Headlights dengan Daytime Running Lights',
                '16-inch Alloy Wheels N7X Design',
                'N7X Front Grille',
                'N7X Side Skirting',
                'N7X Rear Spoiler',
                'Roof Rail',
                'Panoramic Sunroof (Prestige)',
                'Chrome Accents'
            ]
        },
        interior: {
            title: 'Interior Premium dengan Sentuhan N7X',
            description: 'Kabin yang luxurious dengan material premium dan embel-embel N7X exclusive. Dilengkapi dengan fitur kenyamanan tinggi dan teknologi terkini untuk pengalaman berkendara premium.',
            features: [
                'Leather Seats dengan N7X Embroidery (Prestige)',
                '7-inch Touchscreen Display Audio',
                'Panoramic Sunroof (Prestige)',
                'Auto AC Dual Zone (Prestige)',
                'Power Adjustable Driver Seat (Prestige)',
                'Ambient Lighting (Prestige)',
                'Steering Wheel dengan Audio & Phone Control',
                '60:40 Split Fold 3rd Row Seat'
            ]
        },
        safety: {
            title: 'Keselamatan Lengkap dengan Honda SENSING',
            description: 'Dilengkapi dengan fitur keselamatan paling lengkap termasuk Honda SENSING pada varian Prestige HS untuk perlindungan maksimal seluruh penumpang keluarga.',
            features: [
                'Honda SENSING (Prestige HS)',
                '6 SRS Airbags (Prestige)',
                'Vehicle Stability Assist (VSA)',
                'Hill Start Assist',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Rear View Camera',
                'Anti-Lock Braking System (ABS)',
                'Electronic Brake-force Distribution (EBD)',
                'Lane Watch Camera (Prestige HS)'
            ]
        },
        technology: {
            title: 'Teknologi Canggih & Fitur Eksklusif',
            description: 'Berbagai fitur teknologi modern dan eksklusif N7X yang mendukung kenyamanan, keselamatan, dan konektivitas dalam berkendara sehari-hari.',
            features: [
                'Honda SENSING (Prestige HS)',
                'Panoramic Sunroof (Prestige)',
                'Push Start Button',
                'Keyless Entry System',
                'Auto AC Dual Zone (Prestige)',
                'Apple CarPlay & Android Auto',
                'Ambient Lighting (Prestige)',
                'Electric Parking Brake dengan Auto Brake Hold',
                'Steering Wheel dengan Audio & Phone Control'
            ]
        }
    },
    description: 'All New BR-V N7X Edition adalah varian exclusive dari BR-V yang menghadirkan desain lebih sporty dengan body kit khusus, interior premium, dan fitur keselamatan lengkap dengan Honda SENSING. Dengan pilihan varian E CVT, Prestige, dan Prestige with Honda SENSING, BR-V N7X menjadi pilihan MPV keluarga yang stylish dan sophisticated.',
    shortDescription: 'MPV 7-seater exclusive dengan body kit N7X, interior premium, dan Honda SENSING pada varian tertinggi.',
    tags: [
        'MPV',
        '7-Seater',
        'N7X Edition',
        'Premium',
        'Family Car',
        'Honda SENSING',
        'Sporty',
        'Exclusive'
    ],
    isFeatured: true,
    isNew: true,
    views: 658,
    relatedCars: [
        'brv-2024',
        'hrv-2024',
        'crv-2024'
    ],
    createdAt: '2024-06-01',
    updatedAt: '2024-06-01'
};
}),
"[project]/data/cars/index.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cars",
    ()=>cars
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brio$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/brio.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/hrv.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$crv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/crv.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$wrv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/wrv.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/brv.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civic$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/civic.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$accord$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/accord.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$stepwgn$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/stepwgn.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$cityhatchback$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/cityhatchback.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civictyper$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/civictyper.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrvehev$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/hrvehev.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$n7x$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/n7x.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const cars = [
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brio$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["brio"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["hrv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$crv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["crv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$wrv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["wrv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$brv$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["brv"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civic$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["civic"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$accord$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["accord"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$stepwgn$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["stepwgn"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$cityhatchback$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cityhatchback"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$civictyper$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["civicTypeR"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$hrvehev$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["hrvehev"],
    __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$n7x$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["n7x"]
];
}),
"[project]/types/car.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Car Variant Type
__turbopack_context__.s([]);
;
}),
"[project]/data/index.ts [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAllCarSlugs",
    ()=>getAllCarSlugs,
    "getAllCars",
    ()=>getAllCars,
    "getCarBySlug",
    ()=>getCarBySlug,
    "getCarsByCategory",
    ()=>getCarsByCategory,
    "getCarsByPriceRange",
    ()=>getCarsByPriceRange,
    "getFeaturedCars",
    ()=>getFeaturedCars,
    "getNewCars",
    ()=>getNewCars,
    "searchCars",
    ()=>searchCars
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/data/cars/index.ts [app-rsc] (ecmascript)");
// Export types
var __TURBOPACK__imported__module__$5b$project$5d2f$types$2f$car$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/types/car.ts [app-rsc] (ecmascript)");
;
;
const getCarBySlug = (slug)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].find((car)=>car.slug === slug);
};
const getFeaturedCars = ()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].filter((car)=>car.isFeatured);
};
const getNewCars = ()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].filter((car)=>car.isNew);
};
const getCarsByCategory = (category)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].filter((car)=>car.category === category);
};
const getAllCarSlugs = ()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].map((car)=>car.slug);
};
const getAllCars = ()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"];
};
const searchCars = (query)=>{
    const lowerQuery = query.toLowerCase();
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].filter((car)=>car.name.toLowerCase().includes(lowerQuery) || car.model.toLowerCase().includes(lowerQuery) || car.tags.some((tag)=>tag.toLowerCase().includes(lowerQuery)) || car.category.toLowerCase().includes(lowerQuery));
};
const getCarsByPriceRange = (min, max)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$cars$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cars"].filter((car)=>car.startingPrice >= min && car.startingPrice <= max);
};
;
}),
"[project]/components/cars/CarHero.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/CarHero.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/CarHero.tsx <module evaluation>", "default");
}),
"[project]/components/cars/CarHero.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/CarHero.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/CarHero.tsx", "default");
}),
"[project]/components/cars/CarHero.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/CarHero.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/CarHero.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/cars/CarQuickInfo.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarQuickInfo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function CarQuickInfo({ car }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "bg-white py-12 border-b border-gray-200",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-3 gap-6 mb-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gray-50 rounded-xl p-6 text-center border border-gray-200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-500 text-sm mb-2",
                                    children: "KATEGORI"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 14,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-xl font-bold text-gray-900",
                                    children: car.category
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 15,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 13,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gray-50 rounded-xl p-6 text-center border border-gray-200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-500 text-sm mb-2",
                                    children: "VARIAN TERSEDIA"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 19,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-xl font-bold text-gray-900",
                                    children: [
                                        car.typeCount,
                                        " Pilihan"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 20,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gray-50 rounded-xl p-6 text-center border border-gray-200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-500 text-sm mb-2",
                                    children: "DILIHAT"
                                }, void 0, false, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 24,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-xl font-bold text-gray-900",
                                    children: [
                                        car.views.toLocaleString(),
                                        "x"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                                    lineNumber: 25,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-3xl mx-auto text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-700 text-lg leading-relaxed mb-6",
                            children: car.description
                        }, void 0, false, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 31,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-24 h-1 bg-red-600 mx-auto rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/components/cars/CarQuickInfo.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/cars/CarQuickInfo.tsx",
                    lineNumber: 30,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/cars/CarQuickInfo.tsx",
            lineNumber: 10,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/cars/CarQuickInfo.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/VariantsTable.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/VariantsTable.tsx <module evaluation>", "default");
}),
"[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/VariantsTable.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/VariantsTable.tsx", "default");
}),
"[project]/components/cars/VariantsTable.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/VariantsTable.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/CarFeaturesTabs.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/CarFeaturesTabs.tsx <module evaluation>", "default");
}),
"[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/CarFeaturesTabs.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/CarFeaturesTabs.tsx", "default");
}),
"[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/cars/VideoSection.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/VideoSection.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/VideoSection.tsx <module evaluation>", "default");
}),
"[project]/components/cars/VideoSection.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/cars/VideoSection.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/cars/VideoSection.tsx", "default");
}),
"[project]/components/cars/VideoSection.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VideoSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/cars/VideoSection.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VideoSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/cars/VideoSection.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VideoSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/cars/MainCTASection.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MainCTASection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function MainCTASection({ car }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "relative bg-gradient-to-br from-red-600 via-red-500 to-red-700 text-white py-20 overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 opacity-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-0 left-0 w-72 h-72 bg-white rounded-full -translate-x-1/2 -translate-y-1/2"
                    }, void 0, false, {
                        fileName: "[project]/components/cars/MainCTASection.tsx",
                        lineNumber: 12,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full translate-x-1/3 translate-y-1/3"
                    }, void 0, false, {
                        fileName: "[project]/components/cars/MainCTASection.tsx",
                        lineNumber: 13,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/cars/MainCTASection.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4 text-center relative z-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-4xl md:text-5xl font-bold mb-6 tracking-tight",
                                children: [
                                    "Siap Memiliki ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-yellow-300",
                                        children: car.name
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 20,
                                        columnNumber: 27
                                    }, this),
                                    "?"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                lineNumber: 19,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-32 h-1 bg-yellow-400 mx-auto mb-8 rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                lineNumber: 22,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xl md:text-2xl mb-6 max-w-3xl mx-auto leading-relaxed font-light",
                                children: "Jangan lewatkan penawaran spesial dan dapatkan harga terbaik langsung dari Rendy Honda"
                            }, void 0, false, {
                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                lineNumber: 23,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/MainCTASection.tsx",
                        lineNumber: 18,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white/10 backdrop-blur-sm rounded-2xl p-8 mb-10 max-w-2xl mx-auto border border-white/20",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col md:flex-row items-center justify-between gap-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-left",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-2xl font-bold text-yellow-300 mb-2",
                                            children: "Harga Mulai"
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/MainCTASection.tsx",
                                            lineNumber: 32,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-3xl md:text-4xl font-bold",
                                            children: car.priceRange
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/MainCTASection.tsx",
                                            lineNumber: 35,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-red-100 mt-2",
                                            children: [
                                                car.typeCount,
                                                " Varian Tersedia"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/MainCTASection.tsx",
                                            lineNumber: 38,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                    lineNumber: 31,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col gap-2 text-left",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    className: "w-5 h-5 text-green-400",
                                                    fill: "currentColor",
                                                    viewBox: "0 0 20 20",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        fillRule: "evenodd",
                                                        d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                                                        clipRule: "evenodd"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                                        lineNumber: 45,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                                    lineNumber: 44,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "DP Ringan"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                                    lineNumber: 47,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/MainCTASection.tsx",
                                            lineNumber: 43,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    className: "w-5 h-5 text-green-400",
                                                    fill: "currentColor",
                                                    viewBox: "0 0 20 20",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        fillRule: "evenodd",
                                                        d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                                                        clipRule: "evenodd"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                                        lineNumber: 51,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                                    lineNumber: 50,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "Bunga Kompetitif"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                                    lineNumber: 53,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/MainCTASection.tsx",
                                            lineNumber: 49,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    className: "w-5 h-5 text-green-400",
                                                    fill: "currentColor",
                                                    viewBox: "0 0 20 20",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        fillRule: "evenodd",
                                                        d: "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z",
                                                        clipRule: "evenodd"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                                        lineNumber: 57,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                                    lineNumber: 56,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "Proses Cepat"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                                    lineNumber: 59,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/cars/MainCTASection.tsx",
                                            lineNumber: 55,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                    lineNumber: 42,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/cars/MainCTASection.tsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/cars/MainCTASection.tsx",
                        lineNumber: 29,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col sm:flex-row gap-6 justify-center items-center max-w-2xl mx-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: `https://wa.me/6287852432636?text=${encodeURIComponent(`Halo Rendy, saya tertarik dengan ${car.name} ${car.model} ${car.year}. Bisa info detail harga ${car.priceRange}, spesifikasi, dan penawaran terbaiknya?`)}`,
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "group bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-10 py-5 rounded-2xl font-bold text-lg shadow-2xl hover:shadow-3xl hover:scale-105 transition-all duration-300 w-full sm:w-auto flex items-center justify-center gap-4 border-2 border-green-400 min-w-[280px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-7 h-7",
                                                fill: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893-.001-3.189-1.248-6.189-3.515-8.452"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                                    lineNumber: 76,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                                lineNumber: 75,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute -top-1 -right-1 flex gap-1",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "w-2 h-2 bg-white rounded-full animate-ping"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                                    lineNumber: 79,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                                lineNumber: 78,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 74,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-lg",
                                        children: "Chat WhatsApp"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 82,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-5 h-5 transform group-hover:translate-x-1 transition-transform",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M13 7l5 5m0 0l-5 5m5-5H6"
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/MainCTASection.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 83,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                lineNumber: 68,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col sm:flex-row gap-4 w-full sm:w-auto",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "tel:087852432636",
                                        className: "group bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white px-8 py-4 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 w-full sm:w-auto flex items-center justify-center gap-3 border border-white/20 hover:border-white/40 min-w-[200px]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-6 h-6",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                                    lineNumber: 96,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                                lineNumber: 95,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Telepon"
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                                lineNumber: 98,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 91,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: `https://wa.me/6287852432636?text=${encodeURIComponent(`Halo Rendy, saya ingin jadwalkan test drive untuk ${car.name} ${car.model}. Kapan tersedia?`)}`,
                                        className: "group bg-yellow-500 hover:bg-yellow-600 text-gray-900 px-8 py-4 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 w-full sm:w-auto flex items-center justify-center gap-3 border border-yellow-400 min-w-[200px]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-6 h-6",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M13 10V3L4 14h7v7l9-11h-7z"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/cars/MainCTASection.tsx",
                                                    lineNumber: 107,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                                lineNumber: 106,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Test Drive"
                                            }, void 0, false, {
                                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                                lineNumber: 109,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 102,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                lineNumber: 89,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/MainCTASection.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-12 text-sm text-red-100 flex flex-col sm:flex-row justify-center items-center gap-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-5 h-5",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/MainCTASection.tsx",
                                            lineNumber: 118,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 117,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-semibold",
                                        children: "Respon Cepat 24 Jam"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 120,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                lineNumber: 116,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "hidden sm:block w-1 h-1 bg-red-300 rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                lineNumber: 122,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-5 h-5",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/MainCTASection.tsx",
                                            lineNumber: 125,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 124,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-semibold",
                                        children: "Penawaran Terbaik"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 127,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                lineNumber: 123,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "hidden sm:block w-1 h-1 bg-red-300 rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                lineNumber: 129,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-5 h-5",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M13 10V3L4 14h7v7l9-11h-7z"
                                        }, void 0, false, {
                                            fileName: "[project]/components/cars/MainCTASection.tsx",
                                            lineNumber: 132,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 131,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-semibold",
                                        children: "Test Drive Gratis"
                                    }, void 0, false, {
                                        fileName: "[project]/components/cars/MainCTASection.tsx",
                                        lineNumber: 134,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/cars/MainCTASection.tsx",
                                lineNumber: 130,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/cars/MainCTASection.tsx",
                        lineNumber: 115,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/cars/MainCTASection.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/cars/MainCTASection.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/mobil/[slug]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarDetailPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/data/index.ts [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarHero.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarQuickInfo$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarQuickInfo.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/VariantsTable.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/CarFeaturesTabs.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VideoSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/VideoSection.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$MainCTASection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/cars/MainCTASection.tsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
async function CarDetailPage({ params }) {
    const { slug } = await params;
    const car = (0, __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getCarBySlug"])(slug);
    if (!car) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarHero$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                car: car
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarQuickInfo$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                car: car
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VideoSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                videoUrl: car.videoUrl,
                title: `Video ${car.name}`,
                description: `Lihat keunggulan dan fitur-fitur terbaru ${car.name} dalam video berikut`
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "harga",
                className: "py-16 bg-gray-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$VariantsTable$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        variants: car.variants,
                        carName: car.name
                    }, void 0, false, {
                        fileName: "[project]/app/mobil/[slug]/page.tsx",
                        lineNumber: 41,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/mobil/[slug]/page.tsx",
                    lineNumber: 40,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$CarFeaturesTabs$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                features: car.features,
                specs: car.specs
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$cars$2f$MainCTASection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                car: car
            }, void 0, false, {
                fileName: "[project]/app/mobil/[slug]/page.tsx",
                lineNumber: 49,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/mobil/[slug]/page.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/mobil/[slug]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/mobil/[slug]/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__2533a69b._.js.map