module.exports = [
"[project]/components/layout/PreFooter/BlogPreview.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/_0ff3298c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/layout/PreFooter/BlogPreview.tsx [app-ssr] (ecmascript)");
    });
});
}),
];